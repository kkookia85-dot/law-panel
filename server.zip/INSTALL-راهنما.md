# راهنمای نصب سرور جدید (قدم‌به‌قدم)

> همهٔ دستورها داخل ترمینال سرور (SSH) زده می‌شوند. هر بلوک را کپی و Enter بزنید.
> ⚠️ رمز root را که قبلاً در چت فرستاده‌اید حتماً عوض کنید: `passwd`

## ۰) آماده‌سازی دامنه
برای HTTPS (قفل سبز، لازم برای اپ موبایل) یک دامنه یا ساب‌دامین لازم است، مثلاً `panel.example.com`.
در پنل DNS دامنه یک رکورد **A** بسازید که به **IP سرور** اشاره کند. چند دقیقه صبر کنید تا فعال شود.

## ۱) نصب Node.js 22، Caddy و ابزارها
```bash
apt update && apt install -y curl unzip debian-keyring debian-archive-keyring apt-transport-https gnupg
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs
node -v        # باید v22 یا بالاتر باشد

curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy.list
apt update && apt install -y caddy
```

## ۲) گذاشتن برنامه روی سرور
پوشهٔ `server` را (همین فایل‌ها) به‌صورت zip به سرور بفرستید، مثلاً از PowerShell کامپیوتر خودتان:
```powershell
scp server.zip root@IP_SERVER:/root/
```
سپس روی سرور:
```bash
adduser --system --group --home /opt/panel panel
mkdir -p /opt/panel && cd /opt/panel
unzip -o /root/server.zip -d /opt/panel      # اگر داخل zip یک پوشهٔ server هست، محتویاتش را به /opt/panel ببرید
mkdir -p data backups
cp .env.example .env
chown -R panel:panel /opt/panel
chmod 600 .env
```

## ۳) تنظیمات
```bash
nano /opt/panel/.env
```
مقادیر زیر را پر کنید:
- `BOT_TOKEN=` توکن همان ربات فعلی (از BotFather)
- `PUBLIC_URL=https://panel.example.com`
- `TELEGRAM=off`  ← **فعلاً خاموش** تا انتقال تمام شود

ذخیره: `Ctrl+O` ، Enter ، `Ctrl+X`

## ۴) اجرای سرویس و HTTPS
```bash
cp /opt/panel/deploy/panel.service /etc/systemd/system/
cp /opt/panel/deploy/panel-backup.service /opt/panel/deploy/panel-backup.timer /etc/systemd/system/
sed 's/DOMAIN.EXAMPLE.COM/panel.example.com/' /opt/panel/deploy/Caddyfile > /etc/caddy/Caddyfile   # دامنهٔ خودتان
systemctl daemon-reload
systemctl enable --now panel panel-backup.timer
systemctl restart caddy
systemctl status panel --no-pager
```
در مرورگر `https://panel.example.com/healthz` را باز کنید؛ باید `ok` ببینید.

## ۵) انتقال داده‌ها از سیستم قدیمی (Google Sheets)
۱. در Apps Script فایل‌های جدید **Code.gs** و **Api.gs** (از پوشهٔ `app`) را جایگزین کنید و **Deploy → Manage deployments → Edit → New version → Deploy** بزنید (آدرس exec همان می‌ماند).
۲. روی سرور:
```bash
cd /opt/panel
sudo -u panel node --no-warnings src/import.js --url "آدرس-exec-قدیمی" --key "کلید-مدیر-فعلی"
```
باید پیام «انتقال کامل شد» با تعداد ردیف‌ها بیاید. کلیدهای مدیر و اعضا **همان قبلی می‌مانند**.

## ۶) تست قبل از سوییچ
`https://panel.example.com` را باز کنید و با کلید مدیر وارد شوید؛ تعداد اعضا و درخواست‌ها را چک کنید.

## ۷) سوییچ ربات (لحظهٔ قطعی)
۱. در سیستم قدیمی ربات را متوقف کنید: Deploy قدیمی را Archive کنید یا فقط ادامه دهید (وقتی سرور جدید `deleteWebhook` بزند، ربات به آن منتقل می‌شود).
۲. برای اینکه چیزی بین انتقال و سوییچ گم نشود، یک‌بار دیگر import با `--force` بزنید:
```bash
sudo -u panel node --no-warnings src/import.js --url "..." --key "..." --force
```
۳. تلگرام را روشن کنید:
```bash
sed -i 's/^TELEGRAM=.*/TELEGRAM=on/' /opt/panel/.env
systemctl restart panel
journalctl -u panel -n 20 --no-pager     # باید «ربات: @نام_ربات» ببینید
```
۴. به ربات `/start` بزنید و ثبت یک فرم را تست کنید.
۵. لینک اپ اعضا حالا `https://panel.example.com` است؛ کلیدها همان است.

## نگهداری
- لاگ: `journalctl -u panel -f`
- بکاپ خودکار هر شب ساعت ۰۳:۳۰ در `/opt/panel/backups` (۱۴ نسخه). بهتر است گاهی یک نسخه را با `scp` به کامپیوتر خودتان بگیرید.
- بازگردانی: سرویس را متوقف کنید، فایل بکاپ را روی `/opt/panel/data/panel.db` کپی کنید، سرویس را شروع کنید.
- آپدیت برنامه: فایل‌ها را جایگزین کنید و `systemctl restart panel`.
- فایروال: فقط پورت‌های 22، 80 و 443 باز باشند (`ufw allow 22,80,443/tcp && ufw enable`).
- ⚠️ ربات تلگرام باید از سروری کار کند که به `api.telegram.org` دسترسی دارد. اگر سرور داخل ایران تلگرام را نمی‌بیند، متغیر `TELEGRAM_API_BASE` را روی یک پروکسی/رله بگذارید (یا سرور خارج از ایران بگیرید).
