// =====================================================
//  Api.gs — سرور اپ موبایل (مدیر + اعضای تیم)
//  این فایل کنار Code.gs و App.html تو همون پروژه قرار می‌گیره.
// =====================================================

const APP_KEY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // بدون حروف شبیه هم (O/0, I/1)

// ---------- کلیدهای ورود ----------

function generateAppKey_() {
  const hex = Utilities.getUuid().replace(/-/g, "");
  let key = "";
  for (let i = 0; i < 12; i++) {
    const n = parseInt(hex.substr(i * 2, 2), 16);
    key += APP_KEY_ALPHABET.charAt(n % APP_KEY_ALPHABET.length);
    if (i % 4 === 3 && i < 11) key += "-";
  }
  return key;
}

function normKey_(k) {
  return String(k || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function getAdminAppKey_() {
  return ensureAdminKey_();
}

function ensureAdminKey_() {
  const props = PropertiesService.getScriptProperties();
  let key = props.getProperty("ADMIN_APP_KEY");
  if (!key) {
    key = generateAppKey_();
    props.setProperty("ADMIN_APP_KEY", key);
  }
  return key;
}

function backfillAgentKeys_() {
  const sheet = getTeamSheet_();
  if (sheet.getLastRow() < 2) return;
  const n = sheet.getLastRow() - 1;
  const codes = sheet.getRange(2, TCOL.CODE, n, 1).getValues();
  const range = sheet.getRange(2, TCOL.KEY, n, 1);
  const keys = range.getValues();
  let changed = false;
  keys.forEach(function(r, i) {
    if (!r[0] && codes[i][0]) { r[0] = generateAppKey_(); changed = true; }
  });
  if (changed) range.setValues(keys);
}

function appUrl_() {
  return PropertiesService.getScriptProperties().getProperty("WEB_APP_URL") || "";
}

function isTgId_(id) {
  return /^\d{5,}$/.test(String(id || ""));
}

function showAppAccess() {
  const url = appUrl_();
  SpreadsheetApp.getUi().alert(
    "ورود به اپ",
    "آدرس اپ:\n" + (url || "هنوز ثبت نشده — اول Deploy و «۳. اتصال ربات» رو انجام بده") +
    "\n\nکلید ورود مدیر:\n" + getAdminAppKey_() +
    "\n\nکلید هر عضو تیم تو شیت Team (ستون app_key) و داخل اپ (بخش تیم) هست.",
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}

function resetAdminAppKey() {
  const ui = SpreadsheetApp.getUi();
  if (ui.alert("کلید جدید مدیر", "کلید قبلی مدیر باطل بشه؟", ui.ButtonSet.YES_NO) !== ui.Button.YES) return;
  PropertiesService.getScriptProperties().deleteProperty("ADMIN_APP_KEY");
  ui.alert("کلید جدید مدیر:\n\n" + ensureAdminKey_());
}

// ---------- ورودی/خروجی ----------

function parseApiRequest_(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) return null;
    const c = String(e.postData.contents);
    if (c.charAt(0) !== "{" || c.indexOf('"api"') === -1) return null;
    const obj = JSON.parse(c);
    if (obj && obj.api === true) return obj;
  } catch (err) {}
  return null;
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// =====================================================
//  نقطه ورود اپ (با google.script.run یا fetch صدا زده می‌شه)
// =====================================================

function appApi(token, action, payload) {
  let lock = null;
  try {
    const user = authUser_(token);
    if (!user) return { ok: false, error: "UNAUTHORIZED" };

    const spec = API_ACTIONS[String(action)];
    if (!spec) return { ok: false, error: "UNKNOWN_ACTION" };
    const roleOk = user.role === "admin" ||
      (user.role === "manager" && spec.manager === true) ||
      (user.role === "agent" && !spec.admin);
    if (!roleOk) return { ok: false, error: "FORBIDDEN" };

    MEMO = {};
    MEMO_ON = !spec.write;
    if (spec.write) {
      lock = LockService.getScriptLock();
      lock.waitLock(25000);
    }

    const data = spec.fn(user, payload || {});
    return { ok: true, data: data };
  } catch (err) {
    console.error(err && err.stack ? err.stack : err);
    return { ok: false, error: String(err && err.message ? err.message : err) };
  } finally {
    MEMO_ON = false;
    MEMO = {};
    if (lock) { try { lock.releaseLock(); } catch (e2) {} }
  }
}

function authUser_(token) {
  const t = normKey_(token);
  if (t.length < 12) return null;

  const adminKey = normKey_(PropertiesService.getScriptProperties().getProperty("ADMIN_APP_KEY"));
  if (adminKey && t === adminKey) {
    return { role: "admin", id: getSetting_("ADMIN_ID") || "admin", name: "مدیر" };
  }

  const grp = getGroups_().find(function(g) { return g.mgrKey && normKey_(g.mgrKey) === t; });
  if (grp) {
    return { role: "manager", id: "M" + grp.id, name: grp.mgrName || ("مدیر " + grp.name), group: grp };
  }

  const agent = getAllAgents_().find(function(a) {
    return a.status === "active" && a.agentId && a.appKey && normKey_(a.appKey) === t;
  });
  if (agent) return { role: "agent", id: agent.agentId, name: agent.name, agent: agent };
  return null;
}

// =====================================================
//  ابزارهای داخلی
// =====================================================

function toMs_(v) {
  if (!v) return 0;
  const t = new Date(v).getTime();
  return isNaN(t) ? 0 : t;
}

function startOfDayMs_() {
  const now = new Date();
  const day = Utilities.formatDate(now, tz_(), "yyyy-MM-dd");
  return Utilities.parseDate(day + " 00:00:00", tz_(), "yyyy-MM-dd HH:mm:ss").getTime();
}

function rangeBounds_(range) {
  const DAY = 24 * 3600 * 1000;
  const start = startOfDayMs_();
  if (range === "today") return { from: start, to: start + DAY };
  if (range === "yday") return { from: start - DAY, to: start };
  if (range === "week") return { from: Date.now() - 7 * DAY, to: Infinity };
  return { from: 0, to: Infinity };
}

function inBounds_(ms, b) {
  return ms >= b.from && ms < b.to;
}

function agentsIndex_() {
  const byId = {};
  const byCode = {};
  getAllAgents_().forEach(function(a) {
    if (a.agentId) byId[a.agentId] = a;
    byCode[a.code] = a;
  });
  return { byId: byId, byCode: byCode };
}

function lastCallMap_(calls) {
  const map = {};
  calls.forEach(function(c) { map[c.leadId] = c; });
  return map;
}

function leadView_(l, idx, lastCall, admin) {
  const ag = l.assignedTo ? idx.byId[l.assignedTo] : null;
  const v = {
    id: l.leadId,
    seq: l.seq,
    name: l.name,
    phone: l.phone,
    age: l.age,
    city: l.city,
    goal: l.goal,
    status: l.status,
    createdAt: toMs_(l.createdAt),
    assignedAt: toMs_(l.assignedAt),
    agentCode: ag ? ag.code : "",
    agentName: ag ? ag.name : "",
    agentNo: ag ? ag.no : 0,
    callsCount: l.callsCount,
    lastCallAt: lastCall ? toMs_(lastCall.createdAt) : 0,
    lastOutcome: lastCall ? lastCall.outcome : "",
    visitAt: lastCall && lastCall.outcome === "visit" && l.status === "visit" ? (lastCall.visitAt || 0) : 0
  };
  if (admin) {
    v.username = l.username;
    v.note = l.note;
  }
  return v;
}

function callView_(c, leadsById, idx) {
  const l = leadsById[c.leadId];
  const ag = idx.byId[c.agentId];
  return {
    id: c.callId,
    at: toMs_(c.createdAt),
    leadId: c.leadId,
    seq: l ? l.seq : 0,
    leadName: l ? l.name : c.leadName,
    phone: l ? l.phone : "",
    agentName: c.agentName,
    agentCode: ag ? ag.code : "",
    outcome: c.outcome,
    note: c.note,
    editedAt: c.editedAt ? toMs_(c.editedAt) : 0,
    visitAt: c.visitAt || 0
  };
}

function leadsById_(leads) {
  const m = {};
  leads.forEach(function(l) { m[l.leadId] = l; });
  return m;
}

function emptyBy_() {
  const by = {};
  OUTCOME_KEYS.forEach(function(k) { by[k] = 0; });
  return by;
}

function teamStatsMap_(leads, calls) {
  const map = {};
  const get = function(id) {
    return map[id] || (map[id] = { assigned: 0, pending: 0, today: 0, total: 0, by: emptyBy_(), last: 0 });
  };
  leads.forEach(function(l) {
    if (!l.assignedTo) return;
    const s = get(l.assignedTo);
    s.assigned++;
    if (PENDING_STATUSES.indexOf(l.status) !== -1) s.pending++;
  });
  const b = rangeBounds_("today");
  calls.forEach(function(c) {
    const s = get(c.agentId);
    s.total++;
    if (s.by[c.outcome] !== undefined) s.by[c.outcome]++;
    const ms = toMs_(c.createdAt);
    if (inBounds_(ms, b)) s.today++;
    if (ms > s.last) s.last = ms;
  });
  return map;
}

function agentView_(a, stats, withKey) {
  const s = stats || { assigned: 0, pending: 0, today: 0, total: 0, by: emptyBy_(), last: 0 };
  const v = {
    code: a.code,
    no: a.no,
    name: a.name,
    status: a.status,
    username: a.username,
    joinedAt: toMs_(a.joinedAt),
    viaTelegram: isTgId_(a.agentId),
    tgLinked: !!notifyTarget_(a),
    group: a.group || "",
    assigned: s.assigned,
    pending: s.pending,
    today: s.today,
    total: s.total,
    by: s.by,
    lastCallAt: s.last
  };
  if (withKey) v.key = a.appKey;
  return v;
}

function agentFromPayload_(p) {
  const a = getAgentByCode_(p.code || p.agentCode);
  if (!a) throw new Error("عضو پیدا نشد.");
  return a;
}

function activeAgentFromPayload_(p) {
  const a = agentFromPayload_(p);
  if (a.status !== "active" || !a.agentId) throw new Error("این عضو فعال نیست.");
  return a;
}

// =====================================================
//  جدول اکشن‌ها
// =====================================================

const API_ACTIONS = {
  me:            { fn: apiMe_, manager: true },
  leads:         { fn: apiLeads_, manager: true },
  lead:          { fn: apiLead_, manager: true },
  call:          { fn: apiCallAdd_, write: true },
  callEdit:      { fn: apiCallEdit_, write: true },
  calls:         { fn: apiCalls_, manager: true },
  myStats:       { fn: apiMyStats_, manager: true },
  poll:          { fn: apiPoll_ },
  tgLink:        { fn: apiTgLink_, write: true },
  tgUnlink:      { fn: apiTgUnlink_, write: true },

  dashboard:     { fn: apiDashboard_, admin: true, manager: true },
  team:          { fn: apiTeam_, admin: true, manager: true },
  agentGet:      { fn: apiAgentGet_, admin: true, manager: true },
  agentAdd:      { fn: apiAgentAdd_, admin: true, write: true },
  agentUpdate:   { fn: apiAgentUpdate_, admin: true, write: true },
  agentFree:     { fn: apiAgentFree_, admin: true, write: true },
  agentDelete:   { fn: apiAgentDelete_, admin: true, write: true },
  agentResetKey: { fn: apiAgentResetKey_, admin: true, write: true },
  assign:        { fn: apiAssign_, admin: true, write: true },
  assignText:    { fn: apiAssignText_, admin: true, write: true },
  bulkAssign:    { fn: apiBulkAssign_, admin: true, write: true },
  unassign:      { fn: apiUnassign_, admin: true, write: true },
  autoRun:       { fn: apiAutoRun_, admin: true, write: true },
  leadAdd:       { fn: apiLeadAdd_, admin: true, write: true },
  leadNote:      { fn: apiLeadNote_, admin: true, write: true },
  leadDelete:    { fn: apiLeadDelete_, admin: true, write: true },
  groupSave:     { fn: apiGroupSave_, admin: true, write: true },
  groupKey:      { fn: apiGroupKey_, admin: true, write: true },
  groupDelete:   { fn: apiGroupDelete_, admin: true, write: true },
  setSetting:    { fn: apiSetSetting_, admin: true, write: true },
  exportCsv:     { fn: apiExport_, admin: true },
  exportAll:     { fn: apiExportAll_, admin: true }
};

// =====================================================
//  گروه‌ها و مدیر گروه
// =====================================================

function getGroups_() {
  if (MEMO_ON && MEMO.groups) return MEMO.groups;
  let arr = [];
  try { arr = JSON.parse(getSetting_("GROUPS") || "[]"); } catch (e) { arr = []; }
  if (!Array.isArray(arr)) arr = [];
  if (MEMO_ON) MEMO.groups = arr;
  return arr;
}

function saveGroups_(arr) {
  setSetting_("GROUPS", JSON.stringify(arr));
  MEMO = {};
}

function groupById_(id) {
  const s = String(id || "");
  return getGroups_().find(function(g) { return g.id === s; }) || null;
}

// agentIdهای اعضای گروه مدیر گروه
function managerScope_(user) {
  const set = {};
  getAllAgents_().forEach(function(a) {
    if (a.group === user.group.id && a.agentId) set[a.agentId] = true;
  });
  return set;
}

function groupsView_(user) {
  const agents = getAllAgents_();
  if (user.role === "manager") {
    const g = user.group;
    return [{ id: g.id, name: g.name, count: agents.filter(function(a) { return a.group === g.id; }).length }];
  }
  return getGroups_().map(function(g) {
    return {
      id: g.id, name: g.name, mgrName: g.mgrName || "", mgrKey: g.mgrKey || "",
      count: agents.filter(function(a) { return a.group === g.id; }).length
    };
  });
}

function apiGroupSave_(user, p) {
  const name = String(p.name || "").trim().slice(0, 40);
  if (!name) throw new Error("اسم گروه رو بنویس.");
  const groups = getGroups_().slice();
  if (groups.some(function(g) { return g.name === name && g.id !== String(p.id || ""); })) throw new Error("گروهی با این اسم از قبل هست.");

  let g;
  if (p.id) {
    g = groups.filter(function(x) { return x.id === String(p.id); })[0];
    if (!g) throw new Error("گروه پیدا نشد.");
    g.name = name;
    if (p.mgrName !== undefined) g.mgrName = String(p.mgrName).trim().slice(0, 60);
  } else {
    if (groups.length >= 30) throw new Error("حداکثر ۳۰ گروه می‌شه ساخت.");
    let id = "G" + Utilities.getUuid().replace(/-/g, "").slice(0, 5).toUpperCase();
    while (groups.some(function(x) { return x.id === id; })) id = "G" + Utilities.getUuid().replace(/-/g, "").slice(0, 5).toUpperCase();
    g = { id: id, name: name, mgrName: String(p.mgrName || "").trim().slice(0, 60), mgrKey: generateAppKey_() };
    groups.push(g);
  }
  saveGroups_(groups);
  return { groups: groupsView_(user), id: g.id };
}

function apiGroupKey_(user, p) {
  const groups = getGroups_().slice();
  const g = groups.filter(function(x) { return x.id === String(p.id || ""); })[0];
  if (!g) throw new Error("گروه پیدا نشد.");
  g.mgrKey = generateAppKey_();
  saveGroups_(groups);
  return { groups: groupsView_(user), key: g.mgrKey };
}

function apiGroupDelete_(user, p) {
  const id = String(p.id || "");
  const groups = getGroups_().filter(function(x) { return x.id !== id; });
  if (groups.length === getGroups_().length) throw new Error("گروه پیدا نشد.");
  const sheet = getTeamSheet_();
  getAllAgents_().forEach(function(a) {
    if (a.group === id) sheet.getRange(a.rowNumber, TCOL.GROUP).setValue("");
  });
  saveGroups_(groups);
  return { groups: groupsView_(user) };
}

// وقتی اسم عضو عوض می‌شه، اسم توی سابقهٔ تماس‌هاش هم هماهنگ بشه
function renameAgentInCalls_(agentId, name) {
  if (!agentId) return;
  const sheet = getCallsSheet_();
  const n = sheet.getLastRow() - 1;
  if (n < 1) return;
  const ids = sheet.getRange(2, 4, n, 1).getValues();
  const range = sheet.getRange(2, 5, n, 1);
  const names = range.getValues();
  let changed = false;
  ids.forEach(function(r, i) {
    if (String(r[0]) === String(agentId) && names[i][0] !== name) { names[i][0] = name; changed = true; }
  });
  if (changed) range.setValues(names);
}

// =====================================================
//  اکشن‌های مشترک (مدیر، مدیر گروه و عضو تیم)
// =====================================================

function apiMe_(user) {
  const out = {
    role: user.role,
    name: user.name,
    business: getSetting_("BUSINESS_NAME"),
    dateMode: getSetting_("DATE_MODE") === "gregorian" ? "gregorian" : "jalali",
    tz: tz_(),
    version: APP.VERSION
  };
  if (user.role === "manager") {
    out.group = user.group.name;
    out.groupId = user.group.id;
  } else if (user.role === "agent") {
    out.no = user.agent.no;
    out.code = user.agent.code;
    out.tgLinked = !!notifyTarget_(user.agent);
    out.tgNative = isTgId_(user.agent.agentId);
  } else {
    out.appUrl = appUrl_();
    out.auto = { on: getSetting_("AUTO_ASSIGN") === "true", batch: Number(getSetting_("AUTO_BATCH") || 4) };
    out.notify = getSetting_("NOTIFY_CALLS") !== "false";
  }
  return out;
}

function apiLeads_(user, p) {
  const admin = user.role === "admin";
  const idx = agentsIndex_();
  const lastMap = lastCallMap_(getAllCalls_());
  let leads = getAllLeads_().filter(function(l) { return matchStatus_(l, String(p.filter || "all")); });

  if (user.role === "manager") {
    const scope = managerScope_(user);
    leads = leads.filter(function(l) { return l.assignedTo && scope[l.assignedTo]; });
    if (p.agent && p.agent !== "none") {
      const mag = idx.byCode[String(p.agent)];
      leads = mag && scope[mag.agentId] ? leads.filter(function(l) { return l.assignedTo === mag.agentId; }) : [];
    }
  } else if (!admin) {
    leads = leads.filter(function(l) { return l.assignedTo === user.id; });
  } else if (p.agent === "none") {
    leads = leads.filter(function(l) { return !l.assignedTo; });
  } else if (p.agent) {
    const ag = idx.byCode[String(p.agent)];
    leads = ag ? leads.filter(function(l) { return l.assignedTo === ag.agentId; }) : [];
  }

  if (p.range && p.range !== "all") {
    const b = rangeBounds_(p.range);
    leads = leads.filter(function(l) { return inBounds_(toMs_(l.createdAt), b); });
  }

  const q = normalizeDigits_(String(p.q || "")).toLowerCase().replace(/^[@#]/, "").trim();
  if (q) {
    leads = leads.filter(function(l) {
      return l.name.toLowerCase().indexOf(q) !== -1 ||
        normalizeDigits_(l.phone).indexOf(q) !== -1 ||
        l.city.toLowerCase().indexOf(q) !== -1 ||
        (/^\d+$/.test(q) && String(l.seq) === q) ||
        (admin && l.username.toLowerCase().indexOf(q) !== -1);
    });
  }

  if (p.sort === "call") {
    leads.sort(function(a, b) {
      const pa = a.status === "assigned" ? 0 : 1;
      const pb = b.status === "assigned" ? 0 : 1;
      return pa !== pb ? pa - pb : a.seq - b.seq;
    });
  } else if (p.sort === "old") {
    leads.sort(function(a, b) { return a.seq - b.seq; });
  } else {
    leads.sort(function(a, b) { return b.seq - a.seq; });
  }

  const size = Math.max(5, Math.min(Number(p.size || 30), 100));
  const page = Math.max(0, Number(p.page || 0));
  const total = leads.length;
  const items = leads.slice(page * size, page * size + size).map(function(l) {
    return leadView_(l, idx, lastMap[l.leadId], admin);
  });
  return { items: items, total: total, page: page, size: size };
}

function apiLead_(user, p) {
  const admin = user.role === "admin";
  const lead = getLeadById_(p.leadId);
  if (!lead) throw new Error("درخواست پیدا نشد.");
  if (user.role === "manager") {
    if (!lead.assignedTo || !managerScope_(user)[lead.assignedTo]) throw new Error("این مورد مربوط به گروه تو نیست.");
  } else if (!admin && lead.assignedTo !== user.id) throw new Error("این مورد به تو اختصاص داده نشده.");

  const idx = agentsIndex_();
  const calls = getAllCalls_().filter(function(c) { return c.leadId === lead.leadId; });
  const last = calls[calls.length - 1];
  return {
    lead: leadView_(lead, idx, last, admin),
    history: calls.map(function(c) {
      return {
        id: c.callId, at: toMs_(c.createdAt), agentName: c.agentName, outcome: c.outcome, note: c.note,
        editedAt: c.editedAt ? toMs_(c.editedAt) : 0,
        visitAt: c.visitAt || 0,
        canEdit: admin || c.agentId === user.id
      };
    })
  };
}

function saveCallCore_(actor, lead, outcome, note, visitAt) {
  const callId = "C" + Utilities.getUuid().replace(/-/g, "").slice(0, 6).toUpperCase();
  const now = new Date();

  getCallsSheet_().appendRow([callId, lead.leadId, lead.name, String(actor.id), actor.name, outcome, note, now, "", visitAt ? new Date(visitAt) : "", ""]);

  const attempt = Number(lead.callsCount || 0) + 1;
  const sheet = getSheet_(APP.SHEETS.LEADS);
  sheet.getRange(lead.rowNumber, COL.STATUS).setValue(outcome);
  sheet.getRange(lead.rowNumber, COL.LAST_OUTCOME).setValue(outcome);
  sheet.getRange(lead.rowNumber, COL.CALLS_COUNT).setValue(attempt);
  sheet.getRange(lead.rowNumber, COL.UPDATED).setValue(now);

  const adminId = getSetting_("ADMIN_ID");
  if (actor.agent && adminId && getSetting_("NOTIFY_CALLS") !== "false") {
    const st = STATUSES[outcome];
    try {
      sendMessage_(
        adminId,
        "📞 گزارش تماس (اپ)\n\n" +
        "عضو تیم: " + agentLabel_(actor.agent) + "\n" +
        "مشتری: #" + lead.seq + " " + lead.name + " (" + lead.phone + ")\n" +
        "نتیجه: " + st.emoji + " " + st.label + " (تماس شماره " + attempt + ")\n" +
        "🕒 " + formatDateTime_(now) +
        (visitAt ? "\n📅 زمان مشاوره: " + formatDateTime_(new Date(visitAt)) : "") + (note ? "\nیادداشت: " + note : ""),
        { inline_keyboard: [[{ text: "👁 مشاهده مورد", callback_data: "ld:" + lead.leadId }]] }
      );
    } catch (e) {}
  }
  return attempt;
}

// تاریخ مشاوره (میلی‌ثانیه): باید معتبر و نه خیلی قدیمی و نه بیش از دو سال بعد باشه
function parseVisitAt_(outcome, p) {
  if (outcome !== "visit") return 0;
  const ms = Number(p.visitAt);
  if (!ms || isNaN(ms)) throw new Error("برای وقت مشاوره تاریخ رو انتخاب کن.");
  const now = Date.now();
  if (ms < now - 24 * 3600 * 1000) throw new Error("تاریخ مشاوره گذشته‌ست.");
  if (ms > now + 730 * 24 * 3600 * 1000) throw new Error("تاریخ مشاوره خیلی دوره.");
  return ms;
}

function apiCallAdd_(user, p) {
  const outcome = String(p.outcome || "");
  if (OUTCOME_KEYS.indexOf(outcome) === -1) throw new Error("نتیجه تماس نامعتبره.");

  const lead = getLeadById_(p.leadId);
  if (!lead) throw new Error("درخواست پیدا نشد.");
  const admin = user.role === "admin";
  if (!admin && lead.assignedTo !== user.id) throw new Error("این مورد به تو اختصاص داده نشده.");

  const note = String(p.note || "").trim().slice(0, 500);
  const visitAt = parseVisitAt_(outcome, p);
  saveCallCore_({ id: user.id, name: admin ? "مدیر" : user.name, agent: admin ? null : user.agent }, lead, outcome, note, visitAt);

  const out = { saved: true, at: Date.now() };
  if (!admin) {
    const next = nextLeadFor_(user.id);
    out.nextId = next ? next.leadId : "";
    out.next = next ? apiLead_(user, { leadId: next.leadId }) : null;
  }
  return out;
}

function apiCallEdit_(user, p) {
  const outcome = String(p.outcome || "");
  if (OUTCOME_KEYS.indexOf(outcome) === -1) throw new Error("نتیجه تماس نامعتبره.");
  const admin = user.role === "admin";

  const calls = getAllCalls_();
  const call = calls.filter(function(c) { return c.callId === String(p.callId || ""); })[0];
  if (!call) throw new Error("تماس پیدا نشد.");
  if (!admin && call.agentId !== user.id) throw new Error("فقط تماس‌های خودت رو می‌تونی ویرایش کنی.");

  const lead = getLeadById_(call.leadId);
  if (!lead) throw new Error("درخواست پیدا نشد.");
  if (!admin && lead.assignedTo !== user.id) throw new Error("این مورد دیگه به تو اختصاص نداره.");

  const note = String(p.note || "").trim().slice(0, 500);
  const sheet = getCallsSheet_();
  const ids = sheet.getRange(2, 1, Math.max(1, sheet.getLastRow() - 1), 1).getValues();
  let row = 0;
  for (let i = 0; i < ids.length; i++) { if (String(ids[i][0]) === call.callId) { row = i + 2; break; } }
  if (!row) throw new Error("تماس پیدا نشد.");

  const visitAt = parseVisitAt_(outcome, p);
  const now = new Date();
  sheet.getRange(row, 6).setValue(outcome);
  sheet.getRange(row, 7).setValue(note);
  sheet.getRange(row, 9).setValue(now);
  sheet.getRange(row, 10).setValue(visitAt ? new Date(visitAt) : "");
  sheet.getRange(row, 11).setValue("");

  // اگر آخرین تماسِ این شماره ویرایش شد، وضعیت شماره هم هماهنگ بشه
  const mine = calls.filter(function(c) { return c.leadId === lead.leadId; });
  if (mine[mine.length - 1].callId === call.callId) {
    const ls = getSheet_(APP.SHEETS.LEADS);
    ls.getRange(lead.rowNumber, COL.STATUS).setValue(outcome);
    ls.getRange(lead.rowNumber, COL.LAST_OUTCOME).setValue(outcome);
    ls.getRange(lead.rowNumber, COL.UPDATED).setValue(now);
  }

  const adminId = getSetting_("ADMIN_ID");
  if (!admin && adminId && getSetting_("NOTIFY_CALLS") !== "false") {
    const st = STATUSES[outcome];
    try {
      sendMessage_(
        adminId,
        "✏️ ویرایش نتیجه تماس (اپ)\n\n" +
        "عضو تیم: " + agentLabel_(user.agent) + "\n" +
        "مشتری: #" + lead.seq + " " + lead.name + " (" + lead.phone + ")\n" +
        "نتیجه جدید: " + st.emoji + " " + st.label + (visitAt ? " — " + formatDateTime_(new Date(visitAt)) : "") + "\n" +
        "🕒 " + formatDateTime_(now) + (note ? "\nیادداشت: " + note : ""),
        { inline_keyboard: [[{ text: "👁 مشاهده مورد", callback_data: "ld:" + lead.leadId }]] }
      );
    } catch (e) {}
  }
  return { saved: true, at: now.getTime() };
}

function apiCalls_(user, p) {
  const admin = user.role === "admin";
  const idx = agentsIndex_();
  const range = ["today", "yday", "week", "all"].indexOf(p.range) !== -1 ? p.range : "today";
  const b = rangeBounds_(range);

  let calls = getAllCalls_().filter(function(c) { return inBounds_(toMs_(c.createdAt), b); });
  if (user.role === "manager") {
    const scope = managerScope_(user);
    calls = calls.filter(function(c) { return scope[c.agentId]; });
    if (p.agent) {
      const mag = idx.byCode[String(p.agent)];
      calls = mag && scope[mag.agentId] ? calls.filter(function(c) { return c.agentId === mag.agentId; }) : [];
    }
  } else if (!admin) {
    calls = calls.filter(function(c) { return c.agentId === user.id; });
  } else if (p.agent) {
    const ag = idx.byCode[String(p.agent)];
    calls = ag ? calls.filter(function(c) { return c.agentId === ag.agentId; }) : [];
  }
  if (p.outcome) {
    calls = calls.filter(function(c) { return c.outcome === p.outcome; });
    if (p.latest) {
      // فقط شماره‌هایی که «آخرین» نتیجه‌شون همینه
      const lastMap = lastCallMap_(getAllCalls_());
      calls = calls.filter(function(c) { return lastMap[c.leadId] && lastMap[c.leadId].callId === c.callId; });
    }
  }

  calls = calls.slice().reverse();
  const size = Math.max(5, Math.min(Number(p.size || 30), 100));
  const page = Math.max(0, Number(p.page || 0));
  const byId = leadsById_(getAllLeads_());
  return {
    items: calls.slice(page * size, page * size + size).map(function(c) { return callView_(c, byId, idx); }),
    total: calls.length,
    page: page,
    size: size
  };
}

function apiMyStats_(user, p) {
  if (user.role !== "agent") return apiDashboard_(user);
  const leads = getAllLeads_();
  const calls = getAllCalls_();
  const m = teamStatsMap_(leads, calls)[user.id];
  const v = agentView_(user.agent, m, false);

  // برای اعلان داخل اپ: آخرین زمان اختصاص و تعداد شماره‌های تازه
  const since = Number(p && p.since) || 0;
  let newest = 0, fresh = 0;
  leads.forEach(function(l) {
    if (l.assignedTo !== user.id || PENDING_STATUSES.indexOf(l.status) === -1) return;
    const at = toMs_(l.assignedAt);
    if (at > newest) newest = at;
    if (since && at > since) fresh++;
  });
  v.newest = newest;
  v.fresh = fresh;
  return v;
}

// پولینگ سبک: فقط شیت درخواست‌ها خونده می‌شه
function apiPoll_(user, p) {
  if (user.role !== "agent") return { pending: 0, newest: 0, fresh: 0, visits: [] };
  const since = Number(p && p.since) || 0;
  let pending = 0, newest = 0, fresh = 0;
  const visits = [];
  const lastVisit = {};
  getAllCalls_().forEach(function(c) { lastVisit[c.leadId] = c; });
  getAllLeads_().forEach(function(l) {
    if (l.assignedTo === user.id && l.status === "visit") {
      const lc = lastVisit[l.leadId];
      if (lc && lc.outcome === "visit" && lc.visitAt) visits.push({ id: l.leadId, seq: l.seq, name: l.name, at: lc.visitAt, call: lc.callId });
    }
    if (l.assignedTo !== user.id || PENDING_STATUSES.indexOf(l.status) === -1) return;
    pending++;
    const at = toMs_(l.assignedAt);
    if (at > newest) newest = at;
    if (since && at > since) fresh++;
  });
  visits.sort(function(x, y) { return x.at - y.at; });
  return { pending: pending, newest: newest, fresh: fresh, visits: visits.slice(0, 50) };
}

function apiTgLink_(user) {
  if (user.role !== "agent") throw new Error("فقط برای اعضای تیم.");
  const bot = getBotUsername_();
  if (!bot) throw new Error("نام ربات پیدا نشد؛ مدیر باید ربات رو راه‌اندازی کنه.");
  const token = Utilities.getUuid().replace(/-/g, "").slice(0, 16);
  CacheService.getScriptCache().put("tglink_" + token, user.agent.code, 1800);
  return { url: "https://t.me/" + bot + "?start=link_" + token };
}

function apiTgUnlink_(user) {
  if (user.role !== "agent") throw new Error("فقط برای اعضای تیم.");
  if (isTgId_(user.agent.agentId)) throw new Error("حساب تو از قبل تلگرامیه و جدا نمی‌شه.");
  getTeamSheet_().getRange(user.agent.rowNumber, TCOL.TG).setValue("");
  MEMO = {};
  return { ok: true };
}

// دریافت لینک اتصال در ربات
function linkTelegram_(message, token) {
  const chatId = String(message.chat.id);
  const code = CacheService.getScriptCache().get("tglink_" + String(token || "").trim());
  const agent = code ? getAgentByCode_(code) : null;
  if (!agent || agent.status !== "active") {
    sendMessage_(chatId, "لینک اتصال معتبر نیست یا منقضی شده. توی اپ دوباره «اتصال تلگرام» رو بزن.");
    return;
  }
  getTeamSheet_().getRange(agent.rowNumber, TCOL.TG).setNumberFormat("@").setValue(chatId);
  CacheService.getScriptCache().remove("tglink_" + token);
  MEMO = {};
  sendMessage_(chatId, "✅ تلگرامت به پنل وصل شد، " + agent.name + ".\nاز این به بعد وقتی شماره جدید بهت بدن همین‌جا خبر می‌گیری.");
  const adminId = getSetting_("ADMIN_ID");
  if (adminId) sendMessage_(adminId, "🔔 " + agent.name + " (عضو شماره " + agent.no + ") تلگرامش رو به اپ وصل کرد.");
}

// =====================================================
//  فقط مدیر
// =====================================================

function apiDashboard_(user) {
  let leads = getAllLeads_();
  let calls = getAllCalls_();
  let scope = null;
  if (user.role === "manager") {
    scope = managerScope_(user);
    leads = leads.filter(function(l) { return l.assignedTo && scope[l.assignedTo]; });
    calls = calls.filter(function(c) { return scope[c.agentId]; });
  }
  const idx = agentsIndex_();
  const today = rangeBounds_("today");
  const week = rangeBounds_("week");

  const counts = {};
  Object.keys(STATUSES).forEach(function(k) { counts[k] = 0; });
  let newToday = 0;
  let newWeek = 0;
  leads.forEach(function(l) {
    if (counts[l.status] !== undefined) counts[l.status]++;
    const ms = toMs_(l.createdAt);
    if (inBounds_(ms, today)) newToday++;
    if (inBounds_(ms, week)) newWeek++;
  });

  let callsToday = 0;
  let callsWeek = 0;
  calls.forEach(function(c) {
    const ms = toMs_(c.createdAt);
    if (inBounds_(ms, today)) callsToday++;
    if (inBounds_(ms, week)) callsWeek++;
  });

  const stats = teamStatsMap_(leads, calls);
  const agents = getAllAgents_().filter(function(a) { return a.status === "active" && a.agentId && (!scope || scope[a.agentId]); });
  const top = agents.map(function(a) { return agentView_(a, stats[a.agentId], false); })
    .sort(function(x, y) { return y.today - x.today || y.pending - x.pending; })
    .slice(0, 6);

  const byId = leadsById_(leads);
  const recent = calls.slice(-8).reverse().map(function(c) { return callView_(c, byId, idx); });

  return {
    totals: {
      all: leads.length,
      today: newToday,
      week: newWeek,
      unassigned: counts.new,
      pending: counts.assigned + counts.no_answer + counts.followup,
      attention: counts.no_answer + counts.followup,
      done: counts.called + counts.deposit + counts.not_interested,
      visit: counts.visit || 0
    },
    byStatus: counts,
    calls: { today: callsToday, week: callsWeek, all: calls.length },
    top: top,
    recent: recent,
    activeAgents: agents.length,
    auto: scope ? null : { on: getSetting_("AUTO_ASSIGN") === "true", batch: Number(getSetting_("AUTO_BATCH") || 4) }
  };
}

function apiTeam_(user) {
  const stats = teamStatsMap_(getAllLeads_(), getAllCalls_());
  let agents = getAllAgents_();
  if (user && user.role === "manager") agents = agents.filter(function(a) { return a.group === user.group.id; });
  return {
    agents: agents
      .sort(function(a, b) { return a.no - b.no; })
      .map(function(a) { return agentView_(a, stats[a.agentId], false); }),
    groups: groupsView_(user)
  };
}

function apiAgentGet_(user, p) {
  const a = agentFromPayload_(p);
  if (user.role === "manager" && a.group !== user.group.id) throw new Error("این عضو تو گروه تو نیست.");
  const leads = getAllLeads_();
  const calls = getAllCalls_();
  const stats = teamStatsMap_(leads, calls)[a.agentId];
  const idx = agentsIndex_();
  const byId = leadsById_(leads);
  const recent = calls.filter(function(c) { return c.agentId === a.agentId; })
    .slice(-8).reverse().map(function(c) { return callView_(c, byId, idx); });
  return { agent: agentView_(a, stats, user.role === "admin"), recent: recent };
}

function apiAgentAdd_(user, p) {
  const name = String(p.name || "").trim().slice(0, 60);
  if (!name) throw new Error("اسم عضو رو بنویس.");
  const groupId = p.group ? String(p.group) : "";
  if (groupId && !groupById_(groupId)) throw new Error("گروه پیدا نشد.");

  const sheet = getTeamSheet_();
  const agents = getAllAgents_();
  const codes = agents.map(function(a) { return a.code; });
  const no = agents.reduce(function(m, a) { return Math.max(m, a.no); }, 0) + 1;
  let code = generateClaimCode_();
  while (codes.indexOf(code) !== -1) code = generateClaimCode_();

  const row = sheet.getLastRow() + 1;
  sheet.getRange(row, TCOL.ID).setNumberFormat("@");
  sheet.getRange(row, TCOL.CODE).setNumberFormat("@");
  sheet.getRange(row, 1, 1, TEAM_HEADERS.length).setValues([[
    "A" + code, name, "", code, "active", new Date(), new Date(), no, generateAppKey_(), "", groupId
  ]]);
  MEMO = {};
  return { agent: agentView_(getAgentByCode_(code), null, true) };
}

function apiAgentUpdate_(user, p) {
  const a = agentFromPayload_(p);
  const sheet = getTeamSheet_();
  if (p.name !== undefined) {
    const name = String(p.name).trim().slice(0, 60);
    if (!name) throw new Error("اسم خالیه.");
    sheet.getRange(a.rowNumber, TCOL.NAME).setValue(name);
    if (name !== a.name) renameAgentInCalls_(a.agentId, name);
  }
  if (p.group !== undefined) {
    const gid = String(p.group || "");
    if (gid && !groupById_(gid)) throw new Error("گروه پیدا نشد.");
    sheet.getRange(a.rowNumber, TCOL.GROUP).setValue(gid);
  }
  if (p.status !== undefined) {
    if (["active", "disabled"].indexOf(p.status) === -1) throw new Error("وضعیت نامعتبره.");
    if (!a.agentId) throw new Error("این عضو هنوز وارد نشده.");
    sheet.getRange(a.rowNumber, TCOL.STATUS).setValue(p.status);
  }
  return { ok: true };
}

function releaseAgentLeads_(agent) {
  const sheet = getSheet_(APP.SHEETS.LEADS);
  const now = new Date();
  let n = 0;
  getAllLeads_().forEach(function(l) {
    if (l.assignedTo === agent.agentId && PENDING_STATUSES.indexOf(l.status) !== -1) {
      sheet.getRange(l.rowNumber, COL.STATUS).setValue("new");
      sheet.getRange(l.rowNumber, COL.ASSIGNED, 1, 2).setValues([["", ""]]);
      sheet.getRange(l.rowNumber, COL.UPDATED).setValue(now);
      n++;
    }
  });
  return n;
}

function apiAgentFree_(user, p) {
  const a = agentFromPayload_(p);
  return { released: a.agentId ? releaseAgentLeads_(a) : 0 };
}

function apiAgentDelete_(user, p) {
  const a = agentFromPayload_(p);
  const released = a.agentId ? releaseAgentLeads_(a) : 0;
  getTeamSheet_().deleteRow(a.rowNumber);
  return { released: released };
}

function apiAgentResetKey_(user, p) {
  const a = agentFromPayload_(p);
  const key = generateAppKey_();
  getTeamSheet_().getRange(a.rowNumber, TCOL.KEY).setValue(key);
  return { key: key };
}

function apiAssign_(user, p) {
  const agent = activeAgentFromPayload_(p);
  const ids = Array.isArray(p.leadIds) ? p.leadIds : [];
  if (!ids.length) throw new Error("هیچ موردی انتخاب نشده.");
  if (ids.length > 200) throw new Error("در هر بار حداکثر ۲۰۰ مورد.");

  const byId = leadsById_(getAllLeads_());
  const done = [];
  let skipped = 0;
  ids.forEach(function(id) {
    const l = byId[id];
    if (!l || DONE_STATUSES.indexOf(l.status) !== -1) { skipped++; return; }
    assignLeadTo_(l, agent);
    done.push(l);
  });
  notifyAgentAssigned_(agent, done);
  return { assigned: done.length, skipped: skipped, agentName: agent.name };
}

function apiUnassign_(user, p) {
  const ids = Array.isArray(p.leadIds) ? p.leadIds : [];
  const byId = leadsById_(getAllLeads_());
  let n = 0;
  ids.forEach(function(id) {
    const l = byId[id];
    if (l && l.assignedTo && PENDING_STATUSES.indexOf(l.status) !== -1) {
      assignLeadTo_(l, null);
      if (l.status !== "assigned") {
        // اگه نتیجه‌ای ثبت شده بود، وضعیت رو به «جدید» برگردون
        getSheet_(APP.SHEETS.LEADS).getRange(l.rowNumber, COL.STATUS).setValue("new");
      }
      n++;
    }
  });
  return { unassigned: n };
}

function apiBulkAssign_(user, p) {
  const agent = activeAgentFromPayload_(p);
  const n = Math.max(1, Math.min(Number(p.count || 0), 100));
  const pool = getUnassignedLeads_().sort(function(a, b) { return a.seq - b.seq; }).slice(0, n);
  pool.forEach(function(l) { assignLeadTo_(l, agent); });
  notifyAgentAssigned_(agent, pool);
  return { assigned: pool.length, agentName: agent.name, seqs: pool.map(function(l) { return l.seq; }) };
}

function apiAssignText_(user, p) {
  const text = String(p.text || "");
  const bySeq = {};
  getAllLeads_().forEach(function(l) { if (l.seq) bySeq[l.seq] = l; });

  const errors = [];
  const plan = [];
  text.split(/\r?\n/).forEach(function(raw) {
    const line = raw.trim();
    if (!line) return;
    const i = line.search(/[:：=]/);
    if (i === -1) { errors.push("فرمت این خط درست نیست: " + line.slice(0, 40)); return; }
    const res = resolveAgentSelector_(line.slice(0, i));
    if (res.error) { errors.push(res.error); return; }
    plan.push({ agent: res.agent, rest: line.slice(i + 1) });
  });
  if (!plan.length) throw new Error(errors.join(" | ") || "چیزی برای اختصاص پیدا نشد.");

  const used = {};
  const results = plan.map(function(item) {
    const parsed = parseSeqTokens_(item.rest);
    const r = { agent: item.agent, ok: [], skipped: [], missing: [], dup: [], bad: parsed.bad };
    parsed.seqs.forEach(function(n) {
      if (used[n]) { r.dup.push(n); return; }
      const lead = bySeq[n];
      if (!lead) { r.missing.push(n); return; }
      if (DONE_STATUSES.indexOf(lead.status) !== -1) { r.skipped.push(n); return; }
      used[n] = true;
      r.ok.push(lead);
    });
    return r;
  });

  const total = results.reduce(function(s, r) { return s + r.ok.length; }, 0);
  if (total > 200) throw new Error("در هر بار حداکثر ۲۰۰ مورد.");

  const out = results.map(function(r) {
    r.ok.forEach(function(l) { assignLeadTo_(l, r.agent); });
    notifyAgentAssigned_(r.agent, r.ok);
    return {
      agentName: r.agent.name, agentNo: r.agent.no,
      ok: r.ok.map(function(l) { return l.seq; }),
      skipped: r.skipped, missing: r.missing, dup: r.dup, bad: r.bad
    };
  });
  return { results: out, errors: errors, total: total };
}

function apiAutoRun_(user, p) {
  const agents = activeAgentsSorted_();
  if (!agents.length) throw new Error("هنوز عضو فعالی نداری.");
  const pool = getUnassignedLeads_().sort(function(a, b) { return a.seq - b.seq; });
  if (!pool.length) throw new Error("شماره‌ی بدون مسئول وجود نداره.");

  const slice = pool.slice(0, Math.max(1, Math.min(Number(p.limit || 100), 200)));
  const given = {};
  const order = [];
  slice.forEach(function(l) {
    const agent = pickAutoAgent_();
    if (!agent) return;
    assignLeadTo_(l, agent);
    if (!given[agent.agentId]) { given[agent.agentId] = { agent: agent, leads: [] }; order.push(agent.agentId); }
    given[agent.agentId].leads.push(l);
  });

  const groups = order.map(function(id) {
    const g = given[id];
    notifyAgentAssigned_(g.agent, g.leads);
    return { agentName: g.agent.name, agentNo: g.agent.no, seqs: g.leads.map(function(l) { return l.seq; }) };
  });
  MEMO = {};
  return { total: slice.length, groups: groups, remaining: getUnassignedLeads_().length };
}

// افزودن دستیِ شماره توسط مدیر. هر خط: «نام شماره» یا فقط «شماره» (جداکننده: فاصله، کاما، ویرگول فارسی یا تب)
function apiLeadAdd_(user, p) {
  const lines = String(p.text || "").split(/\r?\n/).map(function(s) { return s.trim(); }).filter(Boolean);
  if (!lines.length) throw new Error("هیچ شماره‌ای وارد نشده.");
  if (lines.length > 300) throw new Error("در هر بار حداکثر ۳۰۰ خط.");

  const keyOf = function(ph) { return String(ph).replace(/\D/g, "").slice(-10); };
  const known = {};
  getAllLeads_().forEach(function(l) { const k = keyOf(l.phone); if (k) known[k] = l; });

  const added = [], dup = [], bad = [];
  const note = String(p.note || "").trim().slice(0, 200);
  lines.forEach(function(line) {
    const norm = normalizeDigits_(line);
    const m = norm.match(/\+?\d[\d\s\-()]{8,17}\d/);
    const phone = m ? normalizePhone_(m[0]) : null;
    if (!phone) { bad.push(line.slice(0, 40)); return; }
    const name = norm.replace(m[0], " ").replace(/[،,;\t|:：]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80) || "بدون نام";
    const key = keyOf(phone);
    if (known[key] && !p.allowDup) { dup.push({ phone: phone, seq: known[key].seq, name: known[key].name }); return; }
    const lead = saveLead_({ id: "admin", username: "" }, { name: name, phone: phone, city: "", goal: note });
    known[key] = lead;
    added.push({ id: lead.leadId, seq: lead.seq, name: lead.name, phone: lead.phone });
  });
  MEMO = {};
  return { added: added, dup: dup, bad: bad };
}

function apiLeadNote_(user, p) {
  const lead = getLeadById_(p.leadId);
  if (!lead) throw new Error("درخواست پیدا نشد.");
  updateLeadField_(lead.leadId, COL.NOTE, String(p.note || "").slice(0, 500));
  return { ok: true };
}

function apiLeadDelete_(user, p) {
  deleteLead_(p.leadId);
  return { ok: true };
}

function apiSetSetting_(user, p) {
  const key = String(p.key || "");
  const value = String(p.value);
  if (key === "DATE_MODE" && ["jalali", "gregorian"].indexOf(value) !== -1) {
    setSetting_(key, value);
  } else if (key === "NOTIFY_CALLS" && ["true", "false"].indexOf(value) !== -1) {
    setSetting_(key, value);
  } else if (key === "AUTO_ASSIGN" && ["true", "false"].indexOf(value) !== -1) {
    setSetting_(key, value);
  } else if (key === "AUTO_BATCH") {
    const n = parseNumber_(value);
    if (n === null || n < 1 || n > 20) throw new Error("عدد بین ۱ تا ۲۰ بنویس.");
    setSetting_(key, String(Math.floor(n)));
  } else {
    throw new Error("تنظیم نامعتبره.");
  }
  return { ok: true };
}

// ---------- خروجی CSV ----------

function csvString_(header, rows) {
  const lines = [header.map(csvCell_).join(",")];
  rows.forEach(function(r) { lines.push(r.map(csvCell_).join(",")); });
  return "﻿" + lines.join("\r\n");
}

function apiExport_(user, p) {
  const kind = String(p.kind || "leads");
  const idx = agentsIndex_();
  let leads = getAllLeads_();
  let calls = getAllCalls_();
  const byId = leadsById_(leads);
  let tag = "";

  if (p.agent) {
    const ag = idx.byCode[String(p.agent)];
    if (!ag) throw new Error("عضو پیدا نشد.");
    leads = leads.filter(function(l) { return l.assignedTo === ag.agentId; });
    calls = calls.filter(function(c) { return c.agentId === ag.agentId; });
    tag = "_agent" + ag.no;
  }
  if (p.range && p.range !== "all") {
    const b = rangeBounds_(p.range);
    leads = leads.filter(function(l) { return inBounds_(toMs_(l.createdAt), b); });
    calls = calls.filter(function(c) { return inBounds_(toMs_(c.createdAt), b); });
    tag += "_" + p.range;
  }

  if (kind === "calls") {
    const rows = calls.map(function(c) {
      const l = byId[c.leadId];
      const ag = idx.byId[c.agentId];
      const st = STATUSES[c.outcome];
      return [
        formatDateTime_(c.createdAt), c.callId, l ? l.seq : "", c.leadName,
        l ? '="' + l.phone + '"' : "", c.agentName, ag ? ag.no : "",
        st ? st.label : c.outcome, c.note
      ];
    });
    return {
      filename: "calls" + tag + ".csv", count: rows.length,
      csv: csvString_(["تاریخ و ساعت تماس", "کد تماس", "کد شماره", "مشتری", "تلفن", "عضو تیم", "شماره عضو", "نتیجه", "یادداشت"], rows)
    };
  }

  if (kind === "team") {
    const stats = teamStatsMap_(getAllLeads_(), getAllCalls_());
    const rows = getAllAgents_().filter(function(a) { return a.agentId; })
      .sort(function(a, b) { return a.no - b.no; })
      .map(function(a) {
        const s = stats[a.agentId] || { assigned: 0, pending: 0, today: 0, total: 0, by: emptyBy_(), last: 0 };
        return [
          a.no, a.name, AGENT_STATUS_LABELS[a.status] || a.status,
          a.joinedAt ? formatDateTime_(a.joinedAt) : "",
          s.assigned, s.pending, s.today, s.total,
          s.by.called, s.by.followup, s.by.no_answer, s.by.not_interested,
          s.last ? formatDateTime_(new Date(s.last)) : ""
        ];
      });
    return {
      filename: "team.csv", count: rows.length,
      csv: csvString_(["شماره عضو", "نام", "وضعیت", "تاریخ پیوستن", "اختصاص‌داده‌شده", "در انتظار", "تماس امروز", "کل تماس",
        "قرارداد بست", "نیاز به پیگیری", "جواب نداد", "انصراف", "آخرین تماس"], rows)
    };
  }

  // leads
  const callsByLead = {};
  calls.forEach(function(c) { (callsByLead[c.leadId] = callsByLead[c.leadId] || []).push(c); });
  const allCallsByLead = {};
  getAllCalls_().forEach(function(c) { (allCallsByLead[c.leadId] = allCallsByLead[c.leadId] || []).push(c); });

  const rows = leads.slice().sort(function(a, b) { return a.seq - b.seq; }).map(function(l) {
    const cs = allCallsByLead[l.leadId] || [];
    const first = cs[0];
    const last = cs[cs.length - 1];
    const ag = idx.byId[l.assignedTo];
    const st = STATUSES[l.status];
    const lastSt = last ? STATUSES[last.outcome] : null;
    return [
      l.seq, l.leadId, formatDateTime_(l.createdAt), l.name, '="' + l.phone + '"',
      l.age, l.city, l.goal,
      ag ? ag.name : "", ag ? ag.no : "",
      l.assignedAt ? formatDateTime_(l.assignedAt) : "",
      st ? st.label : l.status,
      cs.length,
      first ? formatDateTime_(first.createdAt) : "",
      last ? formatDateTime_(last.createdAt) : "",
      lastSt ? lastSt.label : "",
      last ? last.note : "",
      l.note
    ];
  });
  return {
    filename: "leads" + tag + ".csv", count: rows.length,
    csv: csvString_(["کد", "شناسه", "تاریخ ثبت", "نام", "تلفن", "سن", "شهر", "موضوع", "مسئول", "شماره عضو",
      "تاریخ اختصاص", "وضعیت", "تعداد تماس", "اولین تماس", "آخرین تماس", "نتیجه آخر", "یادداشت آخر", "یادداشت مدیر"], rows)
  };
}


// خروجی کامل داده‌ها (فقط مدیر) — برای انتقال به سرور جدید
function apiExportAll_(user, p) {
  const out = { version: APP.VERSION, exportedAt: new Date().toISOString(), sheets: {}, props: {} };
  [APP.SHEETS.SETTINGS, APP.SHEETS.LEADS, APP.SHEETS.TEAM, APP.SHEETS.CALLS].forEach(function(name) {
    const sheet = getDatabase_().getSheetByName(name);
    if (!sheet || sheet.getLastRow() < 1) { out.sheets[name] = []; return; }
    out.sheets[name] = sheet.getRange(1, 1, sheet.getLastRow(), Math.max(1, sheet.getLastColumn())).getValues();
  });
  const props = PropertiesService.getScriptProperties();
  ["ADMIN_APP_KEY", "BOT_USERNAME"].forEach(function(k) {
    const v = props.getProperty(k);
    if (v) out.props[k] = v;
  });
  return out;
}
