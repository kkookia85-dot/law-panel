// =====================================================
//  ربات ثبت درخواست مشاوره + مدیریت تیم تماس
//  نسخه 4.0.0 (با اپ موبایل)
// =====================================================

const APP = {
  VERSION: "4.3.0-law",
  SHEETS: {
    SETTINGS: "Settings",
    LEADS: "Leads",
    SESSIONS: "Sessions",
    TEAM: "Team",
    CALLS: "Calls"
  }
};

const LEAD_HEADERS = [
  "lead_id", "user_id", "username", "name", "age", "city", "goal",
  "phone", "status", "note", "created_at", "updated_at",
  "assigned_to", "assigned_at", "last_outcome", "calls_count", "seq"
];

const COL = {
  ID: 1, USER: 2, USERNAME: 3, NAME: 4, AGE: 5, CITY: 6, GOAL: 7,
  PHONE: 8, STATUS: 9, NOTE: 10, CREATED: 11, UPDATED: 12,
  ASSIGNED: 13, ASSIGNED_AT: 14, LAST_OUTCOME: 15, CALLS_COUNT: 16, SEQ: 17
};

const TEAM_HEADERS = ["agent_id", "name", "username", "invite_code", "status", "created_at", "joined_at", "no", "app_key", "tg_chat", "group_id"];
const TCOL = { ID: 1, NAME: 2, USERNAME: 3, CODE: 4, STATUS: 5, CREATED: 6, JOINED: 7, NO: 8, KEY: 9, TG: 10, GROUP: 11 };

const CALL_HEADERS = ["call_id", "lead_id", "lead_name", "agent_id", "agent_name", "outcome", "note", "created_at", "edited_at", "visit_at", "visit_notified"];

const STATUSES = {
  new: { label: "جدید (بدون مسئول)", emoji: "🆕" },
  assigned: { label: "اختصاص داده شده", emoji: "👤" },
  called: { label: "قرارداد وکالت بست", emoji: "✅" },
  deposit: { label: "بیعانه داد", emoji: "💰" },
  followup: { label: "نیاز به پیگیری", emoji: "🔁" },
  no_answer: { label: "جواب نداد", emoji: "📵" },
  visit: { label: "وقت مشاوره", emoji: "📅" },
  not_interested: { label: "انصراف", emoji: "❌" }
};

const OUTCOME_KEYS = ["called", "visit", "followup", "no_answer", "not_interested"];
const BOT_OUTCOME_KEYS = ["called", "followup", "no_answer", "not_interested"]; // بازدید نیاز به تاریخ داره و فقط توی اپ ثبت می‌شه
const PENDING_STATUSES = ["assigned", "no_answer", "followup"];
const DONE_STATUSES = ["called", "deposit", "not_interested"];
const ATTENTION_STATUSES = ["no_answer", "followup"];

const AGENT_STATUS_LABELS = {
  invited: "⏳ دعوت‌شده",
  active: "🟢 فعال",
  disabled: "⛔ غیرفعال"
};

// کارهایی که اعضای تیم اجازه دارن (بقیه فقط مدیر)
const AGENT_ACTIONS = ["ls", "ld", "rs", "ro", "nx", "cl"];

// برچسب دکمه‌های منو
const MENU = {
  NEW: "🆕 درخواست‌های جدید",
  ALL: "📋 همه درخواست‌ها",
  MANUAL: "📌 اختصاص دستی",
  AUTO: "🤖 اختصاص خودکار",
  CALLS: "📞 لیست تماس‌ها",
  ATTN: "🔁 نیازمند پیگیری",
  TEAM: "👥 تیم",
  REPORT: "📈 گزارش تیم",
  SEARCH: "🔍 جستجو",
  STATS: "📊 آمار",
  EXPORT: "📤 خروجی CSV",
  SETTINGS: "⚙️ تنظیمات",
  TEST: "📝 تست فرم",
  HEALTH: "🧪 بررسی سلامت ربات",
  A_PENDING: "⏳ در انتظار تماس",
  A_CALLS: "📞 تماس‌های من",
  A_DONE: "✅ انجام‌شده‌ها",
  A_STATS: "📊 عملکرد من"
};

const ADMIN_MENU_ROWS = [
  [MENU.NEW, MENU.ALL],
  [MENU.MANUAL, MENU.AUTO],
  [MENU.CALLS, MENU.ATTN],
  [MENU.TEAM, MENU.REPORT],
  [MENU.SEARCH, MENU.STATS],
  [MENU.EXPORT, MENU.SETTINGS],
  [MENU.TEST, MENU.HEALTH]
];
const AGENT_MENU_ROWS = [
  [MENU.A_PENDING, MENU.A_CALLS],
  [MENU.A_DONE, MENU.A_STATS]
];
const ADMIN_MENU_LABELS = [].concat.apply([], ADMIN_MENU_ROWS);
const AGENT_MENU_LABELS = [].concat.apply([], AGENT_MENU_ROWS);

const EDITABLE_SETTINGS = {
  name: ["BUSINESS_NAME", "نام مشاور / کسب‌وکار"],
  welcome: ["WELCOME_TEXT", "پیام خوش‌آمدگویی"],
  thanks: ["THANKS_TEXT", "پیام بعد از ثبت"],
  qname: ["Q_NAME", "سؤال نام"]
};

let SETTINGS_CACHE = null;

// کش موقت فقط برای درخواست‌های خواندنی اپ (در هر اجرا)
let MEMO_ON = false;
let MEMO = {};

// =====================================================
//  منوی داخل Google Sheet
// =====================================================

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("🤖 راه‌اندازی ربات مشاوره")
    .addItem("۱. ساخت / به‌روزرسانی دیتابیس", "setupProject")
    .addItem("۲. ثبت یا تغییر توکن ربات", "saveBotToken")
    .addSeparator()
    .addItem("۳. اتصال ربات بعد از Deploy", "connectWebhook")
    .addItem("بررسی اتصال ربات", "checkWebhook")
    .addSeparator()
    .addItem("نمایش کد مدیریت", "showClaimCode")
    .addItem("ساخت کد مدیریت جدید", "resetClaimCode")
    .addSeparator()
    .addItem("فعال‌سازی یادآور روزانه", "installDailyReminder")
    .addItem("🔑 ورود به اپ (کلید مدیر و آدرس)", "showAppAccess")
    .addItem("ساخت کلید جدید برای مدیر", "resetAdminAppKey")
    .addItem("قطع اتصال ربات", "disconnectWebhook")
    .addToUi();
}

function doGet() {
  try {
    let title = "مشاوره";
    try { title = getSetting_("BUSINESS_NAME") || title; } catch (e1) {}
    return HtmlService.createHtmlOutputFromFile("App")
      .setTitle(title)
      .addMetaTag("viewport", "width=device-width, initial-scale=1, viewport-fit=cover")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return HtmlService.createHtmlOutput(
      "Consult Bot is running. Version " + APP.VERSION + " (فایل App.html به پروژه اضافه نشده)"
    );
  }
}

function setupProject() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  PropertiesService.getScriptProperties().setProperty("SPREADSHEET_ID", ss.getId());
  SETTINGS_CACHE = null;

  ensureSheet_(APP.SHEETS.SETTINGS, ["key", "value"]);
  ensureSheet_(APP.SHEETS.LEADS, LEAD_HEADERS);
  ensureSheet_(APP.SHEETS.SESSIONS, [
    "user_id", "username", "first_name", "state", "data_json", "updated_at"
  ]);
  ensureSheet_(APP.SHEETS.TEAM, TEAM_HEADERS);
  ensureSheet_(APP.SHEETS.CALLS, CALL_HEADERS);

  // ستون‌های حساس به‌صورت متن، تا صفر اول و عددهای بلند خراب نشن
  const settings = getSheet_(APP.SHEETS.SETTINGS);
  settings.getRange(1, 2, settings.getMaxRows(), 1).setNumberFormat("@");
  const leads = getSheet_(APP.SHEETS.LEADS);
  leads.getRange(2, COL.PHONE, Math.max(1, leads.getMaxRows() - 1), 1).setNumberFormat("@");
  leads.getRange(2, COL.ASSIGNED, Math.max(1, leads.getMaxRows() - 1), 1).setNumberFormat("@");
  const team = getSheet_(APP.SHEETS.TEAM);
  team.getRange(2, TCOL.ID, Math.max(1, team.getMaxRows() - 1), 1).setNumberFormat("@");
  team.getRange(2, TCOL.CODE, Math.max(1, team.getMaxRows() - 1), 1).setNumberFormat("@");

  const defaults = {
    BUSINESS_NAME: "مشاوره من",
    WELCOME_TEXT: "سلام 👋 خوش اومدی. برای دریافت مشاوره حقوقی، فرم کوتاه رو پر کن تا باهات تماس بگیریم.",
    CONSENT_TEXT: "برای اینکه بتونیم باهات تماس بگیریم، چند تا اطلاعات و شماره تلفنت رو لازم داریم. " +
      "اطلاعاتت فقط برای تماس مشاوره استفاده می‌شه و جای دیگه‌ای منتشر نمی‌شه.\n\nموافقی ادامه بدیم؟",
    THANKS_TEXT: "✅ درخواستت ثبت شد. به‌زودی باهات تماس می‌گیریم. ممنون از اعتمادت 🌱",
    Q_NAME: "اسمت چیه؟ (نام و نام خانوادگی)",
    Q_AGE: "چند سالته؟ (فقط عدد)",
    Q_CITY: "تو کدوم شهر زندگی می‌کنی؟",
    Q_GOAL: "موضوع یا هدفت از مشاوره چیه؟ (کوتاه توضیح بده)",
    NOTIFY_CALLS: "true",
    AUTO_ASSIGN: "false",
    AUTO_BATCH: "4",
    AUTO_CUR_NO: "0",
    AUTO_CUR_COUNT: "0",
    DATE_MODE: "jalali",
    TIMEZONE: "Asia/Tehran",
    LEAD_SEQ: "0",
    GROUPS: "[]",
    ADMIN_ID: "",
    SETUP_DONE: "false",
    CLAIM_CODE: generateClaimCode_()
  };

  Object.keys(defaults).forEach(function(key) {
    if (getSetting_(key) === "") {
      setSetting_(key, defaults[key]);
    }
  });

  backfillSeq_();
  backfillAgentNos_();
  migrateOutcomes_();
  backfillAgentKeys_();
  ensureAdminKey_();
  styleSheets_();

  SpreadsheetApp.getActive().toast(
    "دیتابیس آماده شد. اگه نسخه قبلی رو داشتی، اطلاعات قبلی دست‌نخورده موند.",
    "آماده شد",
    8
  );
}

// به درخواست‌های قدیمی که کد ندارن، شماره ترتیبی می‌ده
function backfillSeq_() {
  const sheet = getSheet_(APP.SHEETS.LEADS);
  if (sheet.getLastRow() < 2) return;
  const range = sheet.getRange(2, COL.SEQ, sheet.getLastRow() - 1, 1);
  const values = range.getValues();
  let max = Number(getSetting_("LEAD_SEQ") || 0);
  values.forEach(function(r) { max = Math.max(max, Number(r[0] || 0)); });

  let changed = false;
  values.forEach(function(r) {
    if (!r[0]) { r[0] = ++max; changed = true; }
  });
  if (changed) range.setValues(values);
  setSetting_("LEAD_SEQ", String(max));
}

// به اعضای قدیمی شماره عضو می‌ده
function backfillAgentNos_() {
  const sheet = getTeamSheet_();
  if (sheet.getLastRow() < 2) return;
  const range = sheet.getRange(2, TCOL.NO, sheet.getLastRow() - 1, 1);
  const codes = sheet.getRange(2, TCOL.CODE, sheet.getLastRow() - 1, 1).getValues();
  const values = range.getValues();
  let max = 0;
  values.forEach(function(r) { max = Math.max(max, Number(r[0] || 0)); });

  let changed = false;
  values.forEach(function(r, i) {
    if (!r[0] && codes[i][0]) { r[0] = ++max; changed = true; }
  });
  if (changed) range.setValues(values);
}

function saveBotToken() {
  const ui = SpreadsheetApp.getUi();
  const result = ui.prompt(
    "ثبت توکن ربات",
    "توکنی که BotFather داده رو وارد کن. توکن داخل سلول‌های شیت ذخیره نمی‌شه.",
    ui.ButtonSet.OK_CANCEL
  );

  if (result.getSelectedButton() !== ui.Button.OK) return;

  const token = String(result.getResponseText() || "").trim();
  if (!/^\d+:[A-Za-z0-9_-]{20,}$/.test(token)) {
    ui.alert("فرمت توکن درست به نظر نمی‌رسه.");
    return;
  }

  PropertiesService.getScriptProperties().setProperty("BOT_TOKEN", token);
  PropertiesService.getScriptProperties().deleteProperty("BOT_USERNAME");
  ui.alert("توکن با موفقیت ثبت شد.");
}

function connectWebhook() {
  const ui = SpreadsheetApp.getUi();
  const token = getBotToken_();

  if (!token) {
    ui.alert("اول توکن ربات رو ثبت کن.");
    return;
  }

  const result = ui.prompt(
    "اتصال ربات",
    "آدرس Web App که به /exec ختم میشه رو وارد کن.",
    ui.ButtonSet.OK_CANCEL
  );

  if (result.getSelectedButton() !== ui.Button.OK) return;

  const webAppUrl = String(result.getResponseText() || "").trim();
  const validUrl = /^https:\/\/script\.google\.com\/macros\/s\/[^/]+\/exec$/.test(webAppUrl);

  if (!validUrl) {
    ui.alert("آدرس درست نیست.\n\nآدرس باید با https شروع بشه و به /exec ختم بشه.");
    return;
  }

  try {
    const testResponse = UrlFetchApp.fetch(webAppUrl, {
      method: "get",
      followRedirects: true,
      muteHttpExceptions: true
    });
    const statusCode = testResponse.getResponseCode();
    if (statusCode !== 200) {
      ui.alert(
        "این آدرس Web App فعال نیست.\n\nکد خطا: " + statusCode +
        "\n\nمطمئن شو دسترسی (Who has access) روی Anyone تنظیم شده."
      );
      return;
    }
  } catch (error) {
    ui.alert("امکان بازکردن آدرس Web App وجود نداره.\n\n" + error.message);
    return;
  }

  PropertiesService.getScriptProperties().setProperty("WEB_APP_URL", webAppUrl);

  const response = telegramRequest_("setWebhook", {
    url: webAppUrl,
    max_connections: 1,
    drop_pending_updates: true,
    allowed_updates: ["message", "callback_query"]
  });

  if (response.ok) {
    ui.alert("✅ ربات با موفقیت متصل شد.\n\nحالا کد مدیریت رو داخل تلگرام ارسال کن.");
  } else {
    ui.alert("اتصال انجام نشد:\n\n" + JSON.stringify(response));
  }
}

function checkWebhook() {
  const ui = SpreadsheetApp.getUi();
  if (!getBotToken_()) {
    ui.alert("توکن ربات ثبت نشده.");
    return;
  }

  const response = telegramRequest_("getWebhookInfo", {});
  if (!response.ok) {
    ui.alert("بررسی اتصال ناموفق بود:\n" + JSON.stringify(response));
    return;
  }

  const info = response.result || {};
  ui.alert(
    "وضعیت اتصال\n\n" +
    "URL: " + (info.url || "ثبت نشده") + "\n" +
    "پیام‌های در انتظار: " + (info.pending_update_count || 0) + "\n" +
    "آخرین خطا: " + (info.last_error_message || "ندارد")
  );
}

function disconnectWebhook() {
  const ui = SpreadsheetApp.getUi();
  if (!getBotToken_()) {
    ui.alert("توکن ربات ثبت نشده.");
    return;
  }
  const response = telegramRequest_("deleteWebhook", { drop_pending_updates: true });
  ui.alert(response.ok ? "اتصال ربات قطع شد." : "قطع اتصال ناموفق بود.");
}

function showClaimCode() {
  SpreadsheetApp.getUi().alert(
    "کد مدیریت:\n\n" + getSetting_("CLAIM_CODE") +
    "\n\nداخل ربات این دستور رو بفرست:\n/claim " + getSetting_("CLAIM_CODE")
  );
}

function resetClaimCode() {
  const ui = SpreadsheetApp.getUi();
  const answer = ui.alert(
    "ساخت کد جدید",
    "مدیر فعلی برداشته بشه و یک کد مدیریت جدید ساخته بشه؟",
    ui.ButtonSet.YES_NO
  );
  if (answer !== ui.Button.YES) return;

  const code = generateClaimCode_();
  setSetting_("CLAIM_CODE", code);
  setSetting_("ADMIN_ID", "");
  setSetting_("SETUP_DONE", "false");
  ui.alert("کد جدید:\n\n" + code + "\n\nدستور تلگرام:\n/claim " + code);
}

function installDailyReminder() {
  ScriptApp.getProjectTriggers().forEach(function(t) {
    if (t.getHandlerFunction() === "dailyReminder") ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger("dailyReminder").timeBased().everyDays(1).atHour(9).create();
  SpreadsheetApp.getUi().alert("✅ یادآور روزانه فعال شد (هر روز حدود ساعت ۹ صبح).");
}

// هر صبح: به مدیر تعداد بدون‌مسئول‌ها، و به هر عضو تعداد موارد در انتظار خودش رو می‌گه
// یادآوری وقت مشاوره: هر دقیقه از سرور صدا زده می‌شه؛ وقتی زمان مشاوره رسید به عضو خبر می‌ده
function visitReminders() {
  const now = Date.now();
  const calls = getAllCallsRaw_();
  const leadsMap = {};
  getAllLeadsRaw_().forEach(function(l) { leadsMap[l.leadId] = l; });
  // فقط آخرین تماسِ هر شماره اعتبار داره و باید هنوز «بازدید» باشه
  const lastBy = {};
  calls.forEach(function(c) { lastBy[c.leadId] = c; });
  const sheet = getCallsSheet_();
  const agentsAll = getAllAgents_();
  let sent = 0;
  calls.forEach(function(c) {
    if (c.outcome !== "visit" || !c.visitAt || c.visitNotified || c.visitAt > now) return;
    const lead = leadsMap[c.leadId];
    const stale = !lead || lastBy[c.leadId].callId !== c.callId || lead.status !== "visit" || now - c.visitAt > 36 * 3600 * 1000;
    sheet.getRange(c.rowNumber, 11).setValue(new Date());
    if (stale) return;
    const agent = agentsAll.filter(function(a) { return a.agentId === c.agentId; })[0] ||
      (lead.assignedTo ? agentsAll.filter(function(a) { return a.agentId === lead.assignedTo; })[0] : null);
    const text = "📅 یادآوری وقت مشاوره" + (isTeamLead_(lead) ? " (دفتر تیم)" : "") + "\n\n" + leadTag_(lead) + " " + lead.name + "\n📞 " + lead.phone +
      "\n🕒 " + formatDateTime_(new Date(c.visitAt)) + (c.note ? "\nیادداشت: " + c.note : "");
    try {
      if (agent) {
        const target = notifyTarget_(agent);
        if (target) sendMessage_(target, text, agentNotifyButtons_(agent, { text: "👁 مشاهده", callback_data: "ld:" + lead.leadId }));
      }
      const adminId = getSetting_("ADMIN_ID");
      if (adminId && getSetting_("NOTIFY_CALLS") !== "false") sendMessage_(adminId, text + (agent ? "\nعضو تیم: " + agentLabel_(agent) : ""));
      sent++;
    } catch (e) {}
  });
  MEMO = {};
  return sent;
}

function dailyReminder() {
  const leads = getAllLeads_();
  const adminId = getSetting_("ADMIN_ID");

  if (adminId) {
    const unassigned = leads.filter(function(l) { return l.status === "new"; }).length;
    const stuck = leads.filter(function(l) { return ATTENTION_STATUSES.indexOf(l.status) !== -1; }).length;
    if (unassigned || stuck) {
      sendMessage_(
        adminId,
        "⏰ یادآوری\n\n🆕 بدون مسئول: " + unassigned + "\n🔁 نیازمند پیگیری یا تماس مجدد: " + stuck,
        { inline_keyboard: [[
          { text: "🆕 جدیدها", callback_data: "ls:new:0" },
          { text: "🔁 پیگیری", callback_data: "ls:attention:0" }
        ]] }
      );
    }
  }

  const pendingMap = pendingCountMap_(leads);
  getAllAgents_().forEach(function(agent) {
    const target = notifyTarget_(agent);
    if (agent.status !== "active" || !target) return;
    const pending = pendingMap[agent.agentId] || 0;
    if (pending) {
      sendMessage_(
        target,
        "⏰ صبح بخیر " + agent.name + "\n\n" + pending + " مورد در انتظار تماس داری.",
        agentNotifyButtons_(agent, { text: "▶️ شروع تماس‌ها", callback_data: "nx" })
      );
    }
  });
}

// =====================================================
//  دریافت پیام‌ها از تلگرام
// =====================================================

function doPost(e) {
  // درخواست‌های اپ (نسخه مستقل PWA) JSON با فیلد api هستند؛ آپدیت‌های تلگرام این فیلد رو ندارن
  const apiReq = parseApiRequest_(e);
  if (apiReq) {
    return jsonOut_(appApi(apiReq.token, apiReq.action, apiReq.payload));
  }

  const lock = LockService.getScriptLock();
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return HtmlService.createHtmlOutput("OK");
    }

    lock.waitLock(25000);

    const update = JSON.parse(e.postData.contents);
    const updateId = String(update.update_id || "");
    const cache = CacheService.getScriptCache();

    if (updateId && cache.get("update_" + updateId)) {
      return HtmlService.createHtmlOutput("OK");
    }
    if (updateId) cache.put("update_" + updateId, "1", 21600);

    if (update.callback_query) {
      handleCallbackQuery_(update.callback_query);
    } else if (update.message) {
      handleMessage_(update.message);
    }
  } catch (error) {
    console.error(error && error.stack ? error.stack : error);
  } finally {
    try { lock.releaseLock(); } catch (e2) {}
  }

  return HtmlService.createHtmlOutput("OK");
}

function getRole_(userId) {
  if (isAdmin_(userId)) return "admin";
  const agent = getAgentByUserId_(userId);
  if (agent && agent.status === "active") return "agent";
  return "customer";
}

function showMenuForRole_(chatId, role, prefix) {
  if (role === "admin") return showAdminMenu_(chatId, prefix);
  if (role === "agent") return showAgentMenu_(chatId, prefix);
  return showCustomerMenu_(chatId, prefix);
}

function handleMessage_(message) {
  if (!message.chat || message.chat.type !== "private") return;

  const chatId = String(message.chat.id);
  const userId = String(message.from ? message.from.id : message.chat.id);
  const text = String(message.text || "").trim();
  const role = getRole_(userId);

  // اتصال تلگرام عضو اپ برای دریافت اعلان
  if (text.indexOf("/start link_") === 0) {
    linkTelegram_(message, text.split("link_")[1] || "");
    return;
  }

  // عضویت در تیم با لینک دعوت یا دستور /join
  if (text.indexOf("/start join_") === 0) {
    joinTeam_(message, text.split("join_")[1] || "");
    return;
  }
  if (text.indexOf("/join") === 0) {
    joinTeam_(message, text.split(/\s+/)[1] || "");
    return;
  }

  if (text === "/start") {
    clearSession_(userId);
    if (role === "customer" && !getSetting_("ADMIN_ID")) {
      sendMessage_(chatId, "این ربات هنوز راه‌اندازی نشده. مدیر باید با دستور /claim اون رو فعال کنه.");
    } else {
      showMenuForRole_(chatId, role, role === "admin" ? "به پنل مدیریت خوش اومدی." : "");
    }
    return;
  }

  if (text.indexOf("/claim") === 0) {
    handleClaim_(message, text);
    return;
  }

  if (text === "/cancel" || text === "❌ لغو عملیات") {
    clearSession_(userId);
    showMenuForRole_(chatId, role, "عملیات لغو شد.");
    return;
  }

  let session = getSession_(userId);

  // اگه وسط یه مرحله دکمه منو رو زد، مرحله قبلی لغو می‌شه و منو اجرا می‌شه
  if (session && (
    (role === "admin" && ADMIN_MENU_LABELS.indexOf(text) !== -1) ||
    (role === "agent" && AGENT_MENU_LABELS.indexOf(text) !== -1)
  )) {
    clearSession_(userId);
    session = null;
  }

  if (session) {
    if (session.state.indexOf("ADMIN_") === 0 && role === "admin") {
      handleAdminState_(message, session);
      return;
    }
    if (session.state.indexOf("AGENT_") === 0 && (role === "admin" || role === "agent")) {
      handleAgentState_(message, session);
      return;
    }
    if (session.state.indexOf("CUSTOMER_") === 0) {
      handleCustomerState_(message, session);
      return;
    }
  }

  if (role === "admin") {
    handleAdminMenuMessage_(message);
  } else if (role === "agent") {
    handleAgentMenuMessage_(message);
  } else {
    handleCustomerMenuMessage_(message);
  }
}

function handleClaim_(message, text) {
  const chatId = String(message.chat.id);
  const userId = String(message.from ? message.from.id : message.chat.id);
  const enteredCode = text.split(/\s+/)[1] || "";
  const currentAdminId = getSetting_("ADMIN_ID");

  if (currentAdminId) {
    if (currentAdminId === userId) {
      showAdminMenu_(chatId, "این حساب از قبل مدیر ربات هست.");
    } else {
      sendMessage_(chatId, "این ربات قبلاً یک مدیر فعال داره.");
    }
    return;
  }

  if (!enteredCode || enteredCode !== getSetting_("CLAIM_CODE")) {
    sendMessage_(chatId, "کد مدیریت درست نیست. دستور باید شبیه این باشه:\n/claim 123456");
    return;
  }

  setSetting_("ADMIN_ID", userId);
  setSession_(message.from, "ADMIN_SETUP_NAME", {});
  sendMessage_(
    chatId,
    "✅ مدیریت ربات به نام شما ثبت شد.\n\nاسم خودت یا کسب‌وکارت رو بفرست (توی پیام خوش‌آمدگویی نمایش داده می‌شه).",
    cancelKeyboard_()
  );
}

function joinTeam_(message, code) {
  const chatId = String(message.chat.id);
  const userId = String(message.from.id);
  code = String(code || "").trim();

  if (isAdmin_(userId)) {
    showAdminMenu_(chatId, "تو مدیر ربات هستی و نیازی به عضویت نداری.");
    return;
  }

  const current = getAgentByUserId_(userId);
  if (current && current.status === "active") {
    showAgentMenu_(chatId, "تو از قبل عضو تیم هستی.");
    return;
  }

  const agent = code ? getAgentByCode_(code) : null;
  if (!agent || agent.status !== "invited") {
    sendMessage_(chatId, "کد دعوت معتبر نیست یا قبلاً استفاده شده. از مدیر بخواه کد جدید بده.");
    return;
  }

  updateAgentRow_(agent.rowNumber, {
    1: String(userId),
    3: message.from.username || "",
    5: "active",
    7: new Date()
  });

  showAgentMenu_(chatId, "✅ خوش اومدی " + agent.name + "! به تیم پیوستی.");

  const adminId = getSetting_("ADMIN_ID");
  if (adminId) {
    sendMessage_(adminId, "👥 " + agent.name + " (عضو شماره " + agent.no + ") با موفقیت به تیم پیوست.");
  }
}

// =====================================================
//  منوها
// =====================================================

function menuKeyboard_(rows) {
  return {
    keyboard: rows.map(function(r) { return r.map(function(t) { return { text: t }; }); }),
    resize_keyboard: true,
    is_persistent: true
  };
}

function showAdminMenu_(chatId, prefix) {
  const text = (prefix ? prefix + "\n\n" : "") + "از منوی پایین درخواست‌ها و تیم رو مدیریت کن.";
  sendMessage_(chatId, text, menuKeyboard_(ADMIN_MENU_ROWS));
}

function showAgentMenu_(chatId, prefix) {
  const text = (prefix ? prefix + "\n\n" : "") +
    "از منوی پایین، شماره‌های اختصاص‌داده‌شده به خودت رو ببین و نتیجه تماس‌ها رو ثبت کن.";
  sendMessage_(chatId, text, menuKeyboard_(AGENT_MENU_ROWS));
}

function customerKeyboard_() {
  return {
    keyboard: [
      [{ text: "📝 ثبت درخواست مشاوره" }]
    ],
    resize_keyboard: true,
    is_persistent: true
  };
}

function showCustomerMenu_(chatId, prefix) {
  const name = getSetting_("BUSINESS_NAME") || "مشاوره";
  const text = (prefix ? prefix + "\n\n" : "") +
    "🌿 " + name + "\n\n" + (getSetting_("WELCOME_TEXT") || "خوش اومدی.");
  sendMessage_(chatId, text, customerKeyboard_());
}

// =====================================================
//  بخش مدیر: منو و مراحل
// =====================================================

function handleAdminMenuMessage_(message) {
  const chatId = String(message.chat.id);
  const text = String(message.text || "").trim();

  switch (text) {
    case MENU.NEW:
      showLeadsList_(chatId, "new", 0, "");
      return;
    case MENU.ALL:
      showLeadsFilter_(chatId);
      return;
    case MENU.MANUAL:
      showManualList_(chatId, message.from, "today", "");
      return;
    case MENU.AUTO:
      showAutoScreen_(chatId, "");
      return;
    case MENU.CALLS:
      showCallLog_(chatId, "today", 0, "", "admin");
      return;
    case MENU.ATTN:
      showLeadsList_(chatId, "attention", 0, "");
      return;
    case MENU.TEAM:
      showTeam_(chatId, 0);
      return;
    case MENU.REPORT:
      showTeamReport_(chatId);
      return;
    case MENU.SEARCH:
      setSession_(message.from, "ADMIN_SEARCH", {});
      sendMessage_(chatId, "نام، شماره تلفن، یوزرنیم یا کد (مثلاً 105) رو بفرست.", cancelKeyboard_());
      return;
    case MENU.STATS:
      showStats_(chatId);
      return;
    case MENU.EXPORT:
      showExportMenu_(chatId);
      return;
    case MENU.SETTINGS:
      showAdminSettings_(chatId);
      return;
    case MENU.TEST:
      startForm_(message.from, chatId);
      return;
    case MENU.HEALTH:
      showHealthCheck_(chatId);
      return;
    default:
      showAdminMenu_(chatId, "یکی از گزینه‌های منوی مدیریت رو انتخاب کن.");
  }
}

function handleAdminState_(message, session) {
  const chatId = String(message.chat.id);
  const text = String(message.text || "").trim();
  const data = session.data || {};
  const userId = String(message.from.id);

  switch (session.state) {
    case "ADMIN_SETUP_NAME":
      if (!text) return sendMessage_(chatId, "اسم رو به‌صورت متن بفرست.");
      setSetting_("BUSINESS_NAME", text);
      setSession_(message.from, "ADMIN_SETUP_WELCOME", {});
      sendMessage_(
        chatId,
        "پیام خوش‌آمدگویی که کاربر اول از همه می‌بینه رو بفرست، یا روی «رد کردن» بزن تا متن پیش‌فرض بمونه.",
        skipCancelKeyboard_()
      );
      return;

    case "ADMIN_SETUP_WELCOME":
      if (text && text !== "رد کردن") setSetting_("WELCOME_TEXT", text);
      setSetting_("SETUP_DONE", "true");
      clearSession_(userId);
      showAdminMenu_(
        chatId,
        "✅ ربات راه‌اندازی شد. هر درخواست جدید همین‌جا برات میاد.\n" +
        "برای اضافه کردن تیمت، از «👥 تیم» استفاده کن."
      );
      return;

    case "ADMIN_SEARCH": {
      if (!text) return sendMessage_(chatId, "یه عبارت برای جستجو بفرست.");
      clearSession_(userId);
      const q = normalizeDigits_(text).toLowerCase().replace(/^[@#]/, "");
      const found = getAllLeads_().filter(function(l) {
        return l.name.toLowerCase().indexOf(q) !== -1 ||
          normalizeDigits_(l.phone).indexOf(q) !== -1 ||
          l.username.toLowerCase().indexOf(q) !== -1 ||
          (/^\d+$/.test(q) && String(l.seq) === q);
      }).reverse();

      if (!found.length) {
        showAdminMenu_(chatId, "نتیجه‌ای پیدا نشد.");
        return;
      }
      showAdminMenu_(chatId, "");
      sendLeadButtons_(chatId, "🔍 نتیجه جستجو (" + found.length + ")", found.slice(0, 20));
      return;
    }

    case "ADMIN_AGENT_SEARCH": {
      if (!text) return sendMessage_(chatId, "بخشی از اسم عضو رو بفرست.");
      clearSession_(userId);
      const q = text.toLowerCase();
      const found = getAllAgents_().filter(function(a) {
        return a.name.toLowerCase().indexOf(q) !== -1 || String(a.no) === normalizeDigits_(q);
      }).sort(function(a, b) { return a.no - b.no; });

      showAdminMenu_(chatId, "");
      if (!found.length) {
        sendMessage_(chatId, "عضوی با این اسم پیدا نشد.");
        return;
      }
      sendMessage_(chatId, "🔎 نتیجه:", {
        inline_keyboard: found.slice(0, 20).map(function(a) {
          return [{ text: agentLabel_(a) + " " + (AGENT_STATUS_LABELS[a.status] || "").split(" ")[0], callback_data: "ag:" + a.code }];
        })
      });
      return;
    }

    case "ADMIN_NOTE":
      updateLeadField_(data.leadId, COL.NOTE, text);
      clearSession_(userId);
      sendMessage_(chatId, "✅ یادداشت مدیر ذخیره شد.");
      showLeadDetail_(chatId, data.leadId, "admin", userId);
      return;

    case "ADMIN_REPLY": {
      const result = telegramRequest_("copyMessage", {
        chat_id: String(data.userId),
        from_chat_id: chatId,
        message_id: message.message_id
      });
      clearSession_(userId);
      if (result.ok) {
        showAdminMenu_(chatId, "✅ پیام برای کاربر ارسال شد.");
      } else {
        showAdminMenu_(chatId, "⚠️ ارسال انجام نشد. ممکنه کاربر ربات رو بلاک کرده باشه.");
      }
      return;
    }

    case "ADMIN_SETTING": {
      if (!text) return sendMessage_(chatId, "متن جدید رو بفرست.");
      const item = EDITABLE_SETTINGS[data.key];
      if (!item) {
        clearSession_(userId);
        return showAdminMenu_(chatId, "تنظیم نامعتبر بود.");
      }
      setSetting_(item[0], text);
      clearSession_(userId);
      showAdminSettings_(chatId, "✅ " + item[1] + " تغییر کرد.");
      return;
    }

    case "ADMIN_ADD_AGENT": {
      if (!text) return sendMessage_(chatId, "اسم عضو تیم رو بفرست.");
      clearSession_(userId);
      const agent = addInvite_(text);
      sendInviteInfo_(chatId, agent);
      return;
    }

    case "ADMIN_BULK": {
      const n = parseNumber_(text);
      if (n === null || n < 1 || n > 30) {
        return sendMessage_(chatId, "یک عدد بین ۱ تا ۳۰ بفرست.");
      }
      clearSession_(userId);
      const agent = getAgentByCode_(data.code);
      if (!agent || agent.status !== "active") {
        return showAdminMenu_(chatId, "این عضو فعال نیست.");
      }
      showAdminMenu_(chatId, "");
      bulkAssign_(chatId, agent, Math.floor(n));
      return;
    }

    case "ADMIN_AUTO_BATCH": {
      const n = parseNumber_(text);
      if (n === null || n < 1 || n > 20) {
        return sendMessage_(chatId, "یک عدد بین ۱ تا ۲۰ بفرست.");
      }
      setSetting_("AUTO_BATCH", String(Math.floor(n)));
      clearSession_(userId);
      showAutoScreen_(chatId, "✅ تعداد هر نوبت تغییر کرد.");
      return;
    }

    case "ADMIN_MANUAL": {
      if (!text) return sendMessage_(chatId, "کد شماره‌ها رو بفرست.");
      const done = executeManualAssign_(chatId, text, data);
      if (done) clearSession_(userId);
      return;
    }

    default:
      clearSession_(userId);
      showAdminMenu_(chatId, "مرحله قبلی معتبر نبود و لغو شد.");
  }
}

function handleCallbackQuery_(query) {
  const data = String(query.data || "");
  const chatId = query.message ? String(query.message.chat.id) : String(query.from.id);
  const userId = String(query.from.id);
  const role = getRole_(userId);

  answerCallbackQuery_(query.id);

  if (role === "customer") {
    sendMessage_(chatId, "این گزینه فقط برای تیم مدیریته.");
    return;
  }

  const parts = data.split(":");
  const action = parts[0];

  if (role === "agent" && AGENT_ACTIONS.indexOf(action) === -1) {
    sendMessage_(chatId, "این گزینه فقط برای مدیره.");
    return;
  }

  switch (action) {
    // ---------- مشترک بین مدیر و عضو تیم ----------
    case "ls": { // ls:وضعیت:صفحه:آیدی_عضو
      const agentFilter = role === "agent" ? userId : (parts[3] || "");
      showLeadsList_(chatId, parts[1], Number(parts[2] || 0), agentFilter);
      return;
    }

    case "cl": { // cl:بازه:صفحه:آیدی_عضو
      const agentFilter = role === "agent" ? userId : (parts[3] || "");
      showCallLog_(chatId, parts[1] || "today", Number(parts[2] || 0), agentFilter, role);
      return;
    }

    case "ld":
      showLeadDetail_(chatId, parts[1], role, userId);
      return;

    case "rs":
      showOutcomeMenu_(chatId, parts[1], role, userId);
      return;

    case "ro":
      startOutcomeNote_(query.from, chatId, parts[1], parts[2], role);
      return;

    case "nx": {
      const next = nextLeadFor_(userId);
      if (!next) {
        sendMessage_(chatId, "🎉 فعلاً موردی برای تماس نداری.");
      } else {
        showLeadDetail_(chatId, next.leadId, role, userId);
      }
      return;
    }

    // ---------- فقط مدیر ----------
    case "note":
      setSession_(query.from, "ADMIN_NOTE", { leadId: parts[1] });
      sendMessage_(chatId, "یادداشت مدیر رو بفرست (عضو تیم این یادداشت رو نمی‌بینه).", cancelKeyboard_());
      return;

    case "reply":
      setSession_(query.from, "ADMIN_REPLY", { userId: parts[1] });
      sendMessage_(chatId, "پیامت رو بفرست. متن، عکس یا فایل قابل ارساله.", cancelKeyboard_());
      return;

    case "del":
      sendMessage_(chatId, "این درخواست حذف بشه؟", {
        inline_keyboard: [[
          { text: "بله، حذف شود", callback_data: "delc:" + parts[1] },
          { text: "خیر", callback_data: "ld:" + parts[1] }
        ]]
      });
      return;

    case "delc":
      deleteLead_(parts[1]);
      sendMessage_(chatId, "✅ درخواست حذف شد.");
      return;

    case "set":
      startSettingEdit_(query.from, chatId, parts[1]);
      return;

    case "tg": {
      if (parts[1] === "notify") {
        const on = getSetting_("NOTIFY_CALLS") !== "false";
        setSetting_("NOTIFY_CALLS", on ? "false" : "true");
        showAdminSettings_(chatId, on ? "🔕 اعلان تماس‌ها خاموش شد." : "🔔 اعلان تماس‌ها روشن شد.");
      } else if (parts[1] === "date") {
        const j = getSetting_("DATE_MODE") !== "gregorian";
        setSetting_("DATE_MODE", j ? "gregorian" : "jalali");
        showAdminSettings_(chatId, "✅ نمایش تاریخ: " + (j ? "میلادی" : "شمسی"));
      }
      return;
    }

    // ----- تیم -----
    case "tm":
      showTeam_(chatId, Number(parts[1] || 0));
      return;

    case "agadd":
      setSession_(query.from, "ADMIN_ADD_AGENT", {});
      sendMessage_(chatId, "اسم عضو جدید تیم رو بفرست.", cancelKeyboard_());
      return;

    case "agsearch":
      setSession_(query.from, "ADMIN_AGENT_SEARCH", {});
      sendMessage_(chatId, "بخشی از اسم عضو یا شماره‌ش رو بفرست.", cancelKeyboard_());
      return;

    case "ag":
      showAgentDetail_(chatId, parts[1]);
      return;

    case "agtog":
      toggleAgent_(chatId, parts[1]);
      return;

    case "agdel":
      sendMessage_(chatId, "این عضو حذف بشه؟ شماره‌های در انتظارش آزاد می‌شن و به لیست «جدید» برمی‌گردن.", {
        inline_keyboard: [[
          { text: "بله، حذف شود", callback_data: "agdelc:" + parts[1] },
          { text: "خیر", callback_data: "ag:" + parts[1] }
        ]]
      });
      return;

    case "agdelc":
      deleteAgent_(chatId, parts[1]);
      return;

    case "agfree":
      freeAgentLeads_(chatId, parts[1]);
      return;

    case "agkey": {
      const ag = getAgentByCode_(parts[1]);
      if (!ag) return sendMessage_(chatId, "عضو پیدا نشد.");
      sendMessage_(
        chatId,
        "🔑 ورود به اپ برای «" + ag.name + "»\n\n" +
        (appUrl_() ? "آدرس اپ:\n" + appUrl_() + "\n\n" : "") +
        "کلید ورود:\n" + (ag.appKey || "—") +
        "\n\n⚠️ این کلید مثل رمز عبوره؛ فقط برای خود همین عضو بفرست."
      );
      return;
    }

    case "app":
      sendMessage_(
        chatId,
        "📱 ورود مدیر به اپ\n\n" +
        (appUrl_() ? "آدرس اپ:\n" + appUrl_() + "\n\n" : "آدرس اپ هنوز ثبت نشده (اتصال ربات رو از منوی شیت بزن).\n\n") +
        "کلید ورود مدیر:\n" + getAdminAppKey_() +
        "\n\n⚠️ این کلید رو به کسی نده."
      );
      return;

    case "bulk": {
      const agent = getAgentByCode_(parts[1]);
      if (!agent || agent.status !== "active") {
        sendMessage_(chatId, "این عضو فعال نیست.");
        return;
      }
      setSession_(query.from, "ADMIN_BULK", { code: parts[1] });
      sendMessage_(
        chatId,
        "چند شماره از «جدید»ها (قدیمی‌ترین‌ها) به " + agent.name + " اختصاص بدم؟ (۱ تا ۳۰)",
        cancelKeyboard_()
      );
      return;
    }

    case "split":
      distributeByBatches_(chatId);
      return;

    case "rep":
      showTeamReport_(chatId);
      return;

    // ----- اختصاص دستی -----
    case "as":
      showAssignMenu_(chatId, parts[1], Number(parts[2] || 0));
      return;

    case "asg": {
      const lead = getLeadById_(parts[1]);
      if (!lead) return sendMessage_(chatId, "درخواست پیدا نشد.");

      if (parts[2] === "none") {
        assignLeadTo_(lead, null);
        sendMessage_(chatId, "↩️ مسئول این مورد برداشته شد.");
      } else {
        const agent = getAgentByCode_(parts[2]);
        if (!agent || agent.status !== "active") {
          return sendMessage_(chatId, "این عضو فعال نیست.");
        }
        assignLeadTo_(lead, agent);
        notifyAgentAssigned_(agent, [lead]);
        sendMessage_(chatId, "✅ به " + agentLabel_(agent) + " اختصاص داده شد.");
      }
      showLeadDetail_(chatId, lead.leadId, "admin", userId);
      return;
    }

    case "ml": // لیست بدون‌مسئول‌ها: ml:بازه
      showManualList_(chatId, query.from, parts[1] || "today", "");
      return;

    case "mlstart":
      showManualList_(chatId, query.from, "today", "");
      return;

    case "mla": // اختصاص با شماره برای یک عضو مشخص
      showManualList_(chatId, query.from, "all", parts[1]);
      return;

    // ----- اختصاص خودکار -----
    case "au": {
      if (parts[1] === "menu") {
        showAutoScreen_(chatId, "");
      } else if (parts[1] === "toggle") {
        const on = getSetting_("AUTO_ASSIGN") === "true";
        setSetting_("AUTO_ASSIGN", on ? "false" : "true");
        showAutoScreen_(chatId, on ? "⏸ اختصاص خودکار خاموش شد." : "✅ اختصاص خودکار روشن شد.");
      } else if (parts[1] === "batch") {
        setSession_(query.from, "ADMIN_AUTO_BATCH", {});
        sendMessage_(chatId, "هر عضو در هر نوبت چند شماره بگیره؟ (عدد ۱ تا ۲۰)", cancelKeyboard_());
      } else if (parts[1] === "run") {
        distributeByBatches_(chatId);
      } else if (parts[1] === "reset") {
        setSetting_("AUTO_CUR_NO", "0");
        setSetting_("AUTO_CUR_COUNT", "0");
        showAutoScreen_(chatId, "🔄 چرخه از اولین عضو شروع می‌شه.");
      }
      return;
    }

    // ----- خروجی -----
    case "ex":
      handleExport_(chatId, parts[1], parts[2]);
      return;
  }
}

// =====================================================
//  لیست‌ها و جزئیات درخواست‌ها
// =====================================================

function matchStatus_(lead, status) {
  if (status === "all") return true;
  if (status === "pending") return PENDING_STATUSES.indexOf(lead.status) !== -1;
  if (status === "done") return DONE_STATUSES.indexOf(lead.status) !== -1;
  if (status === "attention") return ATTENTION_STATUSES.indexOf(lead.status) !== -1;
  return lead.status === status;
}

function statusTitle_(status) {
  if (status === "all") return "📋 همه";
  if (status === "pending") return "⏳ در انتظار تماس";
  if (status === "done") return "✅ انجام‌شده";
  if (status === "attention") return "🔁 نیازمند پیگیری (جواب نداد / پیگیری)";
  const st = STATUSES[status];
  return st ? st.emoji + " " + st.label : status;
}

function leadLabel_(l) {
  return (STATUSES[l.status] ? STATUSES[l.status].emoji + " " : "") +
    "#" + (l.seq || "—") + " · " + formatShort_(l.createdAt) + " · " + truncate_(l.name, 16);
}

function showLeadsFilter_(chatId) {
  const leads = getAllLeads_();
  const counts = {};
  Object.keys(STATUSES).forEach(function(k) { counts[k] = 0; });
  leads.forEach(function(l) { if (counts[l.status] !== undefined) counts[l.status]++; });

  const rows = [[{ text: "📋 همه (" + leads.length + ")", callback_data: "ls:all:0" }]];
  Object.keys(STATUSES).forEach(function(k) {
    rows.push([{
      text: STATUSES[k].emoji + " " + STATUSES[k].label + " (" + counts[k] + ")",
      callback_data: "ls:" + k + ":0"
    }]);
  });
  sendMessage_(chatId, "کدوم دسته رو ببینم؟", { inline_keyboard: rows });
}

function showLeadsList_(chatId, status, page, agentId) {
  let leads = getAllLeads_().reverse(); // جدیدترین اول
  leads = leads.filter(function(l) { return matchStatus_(l, status); });
  if (agentId) {
    leads = leads.filter(function(l) { return l.assignedTo === String(agentId); });
  }

  let title = statusTitle_(status);
  if (agentId) {
    const agent = getAgentByUserId_(agentId);
    if (agent) title += " — " + agent.name;
  }

  if (!leads.length) {
    sendMessage_(chatId, title + "\n\nموردی وجود نداره.");
    return;
  }

  const pageSize = 10;
  const totalPages = Math.ceil(leads.length / pageSize);
  const safePage = Math.max(0, Math.min(Number(page || 0), totalPages - 1));
  const selected = leads.slice(safePage * pageSize, safePage * pageSize + pageSize);
  const suffix = agentId ? ":" + agentId : "";

  const keyboard = selected.map(function(l) {
    return [{ text: leadLabel_(l), callback_data: "ld:" + l.leadId }];
  });

  const nav = [];
  if (safePage > 0) nav.push({ text: "◀️ قبلی", callback_data: "ls:" + status + ":" + (safePage - 1) + suffix });
  if (safePage < totalPages - 1) nav.push({ text: "بعدی ▶️", callback_data: "ls:" + status + ":" + (safePage + 1) + suffix });
  if (nav.length) keyboard.push(nav);

  sendMessage_(
    chatId,
    title + " (" + leads.length + ")\nصفحه " + (safePage + 1) + " از " + totalPages,
    { inline_keyboard: keyboard }
  );
}

function sendLeadButtons_(chatId, title, leads) {
  const keyboard = leads.map(function(l) {
    return [{ text: leadLabel_(l), callback_data: "ld:" + l.leadId }];
  });
  sendMessage_(chatId, title, { inline_keyboard: keyboard });
}

function canAccessLead_(lead, role, userId) {
  if (role === "admin") return true;
  return role === "agent" && lead.assignedTo === String(userId);
}

function showLeadDetail_(chatId, leadId, role, userId) {
  const lead = getLeadById_(leadId);
  if (!lead) return sendMessage_(chatId, "درخواست پیدا نشد.");
  if (!canAccessLead_(lead, role, userId)) {
    return sendMessage_(chatId, "این مورد به تو اختصاص داده نشده.");
  }
  sendMessage_(chatId, leadText_(lead, role), leadButtons_(lead, role));
}

function leadText_(lead, role) {
  const st = STATUSES[lead.status];
  let text = "🔢 کد: #" + (lead.seq || "—") + "\n" +
    "👤 " + lead.name + "\n" +
    "📱 " + lead.phone + "\n" +
    (lead.age ? "🎂 سن: " + lead.age + "\n" : "") +
    (lead.city ? "📍 شهر: " + lead.city + "\n" : "") +
    (lead.goal ? "🎯 موضوع: " + lead.goal + "\n" : "") +
    "🕒 تاریخ ثبت: " + formatDateTime_(lead.createdAt) + "\n" +
    "وضعیت: " + (st ? st.emoji + " " + st.label : lead.status);

  if (lead.assignedAt) {
    text += "\n📌 تاریخ اختصاص: " + formatDateTime_(lead.assignedAt);
  }

  if (role === "admin") {
    text += "\n✈️ تلگرام: " + (lead.username ? "@" + lead.username : "بدون یوزرنیم");
    const agent = lead.assignedTo ? getAgentByUserId_(lead.assignedTo) : null;
    text += "\n🧑‍💼 مسئول: " + (agent ? agentLabel_(agent) : (lead.assignedTo ? "نامشخص" : "—"));
    if (lead.note) text += "\n🗒 یادداشت مدیر: " + lead.note;
  }

  text += historyText_(lead.leadId);
  return text;
}

function historyText_(leadId) {
  const all = getAllCalls_().filter(function(c) { return c.leadId === leadId; });
  if (!all.length) return "\n\n📞 هنوز تماسی ثبت نشده.";

  const shown = all.slice(-8);
  const offset = all.length - shown.length;
  return "\n\n📞 تاریخچه تماس (" + all.length + " بار):\n" + shown.map(function(c, i) {
    const st = STATUSES[c.outcome];
    return (offset + i + 1) + ". " + (st ? st.emoji : "•") + " " + c.agentName +
      " — " + formatDateTime_(c.createdAt) + (c.note ? "\n    " + c.note : "");
  }).join("\n");
}

function leadButtons_(lead, role) {
  if (role === "agent") {
    return { inline_keyboard: [[{ text: "📝 ثبت نتیجه تماس", callback_data: "rs:" + lead.leadId }]] };
  }
  return {
    inline_keyboard: [
      [
        { text: "📝 ثبت نتیجه تماس", callback_data: "rs:" + lead.leadId },
        { text: "👤 اختصاص به عضو", callback_data: "as:" + lead.leadId + ":0" }
      ],
      [
        { text: "🗒 یادداشت مدیر", callback_data: "note:" + lead.leadId },
        { text: "💬 پیام به کاربر", callback_data: "reply:" + lead.userId }
      ],
      [{ text: "🗑 حذف", callback_data: "del:" + lead.leadId }]
    ]
  };
}

// =====================================================
//  ثبت نتیجه تماس
// =====================================================

function showOutcomeMenu_(chatId, leadId, role, userId) {
  const lead = getLeadById_(leadId);
  if (!lead) return sendMessage_(chatId, "درخواست پیدا نشد.");
  if (!canAccessLead_(lead, role, userId)) {
    return sendMessage_(chatId, "این مورد به تو اختصاص داده نشده.");
  }

  const rows = BOT_OUTCOME_KEYS.map(function(k) {
    return [{ text: STATUSES[k].emoji + " " + STATUSES[k].label, callback_data: "ro:" + leadId + ":" + k }];
  });
  sendMessage_(chatId, "نتیجه تماس با «" + lead.name + "» (#" + lead.seq + ") چی بود؟", { inline_keyboard: rows });
}

function startOutcomeNote_(from, chatId, leadId, outcome, role) {
  const lead = getLeadById_(leadId);
  if (!lead) return sendMessage_(chatId, "درخواست پیدا نشد.");
  if (!canAccessLead_(lead, role, String(from.id))) {
    return sendMessage_(chatId, "این مورد به تو اختصاص داده نشده.");
  }
  if (BOT_OUTCOME_KEYS.indexOf(outcome) === -1) return;

  setSession_(from, "AGENT_NOTE", { leadId: leadId, outcome: outcome });
  sendMessage_(
    chatId,
    STATUSES[outcome].emoji + " " + STATUSES[outcome].label + "\n\n" +
    "یه یادداشت کوتاه بنویس (مثلاً نکته مهم مکالمه یا زمان پیگیری)، یا روی «رد کردن» بزن.",
    skipCancelKeyboard_()
  );
}

function handleAgentState_(message, session) {
  const chatId = String(message.chat.id);
  const text = String(message.text || "").trim();
  const data = session.data || {};
  const userId = String(message.from.id);
  const role = getRole_(userId);

  if (session.state !== "AGENT_NOTE") {
    clearSession_(userId);
    return showMenuForRole_(chatId, role, "مرحله قبلی معتبر نبود و لغو شد.");
  }

  if (!text) {
    return sendMessage_(chatId, "یادداشت رو به‌صورت متن بفرست یا «رد کردن» بزن.");
  }

  const lead = getLeadById_(data.leadId);
  clearSession_(userId);

  if (!lead || !canAccessLead_(lead, role, userId)) {
    return showMenuForRole_(chatId, role, "این مورد دیگه در دسترس نیست.");
  }

  const note = text === "رد کردن" ? "" : text;
  saveCall_(message.from, role, lead, data.outcome, note);

  const st = STATUSES[data.outcome];
  const markup = role === "agent"
    ? { inline_keyboard: [[{ text: "➡️ مورد بعدی", callback_data: "nx" }]] }
    : { inline_keyboard: [[{ text: "👁 مشاهده مورد", callback_data: "ld:" + lead.leadId }]] };

  showMenuForRole_(chatId, role, "");
  sendMessage_(
    chatId,
    "✅ نتیجه ثبت شد: " + st.emoji + " " + st.label + "\nمشتری: #" + lead.seq + " " + lead.name +
    "\n🕒 " + formatDateTime_(new Date()),
    markup
  );
}

function saveCall_(from, role, lead, outcome, note) {
  const agent = role === "agent" ? getAgentByUserId_(from.id) : null;
  const agentName = agent ? agent.name : "مدیر";
  const callId = "C" + Utilities.getUuid().replace(/-/g, "").slice(0, 6).toUpperCase();
  const now = new Date();

  getCallsSheet_().appendRow([
    callId, lead.leadId, lead.name, String(from.id), agentName, outcome, note, now
  ]);

  const attempt = Number(lead.callsCount || 0) + 1;
  const sheet = getSheet_(APP.SHEETS.LEADS);
  sheet.getRange(lead.rowNumber, COL.STATUS).setValue(outcome);
  sheet.getRange(lead.rowNumber, COL.LAST_OUTCOME).setValue(outcome);
  sheet.getRange(lead.rowNumber, COL.CALLS_COUNT).setValue(attempt);
  sheet.getRange(lead.rowNumber, COL.UPDATED).setValue(now);

  const adminId = getSetting_("ADMIN_ID");
  if (role === "agent" && adminId && getSetting_("NOTIFY_CALLS") !== "false") {
    const st = STATUSES[outcome];
    sendMessage_(
      adminId,
      "📞 گزارش تماس\n\n" +
      "عضو تیم: " + (agent ? agentLabel_(agent) : agentName) + "\n" +
      "مشتری: #" + lead.seq + " " + lead.name + " (" + lead.phone + ")\n" +
      "نتیجه: " + st.emoji + " " + st.label + " (تماس شماره " + attempt + ")\n" +
      "🕒 " + formatDateTime_(now) +
      (note ? "\nیادداشت: " + note : ""),
      { inline_keyboard: [[{ text: "👁 مشاهده مورد", callback_data: "ld:" + lead.leadId }]] }
    );
  }
}

function nextLeadFor_(userId) {
  const mine = getAllLeads_().filter(function(l) {
    return l.assignedTo === String(userId) && PENDING_STATUSES.indexOf(l.status) !== -1;
  });
  // اول اونایی که هنوز هیچ تماسی نگرفتن، به ترتیب قدیمی‌تر
  mine.sort(function(a, b) {
    const pa = a.status === "assigned" ? 0 : 1;
    const pb = b.status === "assigned" ? 0 : 1;
    return pa !== pb ? pa - pb : a.seq - b.seq;
  });
  return mine[0] || null;
}

// =====================================================
//  لیست تماس‌ها (با تاریخ دقیق)
// =====================================================

function inRange_(value, range) {
  if (range === "all") return true;
  const d = new Date(value);
  if (isNaN(d.getTime())) return false;
  if (range === "today") return dayKey_(d) === dayKey_(new Date());
  if (range === "yday") return dayKey_(d) === dayKey_(new Date(Date.now() - 24 * 3600 * 1000));
  if (range === "week") return d.getTime() >= Date.now() - 7 * 24 * 3600 * 1000;
  return true;
}

function showCallLog_(chatId, range, page, agentId, role) {
  const rangeLabels = { today: "امروز", yday: "دیروز", week: "۷ روز اخیر", all: "همه" };
  if (!rangeLabels[range]) range = "today";

  const leadsById = {};
  getAllLeads_().forEach(function(l) { leadsById[l.leadId] = l; });

  let calls = getAllCalls_().filter(function(c) { return inRange_(c.createdAt, range); });
  if (agentId) calls = calls.filter(function(c) { return c.agentId === String(agentId); });
  calls.reverse(); // جدیدترین اول

  let title = "📞 لیست تماس‌ها — " + rangeLabels[range];
  if (agentId && role === "admin") {
    const ag = getAgentByUserId_(agentId);
    if (ag) title += " — " + ag.name;
  }

  const suffix = agentId && role === "admin" ? ":" + agentId : "";
  const rows = [Object.keys(rangeLabels).map(function(r) {
    return { text: (r === range ? "• " : "") + rangeLabels[r], callback_data: "cl:" + r + ":0" + suffix };
  })];

  if (!calls.length) {
    if (role === "admin") rows.push([{ text: "🔁 نیازمند پیگیری", callback_data: "ls:attention:0" }]);
    sendMessage_(chatId, title + "\n\nتماسی ثبت نشده.", { inline_keyboard: rows });
    return;
  }

  const pageSize = 8;
  const totalPages = Math.ceil(calls.length / pageSize);
  const safePage = Math.max(0, Math.min(Number(page || 0), totalPages - 1));
  const selected = calls.slice(safePage * pageSize, safePage * pageSize + pageSize);
  const showAgent = !agentId;

  const body = selected.map(function(c) {
    const lead = leadsById[c.leadId];
    const who = lead ? "#" + lead.seq + " " + lead.name + " | " + lead.phone : c.leadName;
    const st = STATUSES[c.outcome];
    return "🕒 " + formatDateTime_(c.createdAt) + "\n" +
      (showAgent ? "🧑‍💼 " + c.agentName + " ← " : "") + who + "\n" +
      (st ? st.emoji + " " + st.label : c.outcome) +
      (c.note ? " — " + truncate_(c.note, 100) : "");
  }).join("\n\n");

  const nav = [];
  if (safePage > 0) nav.push({ text: "◀️ قبلی", callback_data: "cl:" + range + ":" + (safePage - 1) + suffix });
  if (safePage < totalPages - 1) nav.push({ text: "بعدی ▶️", callback_data: "cl:" + range + ":" + (safePage + 1) + suffix });
  if (nav.length) rows.push(nav);
  if (role === "admin") rows.push([{ text: "🔁 نیازمند پیگیری", callback_data: "ls:attention:0" }]);

  sendMessage_(
    chatId,
    title + " (" + calls.length + ")\nصفحه " + (safePage + 1) + " از " + totalPages + "\n\n" + body,
    { inline_keyboard: rows }
  );
}

// =====================================================
//  منوی عضو تیم
// =====================================================

function handleAgentMenuMessage_(message) {
  const chatId = String(message.chat.id);
  const userId = String(message.from.id);
  const text = String(message.text || "").trim();

  if (text === MENU.A_PENDING) {
    const pending = getAllLeads_().filter(function(l) {
      return l.assignedTo === userId && PENDING_STATUSES.indexOf(l.status) !== -1;
    });
    if (!pending.length) {
      sendMessage_(chatId, "🎉 فعلاً موردی برای تماس نداری.");
      return;
    }
    sendMessage_(chatId, "تعداد موارد در انتظار: " + pending.length, {
      inline_keyboard: [[{ text: "▶️ شروع تماس‌ها", callback_data: "nx" }]]
    });
    showLeadsList_(chatId, "pending", 0, userId);
    return;
  }

  if (text === MENU.A_CALLS) {
    showCallLog_(chatId, "today", 0, userId, "agent");
    return;
  }

  if (text === MENU.A_DONE) {
    showLeadsList_(chatId, "done", 0, userId);
    return;
  }

  if (text === MENU.A_STATS) {
    const agent = getAgentByUserId_(userId);
    if (agent) {
      sendMessage_(chatId, agentStatsText_(agent, getAllLeads_(), getAllCalls_()));
    }
    return;
  }

  showAgentMenu_(chatId, "یکی از گزینه‌های منو رو انتخاب کن.");
}

// =====================================================
//  اختصاص دستی با کد شماره‌ها
// =====================================================

function showManualList_(chatId, from, range, agentCode) {
  let leads = getUnassignedLeads_();

  if (range === "today") {
    const todays = leads.filter(function(l) { return inRange_(l.createdAt, "today"); });
    if (todays.length) leads = todays; else range = "all";
  } else if (range === "yday") {
    leads = leads.filter(function(l) { return inRange_(l.createdAt, "yday"); });
  }

  leads.sort(function(a, b) { return a.seq - b.seq; });

  const rangeLabels = { today: "امروز", yday: "دیروز", all: "همه" };
  const total = leads.length;
  const SHOW_MAX = 80;
  const shown = leads.slice(0, SHOW_MAX);

  let text = "📌 شماره‌های بدون مسئول — " + (rangeLabels[range] || "همه") + " (" + total + ")\n";
  let lastDay = "";
  shown.forEach(function(l) {
    const day = formatDay_(l.createdAt);
    if (day !== lastDay) {
      text += "\n📅 " + day + "\n";
      lastDay = day;
    }
    text += "#" + l.seq + "  " + timeOnly_(l.createdAt) + "  " + truncate_(l.name, 18) + " (" + truncate_(l.city, 10) + ")\n";
  });
  if (total > SHOW_MAX) text += "\n… و " + (total - SHOW_MAX) + " مورد دیگه (اول جدیدترین‌ها رو اختصاص بده).";
  if (!total) text += "\nموردی بدون مسئول نیست 🎉";

  const rows = [[
    { text: "امروز", callback_data: "ml:today" },
    { text: "دیروز", callback_data: "ml:yday" },
    { text: "همه", callback_data: "ml:all" }
  ]];
  sendLongText_(chatId, text, null);

  if (!total) {
    sendMessage_(chatId, "فیلتر دیگه‌ای رو امتحان کن:", { inline_keyboard: rows });
    return;
  }

  if (agentCode) {
    const agent = getAgentByCode_(agentCode);
    if (!agent || agent.status !== "active") {
      sendMessage_(chatId, "این عضو فعال نیست.");
      return;
    }
    setSession_(from, "ADMIN_MANUAL", { agentCode: agentCode });
    sendMessage_(
      chatId,
      "✍️ کد شماره‌هایی که برای «" + agentLabel_(agent) + "» می‌خوای رو بفرست.\n\n" +
      "مثال:\n101-104 110 115\n\n(بازه با خط تیره و جدا کردن با فاصله)",
      cancelKeyboard_()
    );
    return;
  }

  setSession_(from, "ADMIN_MANUAL", {});
  sendMessage_(
    chatId,
    "✍️ حالا بفرست، هر خط یک عضو:\n\n" +
    "12: 101-104\n" +
    "7: 105 106 107 108\n" +
    "مریم: 109-112\n\n" +
    "سمت چپ ':' شماره عضو یا اسمشه (شماره رو از «👥 تیم» ببین)، سمت راست کد شماره‌ها. " +
    "بازه با خط تیره نوشته می‌شه.",
    { inline_keyboard: rows }
  );
}

function resolveAgentSelector_(sel) {
  const s = normalizeDigits_(String(sel || "")).trim();
  if (!s) return { error: "عضو مشخص نشده." };

  const active = activeAgentsSorted_();
  if (/^\d+$/.test(s)) {
    const n = Number(s);
    const a = active.find(function(x) { return x.no === n; });
    return a ? { agent: a } : { error: "عضو فعال با شماره " + n + " پیدا نشد." };
  }

  const q = s.toLowerCase();
  const matches = active.filter(function(a) { return a.name.toLowerCase().indexOf(q) !== -1; });
  if (matches.length === 1) return { agent: matches[0] };
  if (!matches.length) return { error: "عضوی با اسم «" + s + "» پیدا نشد." };
  return {
    error: "چند عضو با اسم «" + s + "» هست: " +
      matches.slice(0, 5).map(function(a) { return a.no + "." + a.name; }).join("، ") + " — شماره‌شون رو بنویس."
  };
}

function parseSeqTokens_(str) {
  const clean = normalizeDigits_(String(str || ""))
    .replace(/[–—ـ−]/g, "-")
    .replace(/[،,;#]/g, " ")
    .replace(/\s*-\s*/g, "-");
  const seqs = [];
  const bad = [];

  clean.split(/\s+/).filter(Boolean).forEach(function(tok) {
    const m = tok.match(/^(\d+)-(\d+)$/);
    if (m) {
      let a = Number(m[1]);
      let b = Number(m[2]);
      if (a > b) { const t = a; a = b; b = t; }
      if (b - a > 200) { bad.push(tok); return; }
      for (let i = a; i <= b; i++) seqs.push(i);
      return;
    }
    if (/^\d+$/.test(tok)) { seqs.push(Number(tok)); return; }
    bad.push(tok);
  });

  return { seqs: seqs, bad: bad };
}

// خروجی: true یعنی کار انجام شد و مرحله بسته بشه
function executeManualAssign_(chatId, text, data) {
  const plan = [];
  const errors = [];
  const example = "\n\nمثال:\n12: 101-104\nمریم: 105 106";

  if (data.agentCode) {
    const agent = getAgentByCode_(data.agentCode);
    if (!agent || agent.status !== "active") {
      sendMessage_(chatId, "این عضو فعال نیست.");
      return true;
    }
    plan.push({ agent: agent, rest: text });
  } else {
    text.split(/\r?\n/).forEach(function(raw) {
      const line = raw.trim();
      if (!line) return;
      const idx = line.search(/[:：=]/);
      if (idx === -1) {
        errors.push("❌ فرمت این خط درست نیست: " + truncate_(line, 40));
        return;
      }
      const res = resolveAgentSelector_(line.slice(0, idx));
      if (res.error) {
        errors.push("❌ " + res.error);
        return;
      }
      plan.push({ agent: res.agent, rest: line.slice(idx + 1) });
    });
  }

  if (!plan.length) {
    sendMessage_(chatId, (errors.join("\n") || "چیزی پیدا نشد.") + example, cancelKeyboard_());
    return false;
  }

  const bySeq = {};
  getAllLeads_().forEach(function(l) { if (l.seq) bySeq[l.seq] = l; });

  const used = {};
  const results = plan.map(function(item) {
    const parsed = parseSeqTokens_(item.rest);
    const r = { agent: item.agent, ok: [], skipped: [], missing: [], dup: [], bad: parsed.bad };
    parsed.seqs.forEach(function(n) {
      if (used[n]) { r.dup.push(n); return; }
      const lead = bySeq[n];
      if (!lead) { r.missing.push(n); return; }
      if (DONE_STATUSES.indexOf(lead.status) !== -1) { r.skipped.push(n); return; }
      used[n] = true;
      r.ok.push(lead);
    });
    return r;
  });

  const totalOk = results.reduce(function(s, r) { return s + r.ok.length; }, 0);
  if (totalOk > 100) {
    sendMessage_(chatId, "در هر بار حداکثر ۱۰۰ شماره قابل اختصاصه. کمتر بفرست.", cancelKeyboard_());
    return false;
  }
  if (!totalOk && !errors.length) {
    // هیچ شماره معتبری پیدا نشده؛ خطاها رو نشون بده ولی مرحله باز بمونه
    let msg = "هیچ شماره معتبری برای اختصاص پیدا نشد.\n";
    results.forEach(function(r) {
      if (r.missing.length) msg += "❓ پیدا نشد: " + codesText_(r.missing) + "\n";
      if (r.skipped.length) msg += "⏭ قبلاً تماس انجام شده: " + codesText_(r.skipped) + "\n";
      if (r.bad.length) msg += "⚠️ نامعتبر: " + r.bad.join(" ") + "\n";
    });
    sendMessage_(chatId, msg + example, cancelKeyboard_());
    return false;
  }

  let summary = "📌 نتیجه اختصاص\n";
  results.forEach(function(r) {
    r.ok.forEach(function(l) { assignLeadTo_(l, r.agent); });
    if (r.ok.length) notifyAgentAssigned_(r.agent, r.ok);

    summary += "\n" + (r.ok.length ? "✅ " : "⚠️ ") + agentLabel_(r.agent) + ": " + r.ok.length + " شماره";
    if (r.ok.length) summary += "\n   " + codesText_(r.ok.map(function(l) { return l.seq; }));
    if (r.skipped.length) summary += "\n   ⏭ ردشده (تماس انجام‌شده): " + codesText_(r.skipped);
    if (r.missing.length) summary += "\n   ❓ پیدا نشد: " + codesText_(r.missing);
    if (r.dup.length) summary += "\n   🔁 تکراری: " + codesText_(r.dup);
    if (r.bad.length) summary += "\n   ⚠️ نامعتبر: " + r.bad.join(" ");
  });
  if (errors.length) summary += "\n\n" + errors.join("\n");

  sendLongText_(chatId, summary, {
    inline_keyboard: [[{ text: "📌 اختصاص بیشتر", callback_data: "mlstart" }]]
  });
  return true;
}

function codesText_(seqs) {
  return seqs.map(function(n) { return "#" + n; }).join(" ");
}

// =====================================================
//  اختصاص خودکار نوبتی
// =====================================================

function activeAgentsSorted_() {
  return getAllAgents_()
    .filter(function(a) { return a.status === "active" && a.agentId; })
    .sort(function(a, b) { return a.no - b.no; });
}

// عضو بعدی در چرخه رو انتخاب می‌کنه: هر عضو به تعداد AUTO_BATCH شماره می‌گیره، بعد نوبت نفر بعدیه
function pickAutoAgent_() {
  const agents = activeAgentsSorted_();
  if (!agents.length) return null;

  const batch = Math.max(1, Number(getSetting_("AUTO_BATCH") || 4));
  const curNo = Number(getSetting_("AUTO_CUR_NO") || 0);
  let count = Number(getSetting_("AUTO_CUR_COUNT") || 0);

  let cur = agents.find(function(a) { return a.no === curNo; });
  if (!cur || count >= batch) {
    cur = agents.find(function(a) { return a.no > curNo; }) || agents[0];
    count = 0;
  }

  count++;
  setSetting_("AUTO_CUR_NO", String(cur.no));
  setSetting_("AUTO_CUR_COUNT", String(count));
  return cur;
}

function distributeByBatches_(chatId) {
  const agents = activeAgentsSorted_();
  if (!agents.length) {
    sendMessage_(chatId, "هنوز عضو فعالی نداری.");
    return;
  }

  const pool = getUnassignedLeads_().sort(function(a, b) { return a.seq - b.seq; });
  if (!pool.length) {
    sendMessage_(chatId, "شماره‌ی بدون مسئول (جدید) وجود نداره.");
    return;
  }

  const slice = pool.slice(0, 60);
  const given = {};
  const order = [];
  slice.forEach(function(l) {
    const agent = pickAutoAgent_();
    if (!agent) return;
    assignLeadTo_(l, agent);
    if (!given[agent.agentId]) { given[agent.agentId] = { agent: agent, leads: [] }; order.push(agent.agentId); }
    given[agent.agentId].leads.push(l);
  });

  let summary = "⚖️ تقسیم نوبتی انجام شد (" + slice.length + " شماره):\n";
  order.forEach(function(id) {
    const g = given[id];
    summary += "\n• " + agentLabel_(g.agent) + ": " + g.leads.length + " شماره → " +
      codesText_(g.leads.map(function(l) { return l.seq; }));
    notifyAgentAssigned_(g.agent, g.leads);
  });

  const remaining = getUnassignedLeads_().length;
  if (remaining) summary += "\n\nهنوز " + remaining + " شماره بدون مسئول مونده. دوباره بزن.";
  sendLongText_(chatId, summary, null);
}

function showAutoScreen_(chatId, prefix) {
  const on = getSetting_("AUTO_ASSIGN") === "true";
  const batch = Number(getSetting_("AUTO_BATCH") || 4);
  const agents = activeAgentsSorted_();
  const curNo = Number(getSetting_("AUTO_CUR_NO") || 0);
  const count = Number(getSetting_("AUTO_CUR_COUNT") || 0);
  const cur = agents.find(function(a) { return a.no === curNo; });
  const unassigned = getUnassignedLeads_().length;

  let text = (prefix ? prefix + "\n\n" : "") +
    "🤖 اختصاص خودکار نوبتی\n\n" +
    "وضعیت: " + (on ? "✅ روشن" : "⏸ خاموش") + "\n" +
    "هر عضو در هر نوبت: " + batch + " شماره\n" +
    "اعضای فعال در چرخه: " + agents.length + "\n" +
    "آخرین نوبت: " + (cur ? agentLabel_(cur) + " (" + count + " از " + batch + ")" : "هنوز شروع نشده") + "\n" +
    "بدون مسئول الان: " + unassigned + "\n\n" +
    "وقتی روشن باشه، هر شماره جدید خودکار به عضو نوبت داده می‌شه. " +
    "ترتیب نوبت بر اساس «شماره عضو» هست و اعضای غیرفعال نادیده گرفته می‌شن.";

  sendMessage_(chatId, text, {
    inline_keyboard: [
      [{ text: on ? "⏸ خاموش کردن" : "✅ روشن کردن", callback_data: "au:toggle" }],
      [{ text: "🔢 تغییر تعداد هر نوبت (" + batch + ")", callback_data: "au:batch" }],
      [{ text: "⚖️ تقسیم نوبتی بدون‌مسئول‌های فعلی", callback_data: "au:run" }],
      [{ text: "🔄 شروع چرخه از اولین عضو", callback_data: "au:reset" }]
    ]
  });
}

// =====================================================
//  مدیریت تیم (مدیر)
// =====================================================

function agentLabel_(a) {
  return a.no + ". " + a.name;
}

function pendingCountMap_(leads) {
  const map = {};
  leads.forEach(function(l) {
    if (l.assignedTo && PENDING_STATUSES.indexOf(l.status) !== -1) {
      map[l.assignedTo] = (map[l.assignedTo] || 0) + 1;
    }
  });
  return map;
}

function showTeam_(chatId, page) {
  const agents = getAllAgents_().sort(function(a, b) { return a.no - b.no; });
  const pending = pendingCountMap_(getAllLeads_());
  const activeCount = agents.filter(function(a) { return a.status === "active"; }).length;

  const pageSize = 10;
  const totalPages = Math.max(1, Math.ceil(agents.length / pageSize));
  const safePage = Math.max(0, Math.min(Number(page || 0), totalPages - 1));
  const selected = agents.slice(safePage * pageSize, safePage * pageSize + pageSize);

  const rows = selected.map(function(a) {
    const icon = (AGENT_STATUS_LABELS[a.status] || "•").split(" ")[0];
    return [{
      text: icon + " " + agentLabel_(a) + (a.status === "active" ? " | در انتظار: " + (pending[a.agentId] || 0) : ""),
      callback_data: "ag:" + a.code
    }];
  });

  const nav = [];
  if (safePage > 0) nav.push({ text: "◀️ قبلی", callback_data: "tm:" + (safePage - 1) });
  if (safePage < totalPages - 1) nav.push({ text: "بعدی ▶️", callback_data: "tm:" + (safePage + 1) });
  if (nav.length) rows.push(nav);

  rows.push([
    { text: "➕ افزودن عضو", callback_data: "agadd" },
    { text: "🔎 جستجوی عضو", callback_data: "agsearch" }
  ]);
  rows.push([{ text: "🤖 اختصاص خودکار نوبتی", callback_data: "au:menu" }]);
  rows.push([{ text: "⚖️ تقسیم نوبتی جدیدها", callback_data: "split" }]);
  rows.push([{ text: "📈 گزارش تیم", callback_data: "rep" }]);

  sendMessage_(
    chatId,
    "👥 تیم تماس — " + agents.length + " نفر (فعال: " + activeCount + ")\n" +
    "عدد کنار اسم: شماره‌های در انتظار تماس\nصفحه " + (safePage + 1) + " از " + totalPages,
    { inline_keyboard: rows }
  );
}

function addInvite_(name) {
  const sheet = getTeamSheet_();
  const agents = getAllAgents_();
  const codes = agents.map(function(a) { return a.code; });
  const no = agents.reduce(function(m, a) { return Math.max(m, a.no); }, 0) + 1;

  let code = generateClaimCode_();
  while (codes.indexOf(code) !== -1) code = generateClaimCode_();

  const row = sheet.getLastRow() + 1;
  sheet.getRange(row, TCOL.ID).setNumberFormat("@");
  sheet.getRange(row, TCOL.CODE).setNumberFormat("@");
  sheet.getRange(row, 1, 1, TEAM_HEADERS.length).setValues([["", name, "", code, "invited", new Date(), "", no, generateAppKey_(), "", ""]]);

  return { name: name, code: code, no: no };
}

function getBotUsername_() {
  const props = PropertiesService.getScriptProperties();
  let name = props.getProperty("BOT_USERNAME");
  if (name) return name;
  const res = telegramRequest_("getMe", {});
  if (res.ok && res.result && res.result.username) {
    name = res.result.username;
    props.setProperty("BOT_USERNAME", name);
    return name;
  }
  return "";
}

function sendInviteInfo_(chatId, agent) {
  const username = getBotUsername_();
  const link = username ? "https://t.me/" + username + "?start=join_" + agent.code : "";
  sendMessage_(
    chatId,
    "✅ دعوت‌نامه برای «" + agent.name + "» (شماره عضو " + agent.no + ") ساخته شد.\n\n" +
    "این پیام رو براش بفرست:\n\n" +
    (link ? "با این لینک وارد ربات شو:\n" + link + "\n\nیا " : "") +
    "داخل ربات این دستور رو بفرست:\n/join " + agent.code +
    "\n\n⚠️ این کد فقط یک‌بار قابل استفاده‌ست."
  );
  showTeam_(chatId, 0);
}

function showAgentDetail_(chatId, code) {
  const agent = getAgentByCode_(code);
  if (!agent) return sendMessage_(chatId, "عضو پیدا نشد.");

  if (agent.status === "invited") {
    const username = getBotUsername_();
    sendMessage_(
      chatId,
      "⏳ " + agentLabel_(agent) + " هنوز به ربات نپیوسته.\n\n" +
      (username ? "لینک: https://t.me/" + username + "?start=join_" + agent.code + "\n" : "") +
      "دستور: /join " + agent.code,
      { inline_keyboard: [[{ text: "🗑 حذف دعوت", callback_data: "agdelc:" + agent.code }]] }
    );
    return;
  }

  const text = (AGENT_STATUS_LABELS[agent.status] || agent.status) + "\n\n" +
    agentStatsText_(agent, getAllLeads_(), getAllCalls_()) +
    (agent.username ? "\n\n✈️ @" + agent.username : "");

  const id = agent.agentId;
  sendMessage_(chatId, text, {
    inline_keyboard: [
      [
        { text: "⏳ در انتظار", callback_data: "ls:pending:0:" + id },
        { text: "✅ انجام‌شده", callback_data: "ls:done:0:" + id }
      ],
      [
        { text: "📋 همه موارد او", callback_data: "ls:all:0:" + id },
        { text: "📞 تماس‌های او", callback_data: "cl:all:0:" + id }
      ],
      [
        { text: "📌 اختصاص با کد", callback_data: "mla:" + agent.code },
        { text: "➕ اختصاص تعداد", callback_data: "bulk:" + agent.code }
      ],
      [
        { text: "🔑 کلید ورود به اپ", callback_data: "agkey:" + agent.code },
        { text: "📤 خروجی CSV این عضو", callback_data: "ex:agent:" + agent.code },
        { text: "↩️ آزادکردن در انتظارها", callback_data: "agfree:" + agent.code }
      ],
      [
        { text: agent.status === "active" ? "⛔ غیرفعال کردن" : "🟢 فعال کردن", callback_data: "agtog:" + agent.code },
        { text: "🗑 حذف", callback_data: "agdel:" + agent.code }
      ]
    ]
  });
}

function toggleAgent_(chatId, code) {
  const agent = getAgentByCode_(code);
  if (!agent || !agent.agentId) return sendMessage_(chatId, "عضو پیدا نشد.");
  const newStatus = agent.status === "active" ? "disabled" : "active";
  updateAgentRow_(agent.rowNumber, { 5: newStatus });
  sendMessage_(
    chatId,
    newStatus === "active"
      ? "🟢 " + agent.name + " فعال شد."
      : "⛔ " + agent.name + " غیرفعال شد و دیگه به شماره‌ها دسترسی نداره."
  );
  showAgentDetail_(chatId, code);
}

function freeAgentLeads_(chatId, code) {
  const agent = getAgentByCode_(code);
  if (!agent || !agent.agentId) return sendMessage_(chatId, "عضو پیدا نشد.");

  const pending = getAllLeads_().filter(function(l) {
    return l.assignedTo === agent.agentId && PENDING_STATUSES.indexOf(l.status) !== -1;
  });

  const sheet = getSheet_(APP.SHEETS.LEADS);
  pending.forEach(function(l) {
    sheet.getRange(l.rowNumber, COL.STATUS).setValue("new");
    sheet.getRange(l.rowNumber, COL.ASSIGNED, 1, 2).setValues([["", ""]]);
    sheet.getRange(l.rowNumber, COL.UPDATED).setValue(new Date());
  });

  sendMessage_(chatId, "↩️ " + pending.length + " مورد از " + agent.name + " آزاد شد و به لیست «جدید» برگشت.");
}

function deleteAgent_(chatId, code) {
  const agent = getAgentByCode_(code);
  if (!agent) return sendMessage_(chatId, "عضو پیدا نشد.");
  if (agent.agentId) freeAgentLeads_(chatId, code);
  getTeamSheet_().deleteRow(agent.rowNumber);
  sendMessage_(chatId, "🗑 «" + agent.name + "» حذف شد.");
  showTeam_(chatId, 0);
}

function showAssignMenu_(chatId, leadId, page) {
  const agents = activeAgentsSorted_();
  if (!agents.length) {
    sendMessage_(chatId, "هنوز عضو فعالی نداری. از «👥 تیم» عضو اضافه کن.");
    return;
  }

  const pending = pendingCountMap_(getAllLeads_());
  const pageSize = 10;
  const totalPages = Math.ceil(agents.length / pageSize);
  const safePage = Math.max(0, Math.min(Number(page || 0), totalPages - 1));
  const selected = agents.slice(safePage * pageSize, safePage * pageSize + pageSize);

  const rows = selected.map(function(a) {
    return [{
      text: "👤 " + agentLabel_(a) + " (" + (pending[a.agentId] || 0) + ")",
      callback_data: "asg:" + leadId + ":" + a.code
    }];
  });

  const nav = [];
  if (safePage > 0) nav.push({ text: "◀️ قبلی", callback_data: "as:" + leadId + ":" + (safePage - 1) });
  if (safePage < totalPages - 1) nav.push({ text: "بعدی ▶️", callback_data: "as:" + leadId + ":" + (safePage + 1) });
  if (nav.length) rows.push(nav);

  rows.push([{ text: "↩️ برداشتن مسئول", callback_data: "asg:" + leadId + ":none" }]);
  rows.push([{ text: "🔙 برگشت", callback_data: "ld:" + leadId }]);
  sendMessage_(chatId, "این شماره رو به کی بدم؟\n(عدد داخل پرانتز: شماره‌های در انتظار فعلی او)", { inline_keyboard: rows });
}

function assignLeadTo_(lead, agent) {
  const sheet = getSheet_(APP.SHEETS.LEADS);
  let newStatus = lead.status;
  if (agent && lead.status === "new") newStatus = "assigned";
  if (!agent && lead.status === "assigned") newStatus = "new";

  sheet.getRange(lead.rowNumber, COL.STATUS).setValue(newStatus);
  sheet.getRange(lead.rowNumber, COL.ASSIGNED, 1, 2).setValues([[
    agent ? agent.agentId : "",
    agent ? new Date() : ""
  ]]);
  sheet.getRange(lead.rowNumber, COL.UPDATED).setValue(new Date());
}

function notifyAgentAssigned_(agent, leads) {
  const target = notifyTarget_(agent);
  if (!target || !leads.length) return;
  const sorted = leads.slice().sort(function(a, b) { return a.seq - b.seq; });

  if (sorted.length === 1) {
    sendMessage_(
      target,
      "📥 یک شماره جدید به تو اختصاص داده شد:\n\n#" + sorted[0].seq + " " + sorted[0].name,
      agentNotifyButtons_(agent, { text: "👁 مشاهده", callback_data: "ld:" + sorted[0].leadId })
    );
  } else {
    sendMessage_(
      target,
      "📥 " + sorted.length + " شماره جدید به تو اختصاص داده شد:\n\n" +
      codesText_(sorted.slice(0, 30).map(function(l) { return l.seq; })) +
      (sorted.length > 30 ? " …" : ""),
      agentNotifyButtons_(agent, { text: "▶️ شروع تماس‌ها", callback_data: "nx" })
    );
  }
}

// مقصد اعلان: عضو تلگرامی → خودش؛ عضو اپ → چت تلگرامی که وصل کرده
function notifyTarget_(agent) {
  if (isTgId_(agent.agentId)) return agent.agentId;
  if (isTgId_(agent.tgChat)) return agent.tgChat;
  return "";
}

// عضو تلگرامی دکمه‌ی داخل ربات می‌گیره؛ عضو اپ دکمه‌ی باز کردن اپ
function agentNotifyButtons_(agent, tgButton) {
  if (isTgId_(agent.agentId)) return { inline_keyboard: [[tgButton]] };
  const url = appUrl_();
  return url ? { inline_keyboard: [[{ text: "📱 باز کردن پنل", url: url }]] } : undefined;
}

function getUnassignedLeads_() {
  return getAllLeads_().filter(function(l) { return l.status === "new" && !l.assignedTo; });
}

function bulkAssign_(chatId, agent, count) {
  const pool = getUnassignedLeads_().sort(function(a, b) { return a.seq - b.seq; }).slice(0, count);
  if (!pool.length) {
    sendMessage_(chatId, "شماره‌ی بدون مسئول (جدید) وجود نداره.");
    return;
  }

  pool.forEach(function(l) { assignLeadTo_(l, agent); });
  notifyAgentAssigned_(agent, pool);
  sendMessage_(
    chatId,
    "✅ " + pool.length + " شماره به " + agentLabel_(agent) + " اختصاص داده شد:\n" +
    codesText_(pool.map(function(l) { return l.seq; }))
  );
}

function agentStats_(agent, leads, calls) {
  const today = dayKey_(new Date());

  const mine = leads.filter(function(l) { return agent.agentId && l.assignedTo === agent.agentId; });
  const pending = mine.filter(function(l) { return PENDING_STATUSES.indexOf(l.status) !== -1; }).length;
  const myCalls = calls.filter(function(c) { return c.agentId === agent.agentId; });

  const by = {};
  OUTCOME_KEYS.forEach(function(k) { by[k] = 0; });
  let todayCalls = 0;

  myCalls.forEach(function(c) {
    if (by[c.outcome] !== undefined) by[c.outcome]++;
    const d = new Date(c.createdAt);
    if (!isNaN(d.getTime()) && dayKey_(d) === today) todayCalls++;
  });

  return { assigned: mine.length, pending: pending, todayCalls: todayCalls, totalCalls: myCalls.length, by: by };
}

function agentStatsText_(agent, leads, calls) {
  const s = agentStats_(agent, leads, calls);
  let text = "👤 " + agentLabel_(agent) + "\n\n" +
    "📥 اختصاص‌داده‌شده: " + s.assigned + "\n" +
    "⏳ در انتظار تماس: " + s.pending + "\n" +
    "📞 تماس امروز: " + s.todayCalls + "\n" +
    "📞 کل تماس‌ها: " + s.totalCalls + "\n\n";

  OUTCOME_KEYS.forEach(function(k) {
    text += STATUSES[k].emoji + " " + STATUSES[k].label + ": " + s.by[k] + "\n";
  });
  return text.trim();
}

function showTeamReport_(chatId) {
  const agents = getAllAgents_()
    .filter(function(a) { return a.status !== "invited" && a.agentId; })
    .sort(function(a, b) { return a.no - b.no; });
  const leads = getAllLeads_();
  const calls = getAllCalls_();

  if (!agents.length) {
    sendMessage_(chatId, "هنوز عضوی به تیم نپیوسته.");
    return;
  }

  let text = "📈 گزارش تیم — " + formatDay_(new Date()) + "\n" +
    "(اختصاص | در انتظار | تماس امروز | کل تماس)  ✅ 💰 🔁 📵 ❌\n";

  agents.forEach(function(a) {
    const s = agentStats_(a, leads, calls);
    text += "\n" + (a.status === "active" ? "🟢" : "⛔") + " " + agentLabel_(a) + "\n" +
      "   " + s.assigned + " | " + s.pending + " | " + s.todayCalls + " | " + s.totalCalls +
      "   ✅" + s.by.called + " 🔁" + s.by.followup +
      " 📵" + s.by.no_answer + " ❌" + s.by.not_interested;
  });

  const unassigned = leads.filter(function(l) { return l.status === "new"; }).length;
  text += "\n\n🆕 بدون مسئول: " + unassigned;

  sendLongText_(chatId, text, {
    inline_keyboard: [[{ text: "📤 خروجی CSV گزارش اعضا", callback_data: "ex:team" }]]
  });
}

// =====================================================
//  آمار، خروجی، تنظیمات
// =====================================================

function showStats_(chatId) {
  const leads = getAllLeads_();
  const today = dayKey_(new Date());
  const weekAgo = Date.now() - 7 * 24 * 3600 * 1000;

  let todayCount = 0;
  let weekCount = 0;
  const counts = {};
  Object.keys(STATUSES).forEach(function(k) { counts[k] = 0; });

  leads.forEach(function(l) {
    if (counts[l.status] !== undefined) counts[l.status]++;
    const d = new Date(l.createdAt);
    if (!isNaN(d.getTime())) {
      if (dayKey_(d) === today) todayCount++;
      if (d.getTime() >= weekAgo) weekCount++;
    }
  });

  let text = "📊 آمار\n\n" +
    "کل درخواست‌ها: " + leads.length + "\n" +
    "امروز: " + todayCount + "\n" +
    "۷ روز اخیر: " + weekCount + "\n\n";

  Object.keys(STATUSES).forEach(function(k) {
    text += STATUSES[k].emoji + " " + STATUSES[k].label + ": " + counts[k] + "\n";
  });

  sendMessage_(chatId, text);
}

function showExportMenu_(chatId) {
  sendMessage_(chatId, "📤 کدوم خروجی رو می‌خوای؟ (فایل CSV برای اکسل)", {
    inline_keyboard: [
      [{ text: "📄 همه شماره‌ها + مسئول + نتیجه آخر", callback_data: "ex:leads" }],
      [{ text: "📞 ریز همه تماس‌ها (با تاریخ و ساعت)", callback_data: "ex:calls" }],
      [{ text: "👥 گزارش خلاصه همه اعضا", callback_data: "ex:team" }],
      [{ text: "📅 فقط امروز (شماره‌ها + تماس‌ها)", callback_data: "ex:today" }]
    ]
  });
}

function handleExport_(chatId, kind, code) {
  const leads = getAllLeads_();
  const calls = getAllCalls_();

  if (kind === "leads") {
    if (!leads.length) return sendMessage_(chatId, "هنوز درخواستی ثبت نشده.");
    sendLeadsCsv_(chatId, leads, calls, "leads.csv", "📄 " + leads.length + " شماره با مسئول و نتیجه آخر");
    return;
  }

  if (kind === "calls") {
    if (!calls.length) return sendMessage_(chatId, "هنوز تماسی ثبت نشده.");
    sendCallsCsv_(chatId, calls, leads, "calls.csv", "📞 " + calls.length + " تماس ثبت‌شده");
    return;
  }

  if (kind === "team") {
    sendTeamCsv_(chatId, leads, calls);
    return;
  }

  if (kind === "today") {
    const todayLeads = leads.filter(function(l) { return inRange_(l.createdAt, "today"); });
    const todayCalls = calls.filter(function(c) { return inRange_(c.createdAt, "today"); });
    if (!todayLeads.length && !todayCalls.length) return sendMessage_(chatId, "امروز هنوز چیزی ثبت نشده.");
    if (todayLeads.length) sendLeadsCsv_(chatId, todayLeads, calls, "leads_today.csv", "📄 شماره‌های امروز (" + todayLeads.length + ")");
    if (todayCalls.length) sendCallsCsv_(chatId, todayCalls, leads, "calls_today.csv", "📞 تماس‌های امروز (" + todayCalls.length + ")");
    return;
  }

  if (kind === "agent") {
    const agent = getAgentByCode_(code);
    if (!agent || !agent.agentId) return sendMessage_(chatId, "عضو پیدا نشد.");
    const mine = leads.filter(function(l) { return l.assignedTo === agent.agentId; });
    const myCalls = calls.filter(function(c) { return c.agentId === agent.agentId; });
    if (!mine.length && !myCalls.length) return sendMessage_(chatId, "این عضو هنوز چیزی نداره.");
    if (mine.length) sendLeadsCsv_(chatId, mine, calls, "agent_" + agent.no + "_leads.csv", "📄 شماره‌های " + agent.name + " (" + mine.length + ")");
    if (myCalls.length) sendCallsCsv_(chatId, myCalls, leads, "agent_" + agent.no + "_calls.csv", "📞 تماس‌های " + agent.name + " (" + myCalls.length + ")");
  }
}

function agentMapById_() {
  const map = {};
  getAllAgents_().forEach(function(a) { if (a.agentId) map[a.agentId] = a; });
  return map;
}

function sendLeadsCsv_(chatId, leads, calls, filename, caption) {
  const agentById = agentMapById_();
  const callsByLead = {};
  calls.forEach(function(c) {
    (callsByLead[c.leadId] = callsByLead[c.leadId] || []).push(c);
  });

  const rows = leads.slice().sort(function(a, b) { return a.seq - b.seq; }).map(function(l) {
    const cs = callsByLead[l.leadId] || [];
    const first = cs[0];
    const last = cs[cs.length - 1];
    const ag = agentById[l.assignedTo];
    const st = STATUSES[l.status];
    const lastSt = last ? STATUSES[last.outcome] : null;
    return [
      l.seq, l.leadId, formatDateTime_(l.createdAt), l.name, '="' + l.phone + '"', // این فرمت باعث می‌شه اکسل صفر اول شماره رو حذف نکنه
      l.age, l.city, l.goal,
      ag ? ag.name : "", ag ? ag.no : "",
      l.assignedAt ? formatDateTime_(l.assignedAt) : "",
      st ? st.label : l.status,
      cs.length,
      first ? formatDateTime_(first.createdAt) : "",
      last ? formatDateTime_(last.createdAt) : "",
      lastSt ? lastSt.label : "",
      last ? last.note : "",
      l.note
    ];
  });

  sendCsv_(chatId, filename,
    ["کد", "شناسه", "تاریخ ثبت", "نام", "تلفن", "سن", "شهر", "موضوع", "مسئول", "شماره عضو",
     "تاریخ اختصاص", "وضعیت", "تعداد تماس", "اولین تماس", "آخرین تماس", "نتیجه آخر", "یادداشت آخر", "یادداشت مدیر"],
    rows, caption + "\n\nجدول کامل: " + getDatabase_().getUrl());
}

function sendCallsCsv_(chatId, calls, leads, filename, caption) {
  const leadById = {};
  leads.forEach(function(l) { leadById[l.leadId] = l; });
  const agentById = agentMapById_();

  const rows = calls.map(function(c) {
    const l = leadById[c.leadId];
    const ag = agentById[c.agentId];
    const st = STATUSES[c.outcome];
    return [
      formatDateTime_(c.createdAt), c.callId,
      l ? l.seq : "", c.leadName, l ? '="' + l.phone + '"' : "",
      c.agentName, ag ? ag.no : "",
      st ? st.label : c.outcome, c.note
    ];
  });

  sendCsv_(chatId, filename,
    ["تاریخ و ساعت تماس", "کد تماس", "کد شماره", "مشتری", "تلفن", "عضو تیم", "شماره عضو", "نتیجه", "یادداشت"],
    rows, caption);
}

function sendTeamCsv_(chatId, leads, calls) {
  const agents = getAllAgents_()
    .filter(function(a) { return a.agentId; })
    .sort(function(a, b) { return a.no - b.no; });
  if (!agents.length) return sendMessage_(chatId, "هنوز عضوی به تیم نپیوسته.");

  const rows = agents.map(function(a) {
    const s = agentStats_(a, leads, calls);
    const myCalls = calls.filter(function(c) { return c.agentId === a.agentId; });
    const last = myCalls[myCalls.length - 1];
    return [
      a.no, a.name, a.username ? "@" + a.username : "", AGENT_STATUS_LABELS[a.status] || a.status,
      a.joinedAt ? formatDateTime_(a.joinedAt) : "",
      s.assigned, s.pending, s.todayCalls, s.totalCalls,
      s.by.called, s.by.followup, s.by.no_answer, s.by.not_interested,
      last ? formatDateTime_(last.createdAt) : ""
    ];
  });

  sendCsv_(chatId, "team.csv",
    ["شماره عضو", "نام", "یوزرنیم", "وضعیت", "تاریخ پیوستن", "اختصاص‌داده‌شده", "در انتظار",
     "تماس امروز", "کل تماس", "قرارداد بست", "نیاز به پیگیری", "جواب نداد", "انصراف", "آخرین تماس"],
    rows, "👥 گزارش خلاصه " + agents.length + " عضو");
}

function sendCsv_(chatId, filename, header, rows, caption) {
  const lines = [header.map(csvCell_).join(",")];
  rows.forEach(function(r) { lines.push(r.map(csvCell_).join(",")); });

  const blob = Utilities.newBlob("\uFEFF" + lines.join("\r\n"), "text/csv", filename);
  UrlFetchApp.fetch("https://api.telegram.org/bot" + getBotToken_() + "/sendDocument", {
    method: "post",
    payload: { chat_id: String(chatId), document: blob, caption: truncate_(caption, 1000) },
    muteHttpExceptions: true
  });
}

function csvCell_(value) {
  return '"' + String(value === undefined || value === null ? "" : value).replace(/"/g, '""') + '"';
}

function showAdminSettings_(chatId, prefix) {
  let text = (prefix ? prefix + "\n\n" : "") + "⚙️ تنظیمات فعلی\n";
  const keys = Object.keys(EDITABLE_SETTINGS);

  keys.forEach(function(k) {
    const item = EDITABLE_SETTINGS[k];
    text += "\n• " + item[1] + ":\n" + truncate_(getSetting_(item[0]), 90) + "\n";
  });

  const notifyOn = getSetting_("NOTIFY_CALLS") !== "false";
  const jalali = getSetting_("DATE_MODE") !== "gregorian";
  text += "\n• اعلان تماس‌های تیم به مدیر: " + (notifyOn ? "🔔 روشن" : "🔕 خاموش");
  text += "\n• نمایش تاریخ: " + (jalali ? "شمسی" : "میلادی");

  const rows = [];
  for (let i = 0; i < keys.length; i += 2) {
    const row = [{ text: EDITABLE_SETTINGS[keys[i]][1], callback_data: "set:" + keys[i] }];
    if (keys[i + 1]) {
      row.push({ text: EDITABLE_SETTINGS[keys[i + 1]][1], callback_data: "set:" + keys[i + 1] });
    }
    rows.push(row);
  }
  rows.push([{
    text: notifyOn ? "🔕 خاموش کردن اعلان تماس‌ها" : "🔔 روشن کردن اعلان تماس‌ها",
    callback_data: "tg:notify"
  }]);
  rows.push([{
    text: jalali ? "📅 تغییر به تاریخ میلادی" : "📅 تغییر به تاریخ شمسی",
    callback_data: "tg:date"
  }]);
  rows.push([{ text: "📱 ورود به اپ (کلید مدیر)", callback_data: "app" }]);

  sendMessage_(chatId, text, { inline_keyboard: rows });
}

function startSettingEdit_(from, chatId, key) {
  const item = EDITABLE_SETTINGS[key];
  if (!item) return;
  setSession_(from, "ADMIN_SETTING", { key: key });
  sendMessage_(chatId, "متن جدید برای «" + item[1] + "» رو بفرست.", cancelKeyboard_());
}

function showHealthCheck_(chatId) {
  const checks = [];
  checks.push(getBotToken_() ? "✅ توکن ربات" : "❌ توکن ربات");
  checks.push(ScriptApp.getService().getUrl() ? "✅ Web App" : "❌ Web App");
  checks.push(getSetting_("ADMIN_ID") ? "✅ مدیر ربات" : "❌ مدیر ربات");
  checks.push(getSheet_(APP.SHEETS.LEADS) ? "✅ دیتابیس درخواست‌ها" : "❌ دیتابیس درخواست‌ها");

  const activeAgents = getAllAgents_().filter(function(a) { return a.status === "active"; }).length;
  checks.push("👥 اعضای فعال تیم: " + activeAgents);
  checks.push("🤖 اختصاص خودکار: " + (getSetting_("AUTO_ASSIGN") === "true" ? "روشن" : "خاموش"));
  checks.push("🕒 منطقه زمانی: " + tz_());

  const info = telegramRequest_("getWebhookInfo", {});
  if (info.ok && info.result) {
    checks.push(info.result.url ? "✅ اتصال تلگرام" : "❌ اتصال تلگرام");
    if (info.result.last_error_message) {
      checks.push("⚠️ آخرین خطا: " + info.result.last_error_message);
    }
  }

  sendMessage_(chatId, "وضعیت ربات\n\n" + checks.join("\n"));
}

// =====================================================
//  بخش کاربر (پر کردن فرم)
// =====================================================

function handleCustomerMenuMessage_(message) {
  const chatId = String(message.chat.id);
  const text = String(message.text || "").trim();

  if (!getSetting_("ADMIN_ID")) {
    sendMessage_(chatId, "این ربات هنوز راه‌اندازی نشده.");
    return;
  }

  if (text === "📝 ثبت درخواست مشاوره") {
    startForm_(message.from, chatId);
    return;
  }

  showCustomerMenu_(chatId, "یکی از گزینه‌های منو رو انتخاب کن.");
}

function startForm_(from, chatId) {
  setSession_(from, "CUSTOMER_NAME", {});
  sendMessage_(chatId, getSetting_("Q_NAME"), cancelKeyboard_());
}

function phoneKeyboard_() {
  return {
    keyboard: [
      [{ text: "📱 ارسال شماره من", request_contact: true }],
      [{ text: "❌ لغو عملیات" }]
    ],
    resize_keyboard: true,
    one_time_keyboard: true
  };
}

function handleCustomerState_(message, session) {
  const chatId = String(message.chat.id);
  const text = String(message.text || "").trim();
  const data = session.data || {};
  const userId = String(message.from.id);

  switch (session.state) {
    case "CUSTOMER_CONSENT":
      if (text.indexOf("موافقم") === -1) {
        return sendMessage_(chatId, "برای ادامه روی «موافقم ✅» بزن یا عملیات رو لغو کن.");
      }
      setSession_(message.from, "CUSTOMER_NAME", {});
      sendMessage_(chatId, getSetting_("Q_NAME"), cancelKeyboard_());
      return;

    case "CUSTOMER_NAME":
      if (!text) return sendMessage_(chatId, "لطفاً اسمت رو به‌صورت متن بفرست.");
      data.name = text;
      setSession_(message.from, "CUSTOMER_PHONE", data);
      sendMessage_(
        chatId,
        "شماره تماست رو بفرست.\nمی‌تونی دکمه پایین رو بزنی یا شماره رو تایپ کنی.",
        phoneKeyboard_()
      );
      return;

    case "CUSTOMER_PHONE": {
      let phone = "";
      if (message.contact && message.contact.phone_number) {
        phone = String(message.contact.phone_number);
        if (phone.charAt(0) !== "+" && phone.charAt(0) !== "0") phone = "+" + phone;
      } else {
        phone = normalizePhone_(text);
      }

      if (!phone) {
        return sendMessage_(
          chatId,
          "شماره معتبر نیست 🙏 دوباره بفرست (مثلاً 09123456789).",
          phoneKeyboard_()
        );
      }

      data.phone = phone;
      let lead = saveLead_(message.from, data);
      clearSession_(userId);

      const role = getRole_(userId);
      if (role === "customer") {
        sendMessage_(chatId, getSetting_("THANKS_TEXT"), customerKeyboard_());
      } else {
        showMenuForRole_(chatId, role, "✅ فرم تستی ثبت شد (مثل یک درخواست واقعی تو لیست هست).");
      }

      // اختصاص خودکار نوبتی
      if (getSetting_("AUTO_ASSIGN") === "true") {
        const agent = pickAutoAgent_();
        if (agent) {
          assignLeadTo_(lead, agent);
          notifyAgentAssigned_(agent, [lead]);
          lead = getLeadById_(lead.leadId) || lead;
        }
      }

      notifyAdminAboutLead_(lead);
      return;
    }

    default:
      clearSession_(userId);
      showCustomerMenu_(chatId, "مرحله قبلی معتبر نبود و لغو شد.");
  }
}

function saveLead_(from, data) {
  const leadId = "L" + Utilities.getUuid().replace(/-/g, "").slice(0, 6).toUpperCase();
  const now = new Date();
  const sheet = getSheet_(APP.SHEETS.LEADS);
  const row = sheet.getLastRow() + 1;

  const seq = Number(getSetting_("LEAD_SEQ") || 0) + 1;
  setSetting_("LEAD_SEQ", String(seq));

  sheet.getRange(row, COL.PHONE).setNumberFormat("@");
  sheet.getRange(row, COL.ASSIGNED).setNumberFormat("@");
  sheet.getRange(row, 1, 1, LEAD_HEADERS.length).setValues([[
    leadId,
    String(from.id),
    from.username || "",
    data.name || "",
    data.age || "",
    data.city || "",
    data.goal || "",
    String(data.phone || ""),
    "new",
    "",
    now,
    now,
    "",
    "",
    "",
    0,
    seq
  ]]);

  return getLeadById_(leadId);
}

function saveTeamLead_(agentId, data) {
  const leadId = "L" + Utilities.getUuid().replace(/-/g, "").slice(0, 6).toUpperCase();
  const now = new Date();
  const sheet = getSheet_(APP.SHEETS.LEADS);
  const row = sheet.getLastRow() + 1;
  const seq = Number(getSetting_("TEAM_SEQ") || 0) + 1;
  setSetting_("TEAM_SEQ", String(seq));
  sheet.getRange(row, COL.PHONE).setNumberFormat("@");
  sheet.getRange(row, COL.ASSIGNED).setNumberFormat("@");
  sheet.getRange(row, 1, 1, LEAD_HEADERS.length).setValues([[
    leadId, TEAM_LEAD_USER, String(agentId || "admin"), data.name || "", "", "", data.goal || "",
    String(data.phone || ""), "assigned", "", now, now, agentId ? String(agentId) : "", agentId ? now : "", "", 0, seq
  ]]);
  MEMO = {};
  return getLeadById_(leadId);
}

function notifyAdminAboutLead_(lead) {
  const adminId = getSetting_("ADMIN_ID");
  if (!adminId || !lead) return;
  sendMessage_(adminId, "🔔 درخواست مشاوره جدید\n\n" + leadText_(lead, "admin"), leadButtons_(lead, "admin"));
}

// =====================================================
//  دیتابیس (Google Sheets)
// =====================================================

function getDatabase_() {
  const id = PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");
  return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
}

function getSheet_(name) {
  const sheet = getDatabase_().getSheetByName(name);
  if (!sheet) throw new Error("Sheet not found: " + name);
  return sheet;
}

// برای شیت‌هایی که تو نسخه قبلی نبودن: اگه نباشن خودش می‌سازه
function getSheetEnsured_(name, headers) {
  const ss = getDatabase_();
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold");
  }
  return sheet;
}

function getTeamSheet_() { return getSheetEnsured_(APP.SHEETS.TEAM, TEAM_HEADERS); }
function getCallsSheet_() { return getSheetEnsured_(APP.SHEETS.CALLS, CALL_HEADERS); }

function ensureSheet_(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);

  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  } else {
    const current = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), headers.length)).getValues()[0];
    headers.forEach(function(header, index) {
      if (!current[index]) sheet.getRange(1, index + 1).setValue(header);
    });
  }

  sheet.setFrozenRows(1);
  return sheet;
}

function styleSheets_() {
  Object.keys(APP.SHEETS).forEach(function(key) {
    const sheet = getSheet_(APP.SHEETS[key]);
    const lastColumn = Math.max(1, sheet.getLastColumn());
    sheet.getRange(1, 1, 1, lastColumn).setFontWeight("bold");
    sheet.autoResizeColumns(1, lastColumn);
  });
}

function loadSettings_() {
  if (SETTINGS_CACHE) return SETTINGS_CACHE;
  const sheet = getSheet_(APP.SHEETS.SETTINGS);
  const map = {};
  if (sheet.getLastRow() >= 2) {
    sheet.getRange(2, 1, sheet.getLastRow() - 1, 2).getValues().forEach(function(r) {
      map[String(r[0])] = r[1] === undefined || r[1] === null ? "" : String(r[1]);
    });
  }
  SETTINGS_CACHE = map;
  return map;
}

function getSetting_(key) {
  const map = loadSettings_();
  return map[key] !== undefined ? map[key] : "";
}

function setSetting_(key, value) {
  const sheet = getSheet_(APP.SHEETS.SETTINGS);
  const str = String(value);
  loadSettings_();

  if (sheet.getLastRow() >= 2) {
    const keys = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues();
    for (let i = 0; i < keys.length; i++) {
      if (String(keys[i][0]) === String(key)) {
        sheet.getRange(i + 2, 2).setNumberFormat("@").setValue(str);
        SETTINGS_CACHE[key] = str;
        return;
      }
    }
  }
  const row = sheet.getLastRow() + 1;
  sheet.getRange(row, 1).setValue(key);
  sheet.getRange(row, 2).setNumberFormat("@").setValue(str);
  SETTINGS_CACHE[key] = str;
}

function getSession_(userId) {
  const sheet = getSheet_(APP.SHEETS.SESSIONS);
  if (sheet.getLastRow() < 2) return null;
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, 6).getValues();

  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) === String(userId)) {
      let data = {};
      try { data = JSON.parse(values[i][4] || "{}"); } catch (e) { data = {}; }
      return { rowNumber: i + 2, state: String(values[i][3] || ""), data: data };
    }
  }
  return null;
}

function setSession_(from, state, data) {
  const sheet = getSheet_(APP.SHEETS.SESSIONS);
  const userId = String(from.id);
  const existing = getSession_(userId);
  const row = [
    userId,
    from.username || "",
    from.first_name || "",
    state,
    JSON.stringify(data || {}),
    new Date()
  ];

  if (existing) {
    sheet.getRange(existing.rowNumber, 1, 1, 6).setValues([row]);
  } else {
    sheet.appendRow(row);
  }
}

function clearSession_(userId) {
  const session = getSession_(userId);
  if (!session) return;
  getSheet_(APP.SHEETS.SESSIONS).deleteRow(session.rowNumber);
}

// ---------- درخواست‌ها ----------

// «دفتر تیم»: شماره‌هایی که اعضا خودشون اضافه می‌کنن، کاملاً جدا از شماره‌های ربات.
// userId = "team" ، username = شناسه عضوی که اضافه کرده
const TEAM_LEAD_USER = "team";
function isTeamLead_(l) { return !!l && l.userId === TEAM_LEAD_USER; }
function leadTag_(l) { return "#" + (isTeamLead_(l) ? "ت" : "") + l.seq; }

// فقط شماره‌های ربات/مدیر (همه‌ی بخش‌های قبلی برنامه از این استفاده می‌کنن)
function getAllLeads_() {
  return getAllLeadsRaw_().filter(function(l) { return !isTeamLead_(l); });
}

function getTeamLeads_() {
  return getAllLeadsRaw_().filter(isTeamLead_);
}

function teamLeadIds_() {
  const ids = {};
  getTeamLeads_().forEach(function(l) { ids[l.leadId] = true; });
  return ids;
}

function getAllLeadsRaw_() {
  if (MEMO_ON && MEMO.leads) return MEMO.leads;
  const sheet = getSheet_(APP.SHEETS.LEADS);
  if (sheet.getLastRow() < 2) return [];
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, LEAD_HEADERS.length).getValues();
  const out = values
    .map(leadFromRow_)
    .filter(function(l) { return l.leadId; });
  if (MEMO_ON) MEMO.leads = out;
  return out;
}

function getLeadById_(leadId) {
  return getAllLeadsRaw_().find(function(l) {
    return String(l.leadId) === String(leadId);
  }) || null;
}

function leadFromRow_(row, index) {
  return {
    rowNumber: index + 2,
    leadId: String(row[0] || ""),
    userId: String(row[1] || ""),
    username: String(row[2] || ""),
    name: String(row[3] || ""),
    age: String(row[4] || ""),
    city: String(row[5] || ""),
    goal: String(row[6] || ""),
    phone: String(row[7] || ""),
    status: String(row[8] || "new"),
    note: String(row[9] || ""),
    createdAt: row[10],
    updatedAt: row[11],
    assignedTo: String(row[12] || ""),
    assignedAt: row[13],
    lastOutcome: String(row[14] || ""),
    callsCount: Number(row[15] || 0),
    seq: Number(row[16] || 0)
  };
}

function updateLeadField_(leadId, column, value) {
  const lead = getLeadById_(leadId);
  if (!lead) return;
  const sheet = getSheet_(APP.SHEETS.LEADS);
  sheet.getRange(lead.rowNumber, column).setValue(value);
  sheet.getRange(lead.rowNumber, COL.UPDATED).setValue(new Date());
}

function deleteLead_(leadId) {
  const lead = getLeadById_(leadId);
  if (!lead) return;
  getSheet_(APP.SHEETS.LEADS).deleteRow(lead.rowNumber);
}

// ---------- تیم ----------

function getAllAgents_() {
  if (MEMO_ON && MEMO.agents) return MEMO.agents;
  const sheet = getTeamSheet_();
  if (sheet.getLastRow() < 2) return [];
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, TEAM_HEADERS.length).getValues();
  const out = values.map(function(r, i) {
    return {
      rowNumber: i + 2,
      agentId: String(r[0] || ""),
      name: String(r[1] || ""),
      username: String(r[2] || ""),
      code: String(r[3] || ""),
      status: String(r[4] || "invited"),
      createdAt: r[5],
      joinedAt: r[6],
      no: Number(r[7] || 0),
      appKey: String(r[8] || ""),
      tgChat: String(r[9] || ""),
      group: String(r[10] || "")
    };
  }).filter(function(a) { return a.code; });
  if (MEMO_ON) MEMO.agents = out;
  return out;
}

function getAgentByUserId_(userId) {
  const id = String(userId);
  return getAllAgents_().find(function(a) { return a.agentId && a.agentId === id; }) || null;
}

function getAgentByCode_(code) {
  const c = String(code || "");
  return getAllAgents_().find(function(a) { return a.code === c; }) || null;
}

function updateAgentRow_(rowNumber, valuesByColumn) {
  const sheet = getTeamSheet_();
  Object.keys(valuesByColumn).forEach(function(col) {
    const cell = sheet.getRange(rowNumber, Number(col));
    if (Number(col) === TCOL.ID) cell.setNumberFormat("@");
    cell.setValue(valuesByColumn[col]);
  });
}

// ---------- تماس‌ها ----------

// فقط تماس‌های شماره‌های ربات/مدیر
function getAllCalls_() {
  const team = teamLeadIds_();
  return getAllCallsRaw_().filter(function(c) { return !team[c.leadId]; });
}

function getTeamCalls_() {
  const team = teamLeadIds_();
  return getAllCallsRaw_().filter(function(c) { return team[c.leadId]; });
}

function getAllCallsRaw_() {
  if (MEMO_ON && MEMO.calls) return MEMO.calls;
  const sheet = getCallsSheet_();
  if (sheet.getLastRow() < 2) return [];
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, CALL_HEADERS.length).getValues();
  const out = values.map(function(r, i) {
    return {
      callId: String(r[0] || ""),
      leadId: String(r[1] || ""),
      leadName: String(r[2] || ""),
      agentId: String(r[3] || ""),
      agentName: String(r[4] || ""),
      outcome: String(r[5] || ""),
      note: String(r[6] || ""),
      createdAt: r[7],
      editedAt: r[8] || "",
      visitAt: r[9] ? toMs_(r[9]) : 0,
      visitNotified: r[10] ? true : false,
      rowNumber: i + 2
    };
  }).filter(function(c) { return c.callId; });
  if (MEMO_ON) MEMO.calls = out;
  return out;
}

// =====================================================
//  ابزارهای کمکی (تاریخ، متن، عدد)
// =====================================================

function isAdmin_(userId) {
  const adminId = getSetting_("ADMIN_ID");
  return adminId !== "" && adminId === String(userId);
}

function generateClaimCode_() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function normalizeDigits_(value) {
  return String(value || "")
    .replace(/[۰-۹]/g, function(d) { return "۰۱۲۳۴۵۶۷۸۹".indexOf(d); })
    .replace(/[٠-٩]/g, function(d) { return "٠١٢٣٤٥٦٧٨٩".indexOf(d); });
}

function parseNumber_(value) {
  const normalized = normalizeDigits_(value)
    .replace(/[٬,\s]/g, "")
    .replace(/[^0-9.-]/g, "");
  if (!normalized || !/^-?\d+(\.\d+)?$/.test(normalized)) return null;
  const number = Number(normalized);
  return isFinite(number) ? number : null;
}

function normalizePhone_(value) {
  const t = normalizeDigits_(value).replace(/[\s\-()]/g, "");
  return /^\+?\d{10,15}$/.test(t) ? t : null;
}

function tz_() {
  return getSetting_("TIMEZONE") || "Asia/Tehran";
}

function pad2_(n) {
  return (n < 10 ? "0" : "") + n;
}

// کلید روز (میلادی) برای مقایسه امروز/دیروز
function dayKey_(date) {
  return Utilities.formatDate(new Date(date), tz_(), "yyyy-MM-dd");
}

function gregorianToJalali_(gy, gm, gd) {
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy;
  if (gy > 1600) { jy = 979; gy -= 1600; } else { jy = 0; gy -= 621; }
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) +
    Math.floor((gy2 + 399) / 400) - 80 + gd + gdm[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

// تاریخ به‌صورت شمسی یا میلادی، طبق تنظیمات
function formatDay_(value) {
  const d = new Date(value);
  if (isNaN(d.getTime())) return String(value || "");
  const p = dayKey_(d).split("-").map(Number);
  if (getSetting_("DATE_MODE") === "gregorian") {
    return p[0] + "/" + pad2_(p[1]) + "/" + pad2_(p[2]);
  }
  const j = gregorianToJalali_(p[0], p[1], p[2]);
  return j[0] + "/" + pad2_(j[1]) + "/" + pad2_(j[2]);
}

function timeOnly_(value) {
  const d = new Date(value);
  if (isNaN(d.getTime())) return "";
  return Utilities.formatDate(d, tz_(), "HH:mm");
}

function formatDateTime_(value) {
  const d = new Date(value);
  if (isNaN(d.getTime())) return String(value || "");
  return formatDay_(d) + " " + timeOnly_(d);
}

// تاریخ کوتاه برای دکمه‌ها: ماه/روز ساعت
function formatShort_(value) {
  const d = new Date(value);
  if (isNaN(d.getTime())) return "";
  return formatDay_(d).slice(5) + " " + timeOnly_(d);
}

function truncate_(value, maxLength) {
  const text = String(value || "");
  return text.length > maxLength ? text.slice(0, maxLength - 1) + "…" : text;
}

function cancelKeyboard_() {
  return {
    keyboard: [[{ text: "❌ لغو عملیات" }]],
    resize_keyboard: true,
    one_time_keyboard: true
  };
}

function skipCancelKeyboard_() {
  return {
    keyboard: [[{ text: "رد کردن" }, { text: "❌ لغو عملیات" }]],
    resize_keyboard: true,
    one_time_keyboard: true
  };
}

// =====================================================
//  ارتباط با تلگرام
// =====================================================

function getBotToken_() {
  return PropertiesService.getScriptProperties().getProperty("BOT_TOKEN") || "";
}

function telegramRequest_(method, payload) {
  const token = getBotToken_();
  if (!token) return { ok: false, description: "BOT_TOKEN is missing" };

  const response = UrlFetchApp.fetch("https://api.telegram.org/bot" + token + "/" + method, {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload || {}),
    muteHttpExceptions: true
  });

  const text = response.getContentText();
  try {
    return JSON.parse(text);
  } catch (error) {
    return { ok: false, description: text };
  }
}

function sendMessage_(chatId, text, replyMarkup) {
  const payload = { chat_id: String(chatId), text: String(text || "") };
  if (replyMarkup) payload.reply_markup = replyMarkup;
  return telegramRequest_("sendMessage", payload);
}

// متن‌های بلند رو به چند پیام تقسیم می‌کنه (محدودیت تلگرام ۴۰۹۶ کاراکتره)
function sendLongText_(chatId, text, replyMarkup) {
  const LIMIT = 3800;
  const chunks = [];
  let current = "";

  String(text || "").split("\n").forEach(function(line) {
    if ((current + "\n" + line).length > LIMIT && current) {
      chunks.push(current);
      current = line;
    } else {
      current = current ? current + "\n" + line : line;
    }
  });
  if (current) chunks.push(current);

  chunks.forEach(function(chunk, i) {
    sendMessage_(chatId, chunk, i === chunks.length - 1 ? replyMarkup : null);
  });
}

function answerCallbackQuery_(callbackQueryId) {
  return telegramRequest_("answerCallbackQuery", { callback_query_id: callbackQueryId });
}


// نتیجه‌های قدیمی «شماره اشتباه» به «انصراف» منتقل می‌شن (یک‌بار، بی‌خطر برای تکرار)
function migrateOutcomes_() {
  const fix = function(sheet, col) {
    if (!sheet || sheet.getLastRow() < 2) return;
    const range = sheet.getRange(2, col, sheet.getLastRow() - 1, 1);
    const vals = range.getValues();
    let changed = false;
    vals.forEach(function(r) { if (r[0] === "wrong_number") { r[0] = "not_interested"; changed = true; } });
    if (changed) range.setValues(vals);
  };
  fix(getSheet_(APP.SHEETS.LEADS), COL.STATUS);
  fix(getSheet_(APP.SHEETS.LEADS), COL.LAST_OUTCOME);
  fix(getCallsSheet_(), 6);
}
