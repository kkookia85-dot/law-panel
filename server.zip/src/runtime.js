'use strict';
// =====================================================================
//  runtime.js — اجرای همان کدهای Code.gs / Api.gs روی Node
//  به‌جای Google Sheets: داده‌ها در حافظه (سریع) + ذخیره‌ی دائمی در SQLite
//  هیچ پکیج خارجی لازم نیست (فقط Node 22+ که node:sqlite داره).
// =====================================================================
const vm = require('vm');
const fs = require('fs');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

// ---------- سریال‌سازی (تاریخ‌ها حفظ می‌شن) ----------
function ser(row) {
  return JSON.stringify(row, function (k, v) {
    const raw = this[k];
    if (raw instanceof Date) return { $d: raw.getTime() };
    return v;
  });
}
function de(txt) {
  return JSON.parse(txt, (k, v) => (v && typeof v === 'object' && !Array.isArray(v) && '$d' in v ? new Date(v.$d) : v));
}

// بیشتر متدهای فرمت‌دهی شیت (رنگ، عرض ستون...) برای سرور بی‌معنی‌ان؛ بی‌اثر جواب می‌دن
function lenient(obj) {
  return new Proxy(obj, {
    get(t, p, r) {
      if (p in t || typeof p === 'symbol' || p === 'then' || p === 'toJSON') return Reflect.get(t, p, r);
      return function () { return r; };
    }
  });
}

class Store {
  constructor(path) {
    this.db = new DatabaseSync(path);
    this.db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;');
    this.db.exec(`CREATE TABLE IF NOT EXISTS sheet_meta(name TEXT PRIMARY KEY, ord INTEGER, frozen INTEGER DEFAULT 0);
      CREATE TABLE IF NOT EXISTS sheet_rows(name TEXT, idx INTEGER, data TEXT, PRIMARY KEY(name, idx));
      CREATE TABLE IF NOT EXISTS props(k TEXT PRIMARY KEY, v TEXT);`);
    this.qUpsert = this.db.prepare('INSERT INTO sheet_rows(name, idx, data) VALUES(?,?,?) ON CONFLICT(name, idx) DO UPDATE SET data=excluded.data');
    this.qDelFrom = this.db.prepare('DELETE FROM sheet_rows WHERE name=? AND idx>=?');
    this.qMeta = this.db.prepare('INSERT INTO sheet_meta(name, ord, frozen) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET frozen=excluded.frozen');
    this.qProp = this.db.prepare('INSERT INTO props(k, v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v');
    this.qPropDel = this.db.prepare('DELETE FROM props WHERE k=?');
    this.sheets = [];
    this.props = {};
    this._load();
  }
  _load() {
    this.db.prepare('SELECT k, v FROM props').all().forEach(r => { this.props[r.k] = r.v; });
    const metas = this.db.prepare('SELECT name, frozen FROM sheet_meta ORDER BY ord').all();
    const rowsQ = this.db.prepare('SELECT idx, data FROM sheet_rows WHERE name=? ORDER BY idx');
    metas.forEach(m => {
      const sh = new Sheet(this, m.name);
      sh.frozen = m.frozen;
      rowsQ.all(m.name).forEach(r => { sh.data[r.idx] = de(r.data); });
      for (let i = 0; i < sh.data.length; i++) if (!sh.data[i]) sh.data[i] = [];
      this.sheets.push(sh);
    });
  }
  flush() {
    const dirty = this.sheets.filter(s => s.dirty.size || s.truncFrom !== null);
    if (!dirty.length) return;
    this.db.exec('BEGIN');
    try {
      dirty.forEach(s => {
        if (s.truncFrom !== null) { this.qDelFrom.run(s.name, s.truncFrom); }
        s.dirty.forEach(i => { if (i < s.data.length) this.qUpsert.run(s.name, i, ser(s.data[i])); });
        s.dirty.clear(); s.truncFrom = null;
      });
      this.db.exec('COMMIT');
    } catch (e) { try { this.db.exec('ROLLBACK'); } catch (e2) {} throw e; }
  }
  setProp(k, v) { this.props[k] = String(v); this.qProp.run(k, String(v)); }
  delProp(k) { delete this.props[k]; this.qPropDel.run(k); }
  close() { try { this.flush(); this.db.close(); } catch (e) {} }
}

class Sheet {
  constructor(store, name) { this.store = store; this.name = name; this.data = []; this.frozen = 0; this.dirty = new Set(); this.truncFrom = null; this.px = lenient(this); }
  _ensure(r, c) {
    while (this.data.length < r) { this.data.push([]); this.dirty.add(this.data.length - 1); }
    for (let i = 0; i < this.data.length; i++) {
      const row = this.data[i];
      if (row.length < c) { while (row.length < c) row.push(''); this.dirty.add(i); }
    }
  }
  getLastRow() {
    for (let i = this.data.length - 1; i >= 0; i--) if (this.data[i].some(v => v !== '' && v != null)) return i + 1;
    return 0;
  }
  getLastColumn() {
    let m = 0;
    this.data.forEach(r => { for (let i = r.length - 1; i >= 0; i--) if (r[i] !== '' && r[i] != null) { m = Math.max(m, i + 1); break; } });
    return m;
  }
  getMaxRows() { return Math.max(1000, this.data.length); }
  getRange(r, c, nr = 1, nc = 1) { return lenient(new Range(this, r, c, nr, nc)); }
  appendRow(arr) {
    const r = this.getLastRow() + 1;
    this._ensure(r, arr.length);
    this.data[r - 1] = arr.slice();
    this.dirty.add(r - 1);
  }
  deleteRow(r) {
    this.data.splice(r - 1, 1);
    for (let i = r - 1; i < this.data.length; i++) this.dirty.add(i);
    this.truncFrom = this.truncFrom === null ? this.data.length : Math.min(this.truncFrom, this.data.length);
  }
  setFrozenRows(n) { this.frozen = n; this.store.qMeta.run(this.name, this.store.sheets.indexOf(this), n); }
}
class Range {
  constructor(s, r, c, nr, nc) { Object.assign(this, { s, r, c, nr, nc }); }
  getValues() {
    this.s._ensure(this.r + this.nr - 1, this.c + this.nc - 1);
    const out = [];
    for (let i = 0; i < this.nr; i++) out.push(this.s.data[this.r - 1 + i].slice(this.c - 1, this.c - 1 + this.nc));
    return out;
  }
  setValues(v) {
    if (v.length !== this.nr || v.some(r => r.length !== this.nc)) {
      throw new Error('The number of columns in the data does not match the number of columns in the range. The data has ' + (v[0] && v[0].length) + ' but the range has ' + this.nc + '.');
    }
    this.s._ensure(this.r + v.length - 1, this.c + v[0].length - 1);
    v.forEach((row, i) => row.forEach((x, j) => { this.s.data[this.r - 1 + i][this.c - 1 + j] = x; }));
    for (let i = 0; i < v.length; i++) this.s.dirty.add(this.r - 1 + i);
    return this;
  }
  setValue(x) {
    this.s._ensure(this.r + this.nr - 1, this.c + this.nc - 1);
    for (let i = 0; i < this.nr; i++) { for (let j = 0; j < this.nc; j++) this.s.data[this.r - 1 + i][this.c - 1 + j] = x; this.s.dirty.add(this.r - 1 + i); }
    return this;
  }
  setNumberFormat() { return this; }
  setFontWeight() { return this; }
  getValue() { return this.getValues()[0][0]; }
}
class Spreadsheet {
  constructor(store) { this.store = store; }
  getId() { return 'LOCAL'; }
  getUrl() { return ''; }
  getSheetByName(n) { const s = this.store.sheets.find(x => x.name === n); return s ? s.px : null; }
  insertSheet(n) {
    const s = new Sheet(this.store, n);
    this.store.sheets.push(s);
    this.store.qMeta.run(n, this.store.sheets.length - 1, 0);
    return s.px;
  }
  getSheets() { return this.store.sheets.map(s => s.px); }
  toast() {}
}

// ---------- تاریخ و منطقه زمانی ----------
function tzParts(ms, tz) {
  const p = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).formatToParts(new Date(ms)).reduce((a, x) => (a[x.type] = x.value, a), {});
  if (p.hour === '24') p.hour = '00';
  return p;
}
function fmtDate(date, tz, fmt) {
  const p = tzParts(new Date(date).getTime(), tz);
  return fmt.replace(/yyyy|MM|dd|HH|mm|ss/g, t => ({ yyyy: p.year, MM: p.month, dd: p.day, HH: p.hour, mm: p.minute, ss: p.second }[t]));
}
function parseDate(s, tz) {
  const m = String(s).match(/(\d+)-(\d+)-(\d+)(?: (\d+):(\d+):(\d+))?/);
  const asUtc = Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
  const off = (ms) => { const p = tzParts(ms, tz); return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - ms; };
  let guess = asUtc - off(asUtc);
  guess = asUtc - off(guess);
  return new Date(guess);
}

// ---------- ساخت محیط ----------
// opts: { dbPath, onOutbound(url, opt), files:[...], tz }
function createRuntime(opts) {
  const store = new Store(opts.dbPath || ':memory:');
  const ss = lenient(new Spreadsheet(store));
  const cache = new Map();
  const tz = opts.tz || 'Asia/Tehran';

  const fakeResp = (url) => {
    let body = { ok: true, result: {} };
    if (/\/getMe/.test(url)) body = { ok: true, result: { username: store.props.BOT_USERNAME || '' } };
    if (/\/getWebhookInfo/.test(url)) body = { ok: true, result: { url: opts.publicUrl || '', pending_update_count: 0 } };
    return { getContentText: () => JSON.stringify(body), getResponseText: () => JSON.stringify(body), getResponseCode: () => 200 };
  };

  const ctx = {
    console, Date, JSON, Math, Number, String, Array, Object, RegExp, parseInt, parseFloat, isNaN, isFinite, Intl, Error, Infinity, Boolean, Map, Set, Symbol,
    SpreadsheetApp: {
      getActiveSpreadsheet: () => ss, openById: () => ss, getActive: () => ss, create: () => ss,
      getUi: () => ({
        createMenu: () => ({ addItem() { return this; }, addSeparator() { return this; }, addToUi() {} }),
        alert() { return 3; }, prompt() { return { getSelectedButton: () => 2, getResponseText: () => '' }; },
        ButtonSet: { OK: 1, OK_CANCEL: 2, YES_NO: 3 }, Button: { OK: 1, YES: 3, NO: 4 }
      })
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: k => (k in store.props ? store.props[k] : null),
        setProperty: (k, v) => store.setProp(k, v),
        deleteProperty: k => store.delProp(k)
      })
    },
    CacheService: {
      getScriptCache: () => ({
        get: k => { const e = cache.get(k); if (!e) return null; if (e.exp && e.exp < Date.now()) { cache.delete(k); return null; } return e.v; },
        put: (k, v, sec) => { cache.set(k, { v: String(v), exp: sec ? Date.now() + sec * 1000 : 0 }); },
        remove: k => { cache.delete(k); }
      })
    },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    Utilities: {
      getUuid: () => crypto.randomUUID(),
      formatDate: fmtDate,
      parseDate,
      newBlob: (d, t, n) => ({ d, t, n }),
      sleep() {}
    },
    UrlFetchApp: {
      fetch: (url, opt) => { if (opts.onOutbound) opts.onOutbound(url, opt || {}); return fakeResp(url); }
    },
    ScriptApp: {
      getService: () => ({ getUrl: () => opts.publicUrl || '' }),
      getProjectTriggers: () => [],
      newTrigger: () => ({ timeBased: () => ({ everyDays: () => ({ atHour: () => ({ create() {} }) }) }) }),
      deleteTrigger() {}
    },
    Session: { getScriptTimeZone: () => tz },
    ContentService: { createTextOutput: t => ({ text: t, setMimeType() { return this; } }), MimeType: { JSON: 'json' } },
    HtmlService: {
      createHtmlOutput: t => ({ html: t }),
      createHtmlOutputFromFile: () => ({ setTitle() { return this; }, addMetaTag() { return this; }, setXFrameOptionsMode() { return this; } }),
      XFrameOptionsMode: { ALLOWALL: 1 }
    }
  };
  vm.createContext(ctx);

  // const/let بین اسکریپت‌های vm مشترک نیست؛ همه‌ی فایل‌ها یکجا اجرا می‌شن
  const src = opts.files.map(f => fs.readFileSync(f, 'utf8')).join('\n');
  vm.runInContext(src, ctx, { filename: 'bundle.gs' });

  const rt = {
    ctx, store, ss,
    run: code => vm.runInContext(code, ctx),
    call(name, ...args) {
      ctx.__a = args;
      try { return vm.runInContext(name + '(...__a)', ctx); } finally { ctx.__a = null; store.flush(); }
    },
    flush: () => store.flush(),
    close: () => store.close()
  };
  return rt;
}

module.exports = { createRuntime, Store, fmtDate, parseDate };
