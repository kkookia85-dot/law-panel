'use strict';
// =====================================================================
//  server.js — سرور اپ + ربات تلگرام (Long Polling) + زمان‌بندی
// =====================================================================
const http = require('http');
const fs = require('fs');
const path = require('path');
const { createRuntime } = require('./runtime.js');

// ---------- تنظیمات از env ----------
function loadEnv(file) {
  try {
    fs.readFileSync(file, 'utf8').split(/\r?\n/).forEach(line => {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    });
  } catch (e) { /* فایل .env اختیاریه */ }
}
const ROOT = path.join(__dirname, '..');
loadEnv(path.join(ROOT, '.env'));

const CFG = {
  port: Number(process.env.PORT || 3000),
  host: process.env.HOST || '127.0.0.1',
  db: process.env.DB_PATH || path.join(ROOT, 'data', 'panel.db'),
  token: process.env.BOT_TOKEN || '',
  telegram: String(process.env.TELEGRAM || 'on').toLowerCase() !== 'off',
  publicUrl: (process.env.PUBLIC_URL || '').replace(/\/+$/, ''),
  tz: process.env.TZ_NAME || 'Asia/Tehran',
  reminderHour: process.env.DAILY_REMINDER_HOUR === undefined ? '9' : process.env.DAILY_REMINDER_HOUR,
  tgProxy: process.env.TELEGRAM_API_BASE || 'https://api.telegram.org'
};
const log = (...a) => console.log(new Date().toISOString(), ...a);

// ---------- صف ارسال به تلگرام ----------
const outQ = [];
let outBusy = false;
function enqueue(url, opt) { outQ.push({ url, opt, tries: 0 }); pump(); }
async function sendOne(job) {
  const real = job.url.replace('https://api.telegram.org', CFG.tgProxy);
  const o = job.opt || {};
  let body, headers = {};
  if (o.payload && typeof o.payload === 'object' && !Array.isArray(o.payload)) {
    const fd = new FormData();
    Object.keys(o.payload).forEach(k => {
      const v = o.payload[k];
      if (v && typeof v === 'object' && 'd' in v && 't' in v) fd.append(k, new Blob([v.d], { type: v.t }), v.n || 'file');
      else fd.append(k, String(v));
    });
    body = fd;
  } else {
    body = o.payload;
    headers['Content-Type'] = o.contentType || 'application/json';
  }
  const res = await fetch(real, { method: 'POST', body, headers, signal: AbortSignal.timeout(30000) });
  const txt = await res.text();
  let j = null; try { j = JSON.parse(txt); } catch (e) {}
  return { status: res.status, json: j, txt };
}
async function pump() {
  if (outBusy) return;
  outBusy = true;
  while (outQ.length) {
    const job = outQ.shift();
    try {
      const r = await sendOne(job);
      if (r.status === 429 && job.tries < 4) {
        const wait = ((r.json && r.json.parameters && r.json.parameters.retry_after) || 2) * 1000;
        job.tries++; outQ.unshift(job); await sleep(wait); continue;
      }
      if (r.status >= 500 && job.tries < 3) { job.tries++; outQ.unshift(job); await sleep(1500 * job.tries); continue; }
      if (!r.json || !r.json.ok) log('telegram error', r.status, String(r.txt).slice(0, 200).replace(CFG.token, '***'));
    } catch (e) {
      if (job.tries < 3) { job.tries++; outQ.unshift(job); await sleep(1500 * job.tries); }
      else log('telegram send failed:', String(e.message).replace(CFG.token, '***'));
    }
    await sleep(40); // حدود ۲۵ پیام در ثانیه
  }
  outBusy = false;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------- اجرای کدها ----------
const rt = createRuntime({
  dbPath: CFG.db,
  files: [path.join(ROOT, 'gas', 'Code.gs'), path.join(ROOT, 'gas', 'Api.gs')],
  tz: CFG.tz,
  publicUrl: CFG.publicUrl,
  onOutbound: (url, opt) => { if (CFG.token) enqueue(url, opt); }
});
if (CFG.token) rt.store.setProp('BOT_TOKEN', CFG.token);
if (CFG.publicUrl) rt.store.setProp('WEB_APP_URL', CFG.publicUrl);
rt.call('setupProject');
log('DB آماده. اعضا:', rt.run('getAllAgents_().length'), ' درخواست‌ها:', rt.run('getAllLeads_().length'));

// ---------- HTTP ----------
const PUBLIC = path.join(ROOT, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.css': 'text/css; charset=utf-8', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
const fails = new Map(); // ip -> {n, reset}
function clientIp(req) {
  const xf = req.headers['x-forwarded-for'];
  if (xf && /^(127\.|::1|::ffff:127\.)/.test(req.socket.remoteAddress || '')) return String(xf).split(',')[0].trim();
  return req.socket.remoteAddress || '';
}
function blocked(ip) { const f = fails.get(ip); return f && f.reset > Date.now() && f.n >= 40; }
function noteFail(ip) {
  const f = fails.get(ip);
  if (!f || f.reset < Date.now()) fails.set(ip, { n: 1, reset: Date.now() + 10 * 60 * 1000 });
  else f.n++;
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const headers = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY' };
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/healthz') { res.writeHead(200, { ...headers, 'Content-Type': 'text/plain' }); return res.end('ok'); }

    if (url.pathname === '/api' && req.method === 'POST') {
      const ip = clientIp(req);
      if (blocked(ip)) { res.writeHead(429, { ...headers, 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ ok: false, error: 'TOO_MANY_ATTEMPTS' })); }
      let obj;
      try { obj = JSON.parse(await readBody(req, 2 * 1024 * 1024)); } catch (e) { res.writeHead(400, headers); return res.end('bad request'); }
      if (!obj || obj.api !== true) { res.writeHead(400, headers); return res.end('bad request'); }
      const out = rt.call('appApi', obj.token, obj.action, obj.payload || {});
      if (out && out.error === 'UNAUTHORIZED') noteFail(ip);
      res.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify(out));
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      let p = decodeURIComponent(url.pathname);
      if (p === '/') p = '/index.html';
      const file = path.normalize(path.join(PUBLIC, p));
      if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403, headers); return res.end(); }
      fs.readFile(file, (err, data) => {
        if (err) { res.writeHead(404, headers); return res.end('not found'); }
        const ext = path.extname(file);
        const cc = ext === '.html' || file.endsWith('sw.js') || file.endsWith('config.js') ? 'no-cache' : 'public, max-age=86400';
        res.writeHead(200, { ...headers, 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cc });
        res.end(req.method === 'HEAD' ? undefined : data);
      });
      return;
    }
    res.writeHead(405, headers); res.end();
  } catch (e) {
    log('http error', e && e.stack ? e.stack : e);
    try { res.writeHead(500, headers); res.end('error'); } catch (e2) {}
  }
});

// ---------- تلگرام (Long Polling) ----------
let running = true;
async function tg(method, payload, timeoutMs) {
  const r = await fetch(CFG.tgProxy + '/bot' + CFG.token + '/' + method, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload || {}),
    signal: AbortSignal.timeout(timeoutMs || 15000)
  });
  return r.json();
}
async function pollLoop() {
  try {
    const me = await tg('getMe', {});
    if (me.ok) { rt.store.setProp('BOT_USERNAME', me.result.username); log('ربات:', '@' + me.result.username); }
    else { log('getMe ناموفق (توکن درسته؟)', me.description); }
    await tg('deleteWebhook', { drop_pending_updates: false });
  } catch (e) { log('اتصال اولیه به تلگرام ناموفق:', String(e.message).replace(CFG.token, '***')); }

  let offset = Number(rt.store.props.TG_OFFSET || 0);
  let backoff = 1000;
  while (running) {
    try {
      const r = await tg('getUpdates', { offset, timeout: 25, allowed_updates: ['message', 'callback_query'] }, 40000);
      if (!r.ok) { log('getUpdates:', r.description); await sleep(backoff); backoff = Math.min(backoff * 2, 30000); continue; }
      backoff = 1000;
      for (const u of r.result) {
        offset = u.update_id + 1;
        try { rt.call('doPost', { postData: { contents: JSON.stringify(u) } }); }
        catch (e) { log('خطا در پردازش آپدیت', u.update_id, e && e.message); }
      }
      if (r.result.length) rt.store.setProp('TG_OFFSET', offset);
    } catch (e) {
      log('polling error:', String(e.message).replace(CFG.token, '***'));
      await sleep(backoff); backoff = Math.min(backoff * 2, 30000);
    }
  }
}

// ---------- زمان‌بندی (یادآوری صبحگاهی) ----------
let lastReminderDay = '';
setInterval(() => {
  if (CFG.reminderHour === '' || !CFG.token || !CFG.telegram) return;
  const p = new Intl.DateTimeFormat('en-GB', { timeZone: CFG.tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date()).reduce((a, x) => (a[x.type] = x.value, a), {});
  const day = p.year + '-' + p.month + '-' + p.day;
  if (Number(p.hour) === Number(CFG.reminderHour) && day !== lastReminderDay) {
    lastReminderDay = day;
    try { rt.call('dailyReminder'); log('یادآوری صبحگاهی ارسال شد'); } catch (e) { log('dailyReminder error', e && e.message); }
  }
}, 30000);
// یادآوری وقت مشاورهها (هر نیم‌دقیقه بررسی می‌شه)
setInterval(() => {
  if (!CFG.token || !CFG.telegram) return;
  try { const n = rt.call('visitReminders'); if (n) log('یادآوری وقت مشاوره ارسال شد:', n); } catch (e) { log('visitReminders error', e && e.message); }
}, 30000);
setInterval(() => rt.flush(), 5000);

// ---------- شروع و خاموشی ----------
server.listen(CFG.port, CFG.host, () => log(`سرور روی http://${CFG.host}:${CFG.port} بالا اومد. تلگرام: ${CFG.telegram && CFG.token ? 'روشن' : 'خاموش'}`));
if (CFG.telegram && CFG.token) pollLoop();

function shutdown() {
  running = false; log('در حال خاموش شدن…');
  server.close(); rt.close(); setTimeout(() => process.exit(0), 300);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('unhandledRejection', e => log('unhandledRejection', e && e.stack ? e.stack : e));
process.on('uncaughtException', e => log('uncaughtException', e && e.stack ? e.stack : e));
