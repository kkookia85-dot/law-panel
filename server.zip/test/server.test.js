'use strict';
// تست سرور واقعی: HTTP + تلگرام جعلی + ری‌استارت
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path');
const { spawn, spawnSync } = require('child_process');
const ROOT = path.join(__dirname, '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'panel-'));
const DB = path.join(tmp, 'p.db');
let pass = 0, failn = 0;
const ok = (c, m) => { if (c) pass++; else { failn++; console.log('FAIL:', m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const KEY = 'AAAA-BBBB-CCCC';
fs.writeFileSync(path.join(tmp, 'd.json'), JSON.stringify({ sheets: {}, props: { ADMIN_APP_KEY: KEY } }));
const env = { ...process.env, DB_PATH: DB, TZ_NAME: 'Asia/Tehran' };
const imp = spawnSync('node', ['--no-warnings', 'src/import.js', '--file', path.join(tmp, 'd.json')], { cwd: ROOT, env });
ok(imp.status === 0, 'import: ' + imp.stderr + imp.stdout);

// تلگرام جعلی
const sent = []; let queue = [{ update_id: 7, message: { message_id: 1, chat: { id: 555, type: 'private' }, from: { id: 555, first_name: 'Ali' }, text: '/start' } }];
const tg = http.createServer((req, res) => {
  let b = ''; req.on('data', c => b += c); req.on('end', () => {
    const m = req.url.split('/').pop(); let out = { ok: true, result: true };
    if (m === 'getMe') out.result = { username: 'test_bot' };
    else if (m === 'getUpdates') { const q = queue; queue = []; if (!q.length) return setTimeout(() => { res.end(JSON.stringify({ ok: true, result: [] })); }, 300); out.result = q; }
    else sent.push({ m, ct: req.headers['content-type'], b: b.slice(0, 300) });
    res.end(JSON.stringify(out));
  });
}).listen(0);

async function start(port) {
  const p = spawn('node', ['--no-warnings', 'src/server.js'], { cwd: ROOT, env: { ...env, PORT: port, BOT_TOKEN: '123:abc', TELEGRAM_API_BASE: 'http://127.0.0.1:' + tg.address().port, DAILY_REMINDER_HOUR: '' } });
  let out = ''; p.stdout.on('data', d => out += d); p.stderr.on('data', d => out += d);
  for (let i = 0; i < 50; i++) { await sleep(100); try { const r = await fetch(`http://127.0.0.1:${port}/healthz`); if (r.ok) break; } catch (e) {} }
  p.out = () => out; return p;
}
const api = (port, token, action, payload) => fetch(`http://127.0.0.1:${port}/api`, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify({ api: true, token, action, payload: payload || {} }) }).then(r => r.json());

(async () => {
  const PORT = 3911;
  let s = await start(PORT);
  let r = await api(PORT, KEY, 'me'); ok(r.ok && r.data.role === 'admin', 'admin me ' + JSON.stringify(r));
  r = await api(PORT, 'WRONG-WRONG-WRONG', 'me'); ok(!r.ok && r.error === 'UNAUTHORIZED', 'bad key');
  r = await api(PORT, KEY, 'agentAdd', { name: 'سارا', code: 'S1' }); ok(r.ok, 'agentAdd ' + JSON.stringify(r));
  const home = await fetch(`http://127.0.0.1:${PORT}/`); const html = await home.text(); ok(home.ok && html.includes('<html'), 'index served');
  const cfg = await (await fetch(`http://127.0.0.1:${PORT}/config.js`)).text(); ok(cfg.includes('"/api"'), 'config');
  ok((await fetch(`http://127.0.0.1:${PORT}/../src/server.js`)).status !== 200, 'traversal blocked');
  await sleep(1500);
  ok(sent.some(x => x.m === 'sendMessage'), 'bot replied to /start via fake telegram: ' + JSON.stringify(sent.map(x => x.m)) + s.out());
  // ری‌استارت و پایداری
  s.kill('SIGTERM'); await sleep(800);
  s = await start(PORT);
  r = await api(PORT, KEY, 'team'); ok(r.ok && JSON.stringify(r.data).includes('سارا'), 'persisted after restart ' + JSON.stringify(r).slice(0, 200));
  s.kill('SIGKILL'); tg.close();
  // بکاپ
  const b = spawnSync('node', ['--no-warnings', 'src/backup.js'], { cwd: ROOT, env: { ...env, BACKUP_DIR: path.join(tmp, 'bk') } });
  ok(b.status === 0 && fs.readdirSync(path.join(tmp, 'bk')).length === 1, 'backup ' + b.stderr);
  console.log(`سرور: ${pass} موفق، ${failn} ناموفق`); process.exit(failn ? 1 : 0);
})();
